var Entry = "pages/", MainRoot = Entry + "main/", OldMainRoot = "main/", CommonRoot = Entry + "common/", SecondaryRoot = Entry + "secondary/", FulisheRoot = Entry + "fulishe/", OldFulisheRoot = "fulishe/", ActivityRoot = "activity/", OldCommunityRoot = "community/", RouteMap = {
    HomePage: MainRoot + "home/index",
    StoreHomePage: MainRoot + "store/index",
    UserCenterPage: MainRoot + "mine/index",
    Webview: MainRoot + "webview/index",
    JumpPage: MainRoot + "jump/page",
    OldWebview: OldMainRoot + "webview/index",
    OldJumpPage: OldMainRoot + "jump/page",
    OldLoginIndex: OldMainRoot + "login-page/index",
    NoteDetail: MainRoot + "note/index",
    JumpToApp: CommonRoot + "jump-to-app/index",
    NotFound: CommonRoot + "not-found/index",
    ErrorPage: CommonRoot + "error/index",
    LoginIndex: CommonRoot + "login/index",
    MobileLogin: CommonRoot + "login/mobile-login",
    LoginTerms: CommonRoot + "login/terms",
    LoginPrivacy: CommonRoot + "login/privacy",
    ContactPage: CommonRoot + "contact/index",
    Feedback: CommonRoot + "feedback/index",
    InfoPage: SecondaryRoot + "mine/info",
    InfoEditPage: SecondaryRoot + "mine/edit",
    SettingsPage: SecondaryRoot + "mine/setting",
    MineCollect: SecondaryRoot + "mine/collect",
    SearchIndex: SecondaryRoot + "search/index",
    SearchResult: SecondaryRoot + "search/result",
    AuthorPage: SecondaryRoot + "author/index",
    FOLLOWINGS: SecondaryRoot + "author/followings",
    FOLLOWERS: SecondaryRoot + "author/followers",
    NoteCommentDetail: SecondaryRoot + "comment/index",
    CheckoutPay: FulisheRoot + "checkout/pay",
    MemberPurchase: FulisheRoot + "member/purchase",
    OldCheckoutPay: OldFulisheRoot + "checkout/pay",
    OldMemberPurchase: OldFulisheRoot + "member/purchase",
    OldGoodsDetail: OldFulisheRoot + "goods/index",
    OldNote: OldCommunityRoot + "discovery/note",
    OldVideoNote: OldCommunityRoot + "discovery/video-note",
    OldFeedNote: OldCommunityRoot + "note/index",
    OldAuthorPage: OldCommunityRoot + "author/index",
    ActivityDrawFaceIndex: ActivityRoot + "draw-face/index",
    ActivityDrawFaceItem: ActivityRoot + "draw-face/item",
    ActivityLuckyPacketHome: ActivityRoot + "lucky-packet/home/index",
    ActivityLuckyPacketShake: ActivityRoot + "lucky-packet/shake/index",
    ActivityLuckyPacketJoin: ActivityRoot + "lucky-packet/join/index",
    ActivityLuckyPacketResult: ActivityRoot + "lucky-packet/result/index",
    ActivityLuckyPacketMoney: ActivityRoot + "lucky-packet/money/index",
    ActivityLuckyPacketError: ActivityRoot + "lucky-packet/error/index"
}, NoNavigationBarRoutes = [], getRoute = function(o) {
    return RouteMap[o];
}, getCategory = function(o) {
    var e = "";
    for (var t in RouteMap) if (Object.prototype.hasOwnProperty.call(RouteMap, t)) {
        var i = RouteMap[t];
        if (o === i) {
            e = t;
            break;
        }
    }
    return e;
}, isSwitchTab = function(o) {
    return [ "HomePage", "StoreHomePage", "UserCenterPage" ].indexOf(o) > -1;
}, getCategoryByoldRoute = function() {
    var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = {
        HomePage: {
            oldRoute: [ "main/home/page" ]
        },
        AuthorPage: {
            oldRoute: [ "community/author/index" ]
        },
        Webview: {
            oldRoute: [ "main/webview/index" ]
        },
        StoreHomePage: {
            oldRoute: [ "main/fulishe/index" ]
        },
        LoginIndex: {
            oldRoute: [ "main/login-page/index" ]
        },
        JumpToApp: {
            oldRoute: [ "main/jump-to-app/index" ]
        },
        NoteDetail: {
            oldRoute: [ "community/discovery/note", "community/discovery/video-note", "community/note/index" ]
        },
        FOLLOWINGS: {
            oldRoute: [ "community/author/followings" ]
        },
        FOLLOWERS: {
            oldRoute: [ "community/author/followers" ]
        }
    }, t = {}, i = "pages/" + o, n = getCategory(i);
    return n ? (t.category = n, t.isSwitchTab = isSwitchTab(n), t) : (Object.keys(e).some(function(i) {
        if (e[i].oldRoute.indexOf(o) > -1) return t = {
            category: i,
            isSwitchTab: isSwitchTab(i)
        }, !0;
    }), t);
}, GetPages = function(o) {
    var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], t = [];
    for (var i in RouteMap) if (Object.prototype.hasOwnProperty.call(RouteMap, i)) {
        var n = RouteMap[i];
        if (n && 0 === n.indexOf(o)) {
            var a = e ? n.replace(o, "") : n;
            t.push(a);
        }
    }
    return t;
};

module.exports = {
    getRoute: getRoute,
    isSwitchTab: isSwitchTab,
    MainRoot: MainRoot,
    OldMainRoot: OldMainRoot,
    CommonRoot: CommonRoot,
    SecondaryRoot: SecondaryRoot,
    FulisheRoot: FulisheRoot,
    OldFulisheRoot: OldFulisheRoot,
    OldCommunityRoot: OldCommunityRoot,
    ActivityRoot: ActivityRoot,
    RouteMap: RouteMap,
    getCategory: getCategory,
    GetPages: GetPages,
    NoNavigationBarRoutes: NoNavigationBarRoutes,
    getCategoryByoldRoute: getCategoryByoldRoute
};