function _defineProperty(e, r, n) {
    return r in e ? Object.defineProperty(e, r, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = n, e;
}

function getFormatedUserTag() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], n = e.trim().split("@"), t = [], i = !1;
    return n.forEach(function(e, n) {
        var o = n > 0 && e ? "@" : "", a = !1;
        r.some(function(r) {
            if (e.indexOf(r.nickname) > -1) {
                a = !0, i = !0, t.push({
                    type: "userTag",
                    text: "@ " + r.nickname,
                    id: r.userid || r.id
                });
                var n = e.replace(r.nickname, "");
                return n.trim() && t.push({
                    type: "text",
                    text: n
                }), !0;
            }
        }), !a && e && t.push({
            type: "text",
            text: "" + o + e
        });
    }), {
        result: t,
        hasUserTag: i
    };
}

function getFormatTag() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [], t = JSON.parse(JSON.stringify(r)), i = e.split(/[#]/), o = [];
    return i.forEach(function(e) {
        if (e) {
            var r = !1, i = !1, a = !1;
            if (t.some(function(n) {
                if (n.link = n.link || "", e === n.name && isDeepLink(n) && (a = !0), e === n.name && !isDeepLink(n)) return r = !0, 
                o.push({
                    type: "pageTag",
                    sourceType: n.type,
                    text: e,
                    link: n.link,
                    iconUrl: (0, _icons.getPageTagIconUrl)(n.type)
                }), !0;
            }), a && e && e.trim() && (e = "#" + e + "#"), e.indexOf("@") > -1 && n.length > 0) {
                var s = getFormatedUserTag(e, n);
                i = s.hasUserTag, i && (o = o.concat(s.result));
            }
            r || i || o.push({
                type: "text",
                text: e
            });
        }
    }), o;
}

function getExpressionIcon(e) {
    if (!e) return null;
    var r = JSON.parse(JSON.stringify(ICON_MAPPING_REVERSE));
    for (var n in r) if (n === e) return "https://ci.xiaohongshu.com/xy_emo_" + ICON_MAPPING_REVERSE[n] + ".png?v=2";
    return null;
}

function getFormatedExpressionArr() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [], t = [], i = e, o = JSON.parse(JSON.stringify(r)), a = i.indexOf("[") > -1 && i.indexOf("]") > -1;
    if (!a && i.indexOf("@") > -1 && (a = !0), !a) return [ {
        type: "text",
        text: i
    } ];
    for (i = i.replace(/\[商品]|\[话题]|\[地区]|\[自定义]|\[品牌]|\[地点]|\[店铺]|\[影视]/g, ""); i.length > 0; ) {
        var s = i.indexOf("["), u = i.indexOf("]");
        if (-1 === s || -1 === u || u < s) {
            t = t.concat(getFormatTag(i, o, n)), i = "";
            break;
        }
        t = t.concat(getFormatTag(i.substr(0, s), o, n));
        var _ = i.substr(s + 1, u - s - 1);
        if (getExpressionIcon(_)) t.push({
            type: "image",
            url: getExpressionIcon(_),
            text: i.substr(s, u - s + 1)
        }); else {
            var g = i.substr(s, u - s + 1);
            t = t.concat(getFormatTag(g, o, n));
        }
        i = i.substr(u + 1, i.length);
    }
    return t;
}

function filterUnSupportDiscovery() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = [];
    return e.forEach(function(e) {
        isSupportDiscovery(e) && r.push(e);
    }), r;
}

function getNoTagNoFaceIconText() {
    return (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "").replace(/\[(.+?)\]/g, "");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isSupportDiscovery = exports.getGoodsId = void 0;

var _ICON_MAPPING;

exports.getFormatTag = getFormatTag, exports.getExpressionIcon = getExpressionIcon, 
exports.getFormatedExpressionArr = getFormatedExpressionArr, exports.filterUnSupportDiscovery = filterUnSupportDiscovery, 
exports.getNoTagNoFaceIconText = getNoTagNoFaceIconText;

var _enum = require("./enum.js"), _icons = require("./icons.js"), ICON_MAPPING = (_ICON_MAPPING = {
    oldDeyi: "得意",
    xihuan: "喜欢",
    huoli: "活力",
    shaonv: "少女心",
    buman: "不满",
    taoyan: "讨厌",
    wuyu: "无语L",
    oldShengqi: "生气",
    koubi: "抠鼻",
    zhuangku: "装酷",
    zhenjing: "震惊L",
    shihua: "石化",
    haipa: "害怕",
    kuku: "哭哭",
    fanu: "发怒",
    fuhei: "腹黑",
    weiqu: "委屈",
    keshui: "瞌睡",
    baji: "吧唧R",
    bishi: "鄙视R",
    deyi: "得意R",
    feiwen: "飞吻R",
    fuqiang: "扶墙R",
    haixiu: "害羞R",
    hanyan: "汗颜R",
    jingkong: "惊恐R",
    kure: "哭惹R",
    mengmengda: "萌萌哒R",
    sese: "色色R",
    shengqi: "生气R",
    tanqi: "叹气R",
    touxiao: "偷笑R",
    xiaoku: "笑哭R",
    zaijian: "再见R",
    zan: "赞R",
    zhuakuang: "抓狂R",
    r_xieyan: "斜眼R",
    r_kelian: "可怜R",
    r_zhoumei: "皱眉R",
    angry: "无语",
    han: "汗",
    blind: "瞎",
    cool: "酷",
    cry: "哭",
    cute: "萌",
    kiss: "么么哒",
    dignose: "挖鼻孔",
    koushui: "口水",
    baiyan: "白眼",
    frozen: "好冷",
    shy: "害羞",
    titter: "嘿嘿",
    xixi: "嘻嘻",
    haha: "哈哈",
    oops: "好雷",
    question: "啊？",
    rish: "土豪",
    shock: "震惊",
    shoo: "嘘",
    dizzy: "晕",
    h_tushetou: "吐舌头H",
    h_jingxia: "惊吓H",
    h_chelian: "扯脸H",
    r_anzhongguancha: "暗中观察R",
    r_chigua: "吃瓜R",
    r_daxiao: "大笑R",
    r_heishuwenhao: "黑薯问号R",
    r_henaicha: "喝奶茶R",
    r_huangjinshu: "黄金薯R"
}, _defineProperty(_ICON_MAPPING, "r_kelian", "可怜R"), _defineProperty(_ICON_MAPPING, "r_koubi", "抠鼻R"), 
_defineProperty(_ICON_MAPPING, "r_maibao", "买爆R"), _defineProperty(_ICON_MAPPING, "r_paidui", "派对R"), 
_defineProperty(_ICON_MAPPING, "r_shihua", "石化R"), _defineProperty(_ICON_MAPPING, "r_shiwang", "失望R"), 
_defineProperty(_ICON_MAPPING, "r_shuijiao", "睡觉R"), _defineProperty(_ICON_MAPPING, "r_wa", "哇R"), 
_defineProperty(_ICON_MAPPING, "r_weixiao", "微笑R"), _defineProperty(_ICON_MAPPING, "r_wulian", "捂脸R"), 
_defineProperty(_ICON_MAPPING, "r_zipai", "自拍R"), _defineProperty(_ICON_MAPPING, "r_nidongde", "你懂的R"), 
_defineProperty(_ICON_MAPPING, "r_sang", "丧R"), _ICON_MAPPING), ICON_MAPPING_REVERSE = Object.keys(ICON_MAPPING).reduce(function(e, r) {
    var n = ICON_MAPPING[r];
    return 0 === r.indexOf("old") && r.split("old").length > 1 && (r = r.split("old")[1].toLowerCase()), 
    e[n] = r, e;
}, {}), isDeepLink = function(e) {
    return e.link && e.link.indexOf("xhsdiscover") > -1;
}, getGoodsId = exports.getGoodsId = function(e) {
    var r = e.indexOf("/goods/"), n = e || "";
    return e.indexOf("http") > -1 && (n = e.substr(r + "/goods/".length, 24)), n;
}, isSupportDiscovery = exports.isSupportDiscovery = function(e) {
    return e.type !== _enum.NOTE_TYPE.MULTI;
};