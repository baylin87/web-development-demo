function ctorName(r) {
    return r.constructor ? r.constructor.name : null;
}

function isArray(r) {
    return Array.isArray ? Array.isArray(r) : r instanceof Array;
}

function isError(r) {
    return r instanceof Error || "string" == typeof r.message && r.constructor && "number" == typeof r.constructor.stackTraceLimit;
}

function isDate(r) {
    return r instanceof Date || "function" == typeof r.toDateString && "function" == typeof r.getDate && "function" == typeof r.setDate;
}

function isRegexp(r) {
    return r instanceof RegExp || "string" == typeof r.flags && "boolean" == typeof r.ignoreCase && "boolean" == typeof r.multiline && "boolean" == typeof r.global;
}

function isGeneratorFn(r, t) {
    return "GeneratorFunction" === ctorName(r);
}

function isGeneratorObj(r) {
    return "function" == typeof r.throw && "function" == typeof r.return && "function" == typeof r.next;
}

function isArguments(r) {
    try {
        if ("number" == typeof r.length && "function" == typeof r.callee) return !0;
    } catch (r) {
        if (-1 !== r.message.indexOf("callee")) return !0;
    }
    return !1;
}

function isBuffer(r) {
    return !(!r.constructor || "function" != typeof r.constructor.isBuffer) && r.constructor.isBuffer(r);
}

var toString = Object.prototype.toString;

module.exports = function(r) {
    if (void 0 === r) return "undefined";
    if (null === r) return "null";
    var t = typeof r;
    if ("boolean" === t) return "boolean";
    if ("string" === t) return "string";
    if ("number" === t) return "number";
    if ("symbol" === t) return "symbol";
    if ("function" === t) return isGeneratorFn(r) ? "generatorfunction" : "function";
    if (isArray(r)) return "array";
    if (isBuffer(r)) return "buffer";
    if (isArguments(r)) return "arguments";
    if (isDate(r)) return "date";
    if (isError(r)) return "error";
    if (isRegexp(r)) return "regexp";
    switch (ctorName(r)) {
      case "Symbol":
        return "symbol";

      case "Promise":
        return "promise";

      case "WeakMap":
        return "weakmap";

      case "WeakSet":
        return "weakset";

      case "Map":
        return "map";

      case "Set":
        return "set";

      case "Int8Array":
        return "int8array";

      case "Uint8Array":
        return "uint8array";

      case "Uint8ClampedArray":
        return "uint8clampedarray";

      case "Int16Array":
        return "int16array";

      case "Uint16Array":
        return "uint16array";

      case "Int32Array":
        return "int32array";

      case "Uint32Array":
        return "uint32array";

      case "Float32Array":
        return "float32array";

      case "Float64Array":
        return "float64array";
    }
    if (isGeneratorObj(r)) return "generator";
    switch (t = toString.call(r)) {
      case "[object Object]":
        return "object";

      case "[object Map Iterator]":
        return "mapiterator";

      case "[object Set Iterator]":
        return "setiterator";

      case "[object String Iterator]":
        return "stringiterator";

      case "[object Array Iterator]":
        return "arrayiterator";
    }
    return t.slice(8, -1).toLowerCase().replace(/\s/g, "");
};