function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var i = 0; i < t.length; i++) {
            var r = t[i];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, i, r) {
        return i && e(t.prototype, i), r && e(t, r), t;
    };
}(), _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _date = require("./../../utils/date.js"), CountDown = function(e) {
    function t() {
        var e, i, r, n;
        _classCallCheck(this, t);
        for (var o = arguments.length, a = Array(o), s = 0; s < o; s++) a[s] = arguments[s];
        return i = r = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        r.props = {
            timeStamp: {
                require: !0
            },
            fmt: {
                type: String,
                default: "shortTime"
            },
            interval: {
                default: "1000"
            }
        }, r.data = {
            timer: void 0,
            time: void 0,
            endTime: void 0
        }, r.watch = {
            timeStamp: function(e, t) {
                console.log("num value: " + t + " -> " + e), this.endTime = Number(this.timeStamp) + new Date().getTime(), 
                this.timer && clearInterval(this.timer), this.timer = setInterval(this.tick.bind(this), Number(this.interval)), 
                setTimeout(this.tick.bind(this), 0);
            }
        }, n = i, _possibleConstructorReturn(r, n);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "invokeTick",
        value: function() {
            this.endTime = Number(this.timeStamp) + new Date().getTime(), this.timer && clearInterval(this.timer), 
            this.timer = setInterval(this.tick.bind(this), Number(this.interval)), setTimeout(this.tick.bind(this), 0);
        }
    }, {
        key: "getFormatTime",
        value: function() {
            var e = +new Date(), t = this.endTime - e;
            return t < 0 && (t = 0), {
                formatTime: (0, _date.formatTime)(t, this.fmt, !0),
                delta: t
            };
        }
    }, {
        key: "tick",
        value: function() {
            if (!this.endTime) return void clearInterval(this.timer);
            var e = this.getFormatTime();
            this.time = e.formatTime, this.$emit("tick", e), 0 === e.delta && (clearInterval(this.timer), 
            this.$emit("end")), this.$apply();
        }
    }, {
        key: "onLoad",
        value: function() {
            this.timer = setInterval(this.tick.bind(this), Number(this.interval)), setTimeout(this.tick.bind(this), 0);
        }
    }, {
        key: "clearDownTime",
        value: function() {
            clearInterval(this.timer);
        }
    } ]), t;
}(_wepy2.default.component);

exports.default = CountDown;