function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _index = require("./../icon/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./../fixed/index.js"), _index4 = _interopRequireDefault(_index3), _path = require("./../../utils/path.js"), QuarkSearch = function(e) {
    function t() {
        var e, r, n, a;
        _classCallCheck(this, t);
        for (var i = arguments.length, o = Array(i), u = 0; u < i; u++) o[u] = arguments[u];
        return r = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(o))), 
        n.props = {
            type: {
                type: String,
                default: "search"
            },
            focus: {
                type: Boolean,
                default: !1
            },
            searchValue: {
                type: String,
                default: ""
            },
            hasSearch: {
                type: Boolean,
                default: !1
            },
            placeHolder: {
                type: String,
                default: ""
            }
        }, n.$repeat = {}, n.$props = {
            "Quark-icon1": {
                class: "search-svg {{type === 'home' ? 'home-search-svg' : ''}}",
                width: "36rpx",
                height: "36rpx",
                svg: "search"
            },
            "Quark-icon2": {
                width: "24rpx",
                height: "24rpx",
                svg: "cancel-grey"
            },
            FixedContainer: {
                class: "search-header {{type === 'home' ? 'home-header' : ''}}"
            }
        }, n.$events = {}, n.components = {
            "Quark-icon1": _index2.default,
            "Quark-icon2": _index2.default,
            FixedContainer: _index4.default
        }, n.methods = {
            handleInput: function(e) {
                var t = e.detail.value;
                this.searchValue = t, this.$emit("handleInput", t);
            },
            handleCancel: function(e) {
                this.$emit("handleCancel");
            },
            handleFocus: function(e) {
                var t = e.detail.value;
                this.$emit("handleFocus", t);
            },
            handleConfirm: function(e) {
                var t = e.detail.value;
                this.$emit("handleConfirm", t);
            },
            search: function() {
                this.$emit("handleSearch", this.searchValue);
            },
            goSearchPage: function() {
                this.$emit("goSearchPage");
            }
        }, a = r, _possibleConstructorReturn(n, a);
    }
    return _inherits(t, e), t;
}(_wepy2.default.component);

exports.default = QuarkSearch;