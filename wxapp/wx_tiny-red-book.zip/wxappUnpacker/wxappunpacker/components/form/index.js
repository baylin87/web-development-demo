function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _system = require("./../../services/system.js"), _enum = require("./../../utils/enum.js"), _track = require("./../../utils/track.js"), Form = function(e) {
    function t() {
        var e, r, o, i;
        _classCallCheck(this, t);
        for (var n = arguments.length, s = Array(n), a = 0; a < n; a++) s[a] = arguments[a];
        return r = o = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(s))), 
        o.props = {
            buttonClass: {
                type: String,
                default: ""
            },
            fromSource: {
                type: String,
                default: "default"
            },
            formData: {
                type: Object
            }
        }, o.data = {
            isTaped: !1
        }, o.methods = {
            reset: function() {
                this.isTaped = !1;
            },
            handleForm: function() {},
            submit: function(e) {
                var t = _wepy2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO), r = e.detail.formId;
                if (t = t || {}, this.isTaped || !t.sid || "the formId is a mock one" === r) return void this.$emit("submit", this.formData);
                this.isTaped = !0, (0, _system.collectFormId)(r), (0, _track.trackNormalData)({
                    action: "collect_form_id",
                    label: this.fromSource
                }), this.$emit("submit", this.formData);
            }
        }, i = r, _possibleConstructorReturn(o, i);
    }
    return _inherits(t, e), t;
}(_wepy2.default.component);

exports.default = Form;