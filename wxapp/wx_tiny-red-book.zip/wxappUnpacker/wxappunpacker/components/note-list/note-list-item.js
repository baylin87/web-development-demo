function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var a = t[r];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(t, r, a) {
        return r && e(t.prototype, r), a && e(t, a), t;
    };
}(), _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _path = require("./../../utils/path.js"), _enum = require("./../../utils/enum.js"), _track = require("./../../utils/track.js"), _icons = require("./../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), _eventBus = require("./../../libs/event-bus.js"), _eventBus2 = _interopRequireDefault(_eventBus), _debounce = require("./../../libs/debounce.js"), _debounce2 = _interopRequireDefault(_debounce), _user = require("./../../utils/user.js"), _user2 = _interopRequireDefault(_user), _index = require("./../form/index.js"), _index2 = _interopRequireDefault(_index), _avatar = require("./../note/avatar.js"), _avatar2 = _interopRequireDefault(_avatar), _system = require("./../../services/system.js"), NoteListItem = function(e) {
    function t() {
        var e, r, a, i;
        _classCallCheck(this, t);
        for (var o = arguments.length, n = Array(o), u = 0; u < o; u++) n[u] = arguments[u];
        return r = a = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(n))), 
        a.components = {
            MarcoAvatar: _avatar2.default,
            QuarkForm: _index2.default
        }, a.props = {
            item: Object,
            index: {
                type: Boolean,
                default: 0
            },
            canLike: {
                type: Boolean,
                default: !1
            }
        }, a.data = {
            isTaped: !1
        }, a.methods = {
            handleUserTap: function(e) {
                var t = this;
                (0, _debounce2.default)(function() {
                    var r = t.item || {}, a = _wepy2.default.getStorageSync("user_info"), i = (a.sid, 
                    r.user || {}), o = i.userid || i.id;
                    _user2.default.ensureLogin().then(function() {
                        t.collectFormId(e, "note_card_userinfo"), (0, _track.trackClick)({
                            label: "author_info",
                            property: o,
                            context: {},
                            timeStamp: new Date().getTime()
                        }), (0, _path.navigateTo)("AuthorPage", {
                            author_id: o
                        });
                    });
                }, 1e3, !0)();
            },
            handleNoteItemTap: function(e) {
                var t = this.item || {}, r = t.type, a = t.id, i = t.trackData, o = t.image;
                if (this.isTaped || this.collectFormId(e, "note_card"), this.isTaped = !0, r && a && i) {
                    try {
                        (0, _track.trackClick)(i);
                    } catch (e) {}
                    this.$emit("noteItemTap", {
                        type: r,
                        id: a
                    }), this.tapNoteItem({
                        type: r,
                        id: a,
                        trackData: i,
                        image: o
                    });
                }
            },
            handleGoInterestTap: function(e) {
                this.collectFormId(e, "note_card_interest"), (0, _path.navigateTo)("InterestCollectPage");
            },
            handleLikeTap: function(e) {
                if (!_wepy2.default.getStorageSync("user_info").sid) return void (0, _path.navigateTo)("LoginIndex");
                this.collectFormId(e, "note_card_like");
                var t = this.item || {}, r = t.id;
                (0, _track.trackClick)({
                    label: "note_card_like",
                    property: r,
                    context: {},
                    timeStamp: new Date().getTime()
                }), this.canLike ? _eventBus2.default.emit("likeTaped", r) : this.tapNoteItem(t);
            }
        }, i = r, _possibleConstructorReturn(a, i);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "collectFormId",
        value: function(e, t) {
            "the formId is a mock one" !== e.detail.formId && ((0, _track.trackNormalData)({
                action: "collect_form_id",
                label: t
            }), (0, _system.collectFormId)(e.detail.formId));
        }
    }, {
        key: "tapNoteItem",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.type, r = e.id, a = (e.trackData, 
            e.image);
            if (t === _enum.NOTE_TYPE.MULTI) return void console.log("[discover-note] non-supported note type " + t);
            var i = getCurrentPages();
            a = a || {};
            var o = a, n = o.width, u = o.height, s = 1, c = e.image && e.image.id ? e.image.id : "";
            n && u && (s = u / n), (10 === i.length ? _path.redirectTo : _path.navigateTo)("NoteDetail", {
                id: r,
                type: t,
                firstImageRatio: s,
                firstImageId: c
            });
        }
    } ]), t;
}(_wepy2.default.component);

exports.default = NoteListItem;