function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.REFRESH_FEEDS_NOTES_LENGTH = exports.PUSH_MORE_SCOLL_TOP = void 0;

var _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _index = require("./index.js"), _index2 = _interopRequireDefault(_index), PUSH_MORE_SCOLL_TOP = exports.PUSH_MORE_SCOLL_TOP = 2e3, REFRESH_FEEDS_NOTES_LENGTH = exports.REFRESH_FEEDS_NOTES_LENGTH = 100, ScrollFeeds = function(e) {
    function t() {
        var e, o, n, i;
        _classCallCheck(this, t);
        for (var r = arguments.length, s = Array(r), l = 0; l < r; l++) s[l] = arguments[l];
        return o = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(s))), 
        n.props = {
            notes: {
                type: Object,
                default: []
            },
            scrollTop: {
                type: Number,
                default: 0
            },
            isFirstLogin: {
                type: Boolean,
                default: !1
            },
            isNeverFillInRecommendTagForm: {
                type: Boolean,
                default: !1
            },
            canLike: {
                type: Boolean,
                default: !1
            }
        }, n.data = {
            isLoading: !1
        }, n.methods = {
            handleScroll: function(e) {
                this.$emit("scroll", e), this.notes.length > REFRESH_FEEDS_NOTES_LENGTH && this.$emit("cleanFeeds"), 
                e.detail.scrollHeight - e.detail.scrollTop < PUSH_MORE_SCOLL_TOP ? this.isLoading || (this.isLoading = !0, 
                this.$emit("pushMoreFeeds")) : this.isLoading = !1;
            },
            handleScrollToLower: function() {
                this.$emit("pushMoreFeeds");
            }
        }, n.$repeat = {}, n.$props = {
            NoteList: {
                "xmlns:wx": "",
                "xmlns:v-bind": "",
                "v-bind:notes.sync": "notes",
                "v-bind:isFirstLogin.sync": "isFirstLogin",
                "v-bind:isNeverFillInRecommendTagForm.sync": "isNeverFillInRecommendTagForm",
                "v-bind:canLike.sync": "canLike"
            }
        }, n.$events = {}, n.components = {
            NoteList: _index2.default
        }, i = o, _possibleConstructorReturn(n, i);
    }
    return _inherits(t, e), t;
}(_wepy2.default.component);

exports.default = ScrollFeeds;