function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function getDoubleColumnNotes() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    if (!e.length) return {
        leftNotes: [],
        rightNotes: []
    };
    var o = [], n = [], r = 0, s = 0;
    return e.forEach(function(e) {
        var t = void 0;
        e.trackData = JSON.stringify({
            label: "note_card",
            property: e.id,
            context: {},
            timeStamp: new Date().getTime()
        }), e.image && e.image.url && (e.image.id = (0, _image.getImageId)(e.image.url), 
        e.image.url = (0, _image.getFormatedUrl)({
            url: e.image.url,
            width: 300,
            quality: 85
        })), e.title ? e.title = (0, _discovery.getNoTagNoFaceIconText)(e.title) : e.title = (0, 
        _discovery.getNoTagNoFaceIconText)(e.desc), t = e.videoInfo ? e.videoInfo.height / e.videoInfo.width : e.image.height / e.image.width, 
        s < r ? (s += t, n.push(e)) : (r += t, o.push(e));
    }), !t && i && o.splice(2, 0, {
        type: "interest",
        image: {
            width: 750,
            height: 352,
            url: (0, _icons.getIconUrl)(_icons2.default.interestCover)
        },
        firTitle: "选择感兴趣的内容",
        secTitle: "定制你的小红书"
    }), {
        leftNotes: o,
        rightNotes: n
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.mapPage = exports.createData = exports.NOTE_TYPE = exports.DEFAULT_DATA = void 0;

var _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _noteListItem = require("./note-list-item.js"), _noteListItem2 = _interopRequireDefault(_noteListItem), _enum = require("./../../utils/enum.js"), _string = require("./../../utils/string.js"), _page = require("./../../utils/page.js"), _image = require("./../../utils/image.js"), _discovery = require("./../../utils/discovery.js"), _icons = require("./../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), DEFAULT_META = {}, DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    notes: []
});

exports.NOTE_TYPE = _enum.NOTE_TYPE;

var createData = exports.createData = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    e || console.log("[note-list] could not found notes array");
    var i = e.map(function(e) {
        return Object.assign(e, {
            title: (0, _string.escapeNoteString)(e.title),
            desc: (0, _string.escapeNoteString)(e.desc)
        });
    });
    return Object.assign({}, DEFAULT_DATA, t, {
        notes: i
    });
}, mapPage = exports.mapPage = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments[1], i = arguments[2], o = i.page, n = i.pageSize, r = (0, 
    _page.mapPage)(e.notes, t.notes, {
        page: o,
        pageSize: n
    }), s = r.list, a = r.pagination;
    return Object.assign({}, t, {
        notes: s,
        pagination: a
    });
}, NoteList = function(e) {
    function t() {
        var e, i, o, n;
        _classCallCheck(this, t);
        for (var r = arguments.length, s = Array(r), a = 0; a < r; a++) s[a] = arguments[a];
        return i = o = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(s))), 
        o.props = {
            notes: {
                type: Object,
                default: []
            },
            isFirstLogin: {
                type: Boolean,
                default: !1
            },
            isNeverFillInRecommendTagForm: {
                type: Boolean,
                default: !1
            },
            canLike: {
                type: Boolean,
                default: !1
            }
        }, o.data = {
            isLoading: !1
        }, o.computed = {
            doubleColumnNotes: function() {
                return getDoubleColumnNotes(this.notes, this.isFirstLogin, this.isNeverFillInRecommendTagForm);
            }
        }, o.methods = {}, o.$repeat = {
            doubleColumnNotes: {
                com: "NoteListRightItem",
                props: "item.sync"
            }
        }, o.$props = {
            NoteListLeftItem: {
                "xmlns:v-bind": {
                    value: "",
                    for: "doubleColumnNotes.leftNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                },
                "v-bind:item.sync": {
                    value: "item",
                    type: "item",
                    for: "doubleColumnNotes.leftNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                },
                "v-bind:index.sync": {
                    value: "index",
                    type: "index",
                    for: "doubleColumnNotes.leftNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                },
                "v-bind:canLike.sync": {
                    value: "canLike",
                    for: "doubleColumnNotes.leftNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                }
            },
            NoteListRightItem: {
                "v-bind:item.sync": {
                    value: "item",
                    type: "item",
                    for: "doubleColumnNotes.rightNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                },
                "v-bind:index.sync": {
                    value: "index",
                    type: "index",
                    for: "doubleColumnNotes.rightNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                },
                "v-bind:canLike.sync": {
                    value: "canLike",
                    for: "doubleColumnNotes.rightNotes",
                    item: "item",
                    index: "index",
                    key: "index"
                }
            }
        }, o.$events = {}, o.components = {
            NoteListLeftItem: _noteListItem2.default,
            NoteListRightItem: _noteListItem2.default
        }, n = i, _possibleConstructorReturn(o, n);
    }
    return _inherits(t, e), t;
}(_wepy2.default.component);

exports.default = NoteList;