function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var o = 0; o < t.length; o++) {
            var n = t[o];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, o, n) {
        return o && e(t.prototype, o), n && e(t, n), t;
    };
}(), _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _path = require("./../../utils/path.js"), _icons = require("./../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), _follow = require("./../../mixins/follow.js"), _follow2 = _interopRequireDefault(_follow), UserListItem = function(e) {
    function t() {
        var e, o, n, r;
        _classCallCheck(this, t);
        for (var i = arguments.length, s = Array(i), a = 0; a < i; a++) s[a] = arguments[a];
        return o = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(s))), 
        n.config = {}, n.mixins = [ _follow2.default ], n.components = {}, n.props = {
            item: Object
        }, n.data = {
            officalVerified: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
        }, n.watch = {}, n.methods = {
            handleTapItem: function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: this.item.userid
                });
            },
            handleTriggleFollow: function() {
                var e = wx.getStorageSync("user_info"), t = e.appUserId;
                t ? t === this.item.userid ? wx.showToast({
                    title: "不能关注自己",
                    icon: "none"
                }) : this.handleFollow(this.item) : wx.showToast({
                    title: "请先登录",
                    icon: "none"
                });
            },
            handleAvatarError: function() {
                this.item.images = "https://ci.xiaohongshu.com/4dbf6dd3-7611-4625-90f3-91928fe0e4b0";
            }
        }, n.events = {}, r = o, _possibleConstructorReturn(n, r);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {}
    }, {
        key: "onShow",
        value: function() {}
    }, {
        key: "onPullDownRefresh",
        value: function() {}
    }, {
        key: "onReachBottom",
        value: function() {}
    }, {
        key: "onShareAppMessage",
        value: function() {}
    } ]), t;
}(_wepy2.default.component);

exports.default = UserListItem;