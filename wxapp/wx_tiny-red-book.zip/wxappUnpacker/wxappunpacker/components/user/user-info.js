function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function formatNum() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    return e >= 1e4 ? (e = Math.round(10 * (e / 1e4).toFixed(1)) / 10) + "万" : e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _index = require("./../note-list/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./../icon/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("./../loading/index.js"), _index6 = _interopRequireDefault(_index5), _index7 = require("./../not-found/index.js"), _index8 = _interopRequireDefault(_index7), _track = require("./../../utils/track.js"), _path = require("./../../utils/path.js"), _icons = require("./../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), _user = require("./../../utils/user.js"), _user2 = _interopRequireDefault(_user), CDN_ORIGIN = "https://ci.xiaohongshu.com", isIPhoneX = _wepy2.default.$instance.globalData.isIPhoneX, UserInfo = function(e) {
    function t() {
        var e, n, i, o;
        _classCallCheck(this, t);
        for (var r = arguments.length, a = Array(r), s = 0; s < r; s++) a[s] = arguments[s];
        return n = i = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        i.props = {
            noteList: [],
            userInfo: {},
            switchTab: {
                type: String,
                default: "notes"
            },
            isFetching: {
                type: Boolean,
                default: !1
            },
            isFetchEnd: {
                type: Boolean,
                default: !1
            }
        }, i.data = {
            type: "red",
            text: "加载中",
            listType: "anthor",
            isIPhoneX: !1,
            canLike: !0,
            defaultImage: CDN_ORIGIN + "/8c47df99-484e-448d-9226-430e46641d53",
            isLogin: !1,
            noFoundImg: CDN_ORIGIN + "/6f3fecd4-4282-4448-81a6-af6c26dbc10b"
        }, i.$repeat = {}, i.$props = {
            NoteList: {
                "v-bind:notes.sync": "noteList",
                "v-bind:canLike.sync": "canLike"
            },
            QuarkIcon: {
                class: "arrow-right",
                width: "8rpx",
                height: "12rpx",
                svg: "arrow-right"
            },
            Loading: {
                "v-bind:type.sync": "type",
                "v-bind:text.sync": "text",
                class: "loading"
            },
            "Quark-x-not-found": {
                "xmlns:v-bind": "",
                "v-bind:type.sync": "listType"
            }
        }, i.$events = {}, i.components = {
            NoteList: _index2.default,
            QuarkIcon: _index4.default,
            Loading: _index6.default,
            "Quark-x-not-found": _index8.default
        }, i.computed = {
            likedAndCollected: function() {
                var e = this.userInfo || {};
                return formatNum(e.liked + e.collected) || 0;
            },
            fansNum: function() {
                return formatNum((this.userInfo || {}).fans);
            },
            genderIcon: function() {
                return 1 == (this.userInfo || {}).gender ? CDN_ORIGIN + "/" + _icons2.default.genderFemaleIcon : CDN_ORIGIN + "/" + _icons2.default.genderMaleIcon;
            }
        }, i.methods = {
            handleTapSwitchTab: function(e, t) {
                this.isLogin && ((0, _track.trackNormalData)({
                    action: "switchTab",
                    property: e
                }), this.listType = "collect" === e ? "collect" : "anthor", this.$emit("tapSwitchTab", e));
            },
            handleTapSettings: function() {
                if (!this.isLogin) return void (0, _path.navigateTo)("LoginIndex");
                (0, _track.trackClick)({
                    label: "settings",
                    context: {},
                    timeStamp: new Date().getTime()
                }), (0, _path.navigateTo)("SETTINGS");
            },
            handleTapFollowings: function() {
                this.isLogin && ((0, _track.trackClick)({
                    label: "followings",
                    context: {},
                    timeStamp: new Date().getTime()
                }), (0, _path.navigateTo)("FOLLOWINGS", {
                    authorId: this.userInfo.userid
                }));
            },
            handleTapFollowers: function() {
                this.isLogin && ((0, _track.trackClick)({
                    label: "followers",
                    context: {},
                    timeStamp: new Date().getTime()
                }), (0, _path.navigateTo)("FOLLOWERS", {
                    authorId: this.userInfo.userid
                }));
            },
            handleImageError: function() {
                this.userInfo.images = this.defaultImage;
            },
            handleToLogin: function() {
                (0, _path.navigateTo)("LoginIndex");
            },
            handleTapUserImage: function() {
                if (!this.isLogin) return void (0, _path.navigateTo)("LoginIndex");
            }
        }, o = n, _possibleConstructorReturn(i, o);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            this.isIPhoneX = isIPhoneX, this.isLogin = _user2.default.checkLogin(), this.$apply();
        }
    } ]), t;
}(_wepy2.default.component);

exports.default = UserInfo;