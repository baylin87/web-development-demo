function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _path = require("./../../utils/path.js"), _icons = require("./../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), _follow = require("./../../mixins/follow.js"), _follow2 = _interopRequireDefault(_follow), _tracker = require("./../../services/tracker.js"), OneBox = function(e) {
    function t() {
        var e, o, n, r;
        _classCallCheck(this, t);
        for (var i = arguments.length, l = Array(i), a = 0; a < i; a++) l[a] = arguments[a];
        return o = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(l))), 
        n.props = {
            noteOnebox: {
                type: Object,
                default: {}
            }
        }, n.data = {
            officalVerified: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
        }, n.mixins = [ _follow2.default ], n.methods = {
            handleTapTopic: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                _tracker.wxTrack.call(this, {
                    action: "onebox-tap",
                    label: "onebox-block",
                    property: e.id
                }), (0, _path.navigateTo)("Webview", {
                    link: e.link
                });
            },
            handleTriggleFollow: function() {
                this.handleFollow(this.noteOnebox.onebox);
            },
            handleTapItem: function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: this.noteOnebox.onebox.id
                });
            }
        }, r = o, _possibleConstructorReturn(n, r);
    }
    return _inherits(t, e), t;
}(_wepy2.default.component);

exports.default = OneBox;