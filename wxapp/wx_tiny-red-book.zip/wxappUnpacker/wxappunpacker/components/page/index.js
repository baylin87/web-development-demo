function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var a = 0; a < t.length; a++) {
            var i = t[a];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, a, i) {
        return a && e(t.prototype, a), i && e(t, i), t;
    };
}(), _wepy = require("./../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _addMpToast = require("./../toast/add-mp-toast.js"), _addMpToast2 = _interopRequireDefault(_addMpToast), _path = require("./../../utils/path.js"), _track = require("./../../utils/track.js"), _enum = require("./../../utils/enum.js"), _page = require("./../../utils/page.js"), _datetime = require("./../../utils/datetime.js"), _user = require("./../../utils/user.js"), _user2 = _interopRequireDefault(_user), NavigationBar = function(e) {
    function t() {
        var e, a, i, n;
        _classCallCheck(this, t);
        for (var o = arguments.length, r = Array(o), s = 0; s < o; s++) r[s] = arguments[s];
        return a = i = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(r))), 
        i.props = {
            type: {
                type: String,
                default: ""
            },
            navigationBarConfig: {
                type: Object
            },
            pageConfig: {
                type: Object,
                default: {}
            }
        }, i.computed = {
            leftSideInnerClass: function() {
                var e = "";
                switch (this.type) {
                  case "defeat":
                    e = "back-defeat";
                    break;

                  case "white":
                    e = "back-white";
                    break;

                  default:
                    e = "back-defeat";
                }
                return e;
            },
            navIconContainerClass: function() {
                var e = "";
                switch (this.type) {
                  case "defeat":
                    e = "back-icon-container-defeat";
                    break;

                  case "white":
                    e = "back-icon-container--white";
                    break;

                  default:
                    e = "back-icon-container-defeat";
                }
                return e;
            }
        }, i.watch = {
            navigationBarConfig: function(e) {
                this.setNavigationBar(e), this.$apply();
            }
        }, i.$repeat = {}, i.$props = {
            AddMpToast: {
                "xmlns:v-bind": "",
                "v-bind:addMyMp.sync": "addMyMp",
                "xmlns:v-on": ""
            }
        }, i.$events = {
            AddMpToast: {
                "v-on:closeAddMyMp": "handleCloseAddMyMp"
            }
        }, i.components = {
            AddMpToast: _addMpToast2.default
        }, i.data = {
            title: "",
            isIphoneX: !1,
            navigationBarTrueHeight: (0, _page.getTopSectionHeight)(),
            navigationBarStyles: "",
            navigationBarIconsNum: 0,
            canUseCustomNavigationBar: !0,
            noShowNavigationBar: !1,
            showBackIcon: !1,
            showHomePageIcon: !1,
            pageContentClass: "",
            pageContentStyle: "",
            pageContainerClass: "",
            pageContentMinHeight: 0,
            leftSideInnerStyle: "",
            addMyMp: {
                hasClose: !1,
                isShowAddMp: !1
            },
            backPage: ""
        }, i.methods = {
            handleCloseAddMyMp: function() {
                this.addMyMp.isShowAddMp = !1;
            },
            handleGoLastPage: function() {
                this.backPage ? ((0, _track.trackNormalData)({
                    action: "navigate_back_another_page"
                }), "HOME" === this.backPage || "HomePage" === this.backPage ? (0, _path.switchTab)(this.backPage, {
                    isSpecifiedPath: !0
                }) : (0, _path.navigateTo)(this.backPage, {
                    isSpecifiedPath: !0
                })) : (this.$emit("navigateBack"), (0, _track.trackNormalData)({
                    action: "navigate_back"
                }), (0, _path.navigateBack)());
            },
            handleHomePage: function() {
                this.$emit("switchHomePage"), (0, _track.trackNormalData)({
                    action: "navigate_home_page"
                }), (0, _path.switchTab)("HomePage");
            }
        }, n = a, _possibleConstructorReturn(i, n);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "setNavigationBar",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = (0, 
            _path.getPageUrl)(), a = 0;
            this.showHomePageIcon = (0, _page.isShowHomePage)(t.route), this.showBackIcon && (a += 1), 
            e.hideHomePageIcon && (this.showHomePageIcon = !1), this.showHomePageIcon && (a += 1), 
            this.navigationBarIconsNum = a, e.titleText && (this.title = e.titleText, wx.setNavigationBarTitle({
                title: e.titleText
            })), e.backPagePath && (this.backPage = e.backPagePath);
            var i = "#ff2741", n = "#ffffff";
            e.backgroundColor && (i = e.backgroundColor);
            var o = {
                black: "#000000",
                white: "#ffffff"
            };
            o[e.textStyle] && (n = o[e.textStyle]);
            var r = (0, _page.getTrueStatusBarHeight)();
            this.navigationBarStyles = "color: " + n + ";background-color: " + i + ";padding-top: " + r + "px;", 
            wx.setNavigationBarColor && wx.setNavigationBarColor({
                frontColor: n,
                backgroundColor: i
            });
        }
    }, {
        key: "initPageScrollEvent",
        value: function() {
            var e = this, t = this.$parent, a = t.onPageScroll || null;
            t.onPageScroll = function(i) {
                a && a.call(t, i), e.checkAddMyMp();
            };
        }
    }, {
        key: "checkAddMyMp",
        value: function() {
            this.addMyMp.isShowAddMp && !this.addMyMp.hasClose && (this.addMyMp.isShowAddMp = !1, 
            this.$apply());
        }
    }, {
        key: "initAddMyMp",
        value: function() {
            var e = this, t = wx.getStorageSync(_enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG), a = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {}, i = a.isNewWxmpUser, n = new Date().getTime();
            if (!t) return t = n, this.addMyMp.isShowAddMp = !0, i ? this.addMyMp.hasClose = !0 : setTimeout(function() {
                e.addMyMp.isShowAddMp = !1, e.$apply();
            }, 3e3), void wx.setStorage({
                key: _enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG,
                data: t
            });
            t && n - t > (0, _datetime.getTimeStampByDay)(7) && (this.addMyMp.isShowAddMp = !0, 
            i ? (this.addMyMp.hasClose = !0, a.isNewWxmpUser = !1, _user2.default.setUserInfo(a)) : setTimeout(function() {
                e.addMyMp.isShowAddMp = !1, e.$apply();
            }, 3e3), t = n, wx.setStorage({
                key: _enum.STORAGE_KEY.PIN_MINI_PROGRAM_FLAG,
                data: t
            }));
        }
    }, {
        key: "onLoad",
        value: function() {
            var e = (0, _page.getSystemInfo)(), t = "android" === e.platform, a = function(t) {
                return t * e.screenWidth / 750;
            };
            this.initPageScrollEvent(), this.isIphoneX = _wepy2.default.$instance.globalData.isIPhoneX;
            var i = (0, _page.getNavigationBarInfo)(), n = getCurrentPages();
            this.showBackIcon = n.length > 1, this.canUseCustomNavigationBar = i.canCustom, 
            this.noShowNavigationBar = i.noShow;
            this.canUseCustomNavigationBar && this.noShowNavigationBar && (this.navigationBarTrueHeight = 0), 
            this.pageContentClass = "", this.pageContainerClass = " ready", this.isIphoneX && this.canUseCustomNavigationBar && this.noShowNavigationBar && (this.navigationBarTrueHeight = (0, 
            _page.getTopSectionHeight)()), this.setNavigationBar(this.navigationBarConfig), 
            this.pageContentMinHeight = e.screenHeight - (e.screenHeight - e.windowHeight) - this.navigationBarTrueHeight + "px", 
            this.$emit("pageSizeInfo", {
                contentViewHeight: this.pageContentMinHeight
            });
            var o = a(64) - 2, r = a(174) - 2;
            t && (o -= 1, r -= 1), o += "px", r += "px", this.leftSideInnerStyle = "height: " + o + ";max-width: " + r + ";";
            var s = [ "min-height: " + this.pageContentMinHeight ];
            if (this.pageConfig.fullScreen) {
                var h = (0, _page.getTrueFullScreenHeight)();
                s.push("padding-top: " + this.navigationBarTrueHeight + "px"), s.push("height: " + h + "px");
            } else s.push("margin-top: " + this.navigationBarTrueHeight + "px");
            this.pageContentStyle = s.join(";"), this.initAddMyMp(), this.$apply();
        }
    } ]), t;
}(_wepy2.default.component);

exports.default = NavigationBar;