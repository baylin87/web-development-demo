function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function a(o, r) {
                try {
                    var i = t[o](r), s = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    a("next", e);
                }, function(e) {
                    a("throw", e);
                });
                e(s);
            }
            return a("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function canLaunchApp(e) {
    return (e === _enum.SHARE_MEESAGE_SCENE || e === _enum.MAIN_CHAT_SCENE || e === _enum.HISTORY_SCENE) && e === _enum.SHARE_MEESAGE_SCENE;
}

function updateProgram() {
    _api2.default.getSystemInfo({
        success: function(e) {
            var t = e.SDKVersion;
            if ((0, _string.compareVersion)(t, "1.9.91") >= 0) {
                var n = wx.getUpdateManager();
                n.onCheckForUpdate(function(e) {
                    e.hasUpdate && (n.onUpdateReady(function() {
                        wx.showModal({
                            title: "更新提示",
                            content: "新版本已经准备好，是否重启应用？",
                            success: function(e) {
                                e.confirm && n.applyUpdate();
                            }
                        });
                    }), n.onUpdateFailed(function() {
                        wx.showToast({
                            title: "新版本下载失败",
                            icon: "none",
                            duration: 2e3
                        });
                    }));
                });
            }
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(t, n, a) {
        return n && e(t.prototype, n), a && e(t, a), t;
    };
}(), _wepy = require("./npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy);

require("./npm/wepy-async-function/index.js");

var _http = require("./http.config.js"), _routes = require("./routes.js"), _http2 = require("./utils/http.js"), _user = require("./utils/user.js"), _user2 = _interopRequireDefault(_user), _track = require("./utils/track.js"), _path = require("./utils/path.js"), _api = require("./utils/api.js"), _api2 = _interopRequireDefault(_api), _abTest = require("./utils/ab-test.js"), _abTest2 = _interopRequireDefault(_abTest), _interval = require("./utils/interval.js"), _enum = require("./utils/enum.js"), _auth = require("./utils/auth.js"), _page = require("./utils/page.js"), _string = require("./utils/string.js"), SMSdk = require("./libs/fp.js"), debug = !1;

(0, _http2.configure)({
    baseURL: debug ? _http.config.BASE_URL.development : _http.config.BASE_URL.production,
    apiList: _http.config.API_LIST
}), SMSdk.initConf({
    organization: "eR46sBuqF0fdw7KWFLYa",
    channel: "miniProgram"
});

var _default = function(e) {
    function t() {
        _classCallCheck(this, t);
        var e = _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        return e.config = {
            pages: function() {
                return global.__AppConfig && global.__AppConfig.Main ? global.__AppConfig.Main : [];
            }(),
            subPackages: [ {
                root: "pages/common/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.Common ? global.__AppConfig.Common : [];
                }()
            }, {
                root: "pages/secondary/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.Secondary ? global.__AppConfig.Secondary : [];
                }()
            }, {
                root: "pages/fulishe/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.Fulishe ? global.__AppConfig.Fulishe : [];
                }()
            }, {
                root: "main/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.OldMain ? global.__AppConfig.OldMain : [];
                }()
            }, {
                root: "fulishe/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.OldFulishe ? global.__AppConfig.OldFulishe : [];
                }()
            }, {
                root: "activity/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.Activity ? global.__AppConfig.Activity : [];
                }()
            }, {
                root: "community/",
                pages: function() {
                    return global.__AppConfig && global.__AppConfig.OldCommunity ? global.__AppConfig.OldCommunity : [];
                }()
            } ],
            preloadRule: {
                "pages/main/home/index": {
                    network: "wifi",
                    packages: [ "pages/common/", "pages/secondary/" ]
                },
                "pages/main/note/index": {
                    network: "wifi",
                    packages: [ "pages/common/", "pages/secondary/" ]
                }
            },
            window: {
                navigationBarBackgroundColor: "#FFFFFF",
                navigationBarTextStyle: "black",
                navigationBarTitleText: "小红书",
                backgroundColor: "#FFF",
                backgroundTextStyle: "light",
                navigationStyle: "custom",
                enablePullDownRefresh: !1,
                onReachBottomDistance: 600
            },
            tabBar: {
                borderStyle: "white",
                selectedColor: "#333333",
                backgroundColor: "#FFFFFF",
                color: "#999999",
                list: [ {
                    pagePath: "pages/main/home/index",
                    text: "首页",
                    iconPath: "assets/images/tab-home.png",
                    selectedIconPath: "assets/images/tab-home-selected.png"
                }, {
                    pagePath: "pages/main/store/index",
                    text: "商城",
                    iconPath: "assets/images/tab-store.png",
                    selectedIconPath: "assets/images/tab-store-selected.png"
                }, {
                    pagePath: "pages/main/mine/index",
                    text: "我的",
                    iconPath: "assets/images/tab-mine.png",
                    selectedIconPath: "assets/images/tab-mine-selected.png"
                } ]
            },
            networkTimeout: {
                request: 1e4,
                downloadFile: 1e4
            },
            debug: !0,
            navigateToMiniProgramAppIdList: [ "wx4554c1e6dfadc8ed" ]
        }, e.globalData = {
            promise: null,
            canLaunchApp: !1,
            launchOps: null,
            scene: null,
            navigateToLoginPageCount: 0,
            navigateToLoginPageTime: null,
            isIPhoneX: !1,
            isLongScreen: !1,
            isIOS: !0,
            systemInfo: {},
            SMSdk: SMSdk
        }, e.use("requestfix"), e.use("promisify"), e;
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onPageNotFound",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.path, n = e.query, a = (e.isEntryPage, 
            function() {
                (0, _path.redirectTo)("NotFound");
            });
            (0, _track.trackNormalData)({
                action: "page_not_found",
                property: t
            });
            var o = JSON.parse(JSON.stringify(n)), r = (0, _routes.getCategoryByoldRoute)(t);
            if (r.category) {
                var i = r.isSwitchTab ? _path.switchTab : _path.redirectTo, s = r.isSwitchTab ? void 0 : o;
                a = function() {
                    i(r.category, s);
                };
            } else (0, _track.trackNormalData)({
                action: "page_not_found_failure",
                property: t
            });
            setTimeout(function() {
                a();
            }, 200);
        }
    }, {
        key: "onLaunch",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                var n, a, o, r, i, s, u, l, p, c;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = _user2.default.getUserInfo(), a = n.sid, o = n.isNewWxmpUser, r = n.appUserInfo, 
                        i = r || {}, s = i.isAppUser, a ? (this.globalData.promise = new Promise(function(e) {
                            return e();
                        }), o && (n.isNewWxmpUser = !1, _user2.default.setUserInfo(n))) : this.globalData.promise = new Promise(function(e) {
                            _user2.default.loginWithCode({
                                noAutoGoToLogin: !0
                            }).then(function() {
                                _abTest2.default.init(), e();
                            }).catch(function() {
                                e();
                            });
                        }), u = t.scene, this.globalData.launchOps = t, this.globalData.scene = u, this.globalData.canLaunchApp = canLaunchApp(u), 
                        (0, _auth.refreshTokenRegister)(), _http2.interceptors.response.use(function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            return void 0 !== e.result && -1 === [ 0, -100 ].indexOf(e.result) && (0, _track.trackNormalData)({
                                action: "response_error",
                                property: e.requestUrl,
                                label: "result_" + e.result
                            }), -100 === e.result && _user2.default.loginWithCode().then(function() {
                                _user2.default.ensureLogin().then(function() {
                                    _api2.default.reLaunch({
                                        url: "/" + (0, _path.getPageUrl)().url
                                    });
                                });
                            }), e;
                        }), _http2.interceptors.request.use(function(e) {
                            var t = _user2.default.getUserInfo(), n = t.sid, a = !1;
                            return _http.NO_SID_API_LIST.some(function(t) {
                                if (e.url.indexOf(t) > -1) return a = !0, !0;
                            }), a ? e : (n && (e.params ? e.params.sid = n : (e.params = {}, e.params.sid = n)), 
                            e);
                        }), _abTest2.default.init(), l = _api2.default.getStorageSync(_enum.STORAGE_KEY.NEWBIE_FLAG)) {
                            e.next = 16;
                            break;
                        }
                        return e.next = 16, _api2.default.setStorage({
                            key: _enum.STORAGE_KEY.NEWBIE_FLAG,
                            data: {
                                hintTapAvatarMine: !0,
                                hintTapAvatarNote: !0
                            }
                        });

                      case 16:
                        p = this, _api2.default.getSystemInfo({
                            success: function(e) {
                                p.globalData.isLongScreen = (0, _page.getScreenRatio)(), p.globalData.isIPhoneX = e.model.search("iPhone X") >= 0, 
                                p.globalData.isIOS = e.system.search("iOS") >= 0, p.globalData.systemInfo = e;
                            }
                        }), (0, _track.trackNormalData)({
                            action: "miniprogram_launch",
                            sourceRoute: t.path,
                            sourceScene: t.scene
                        }), c = _wepy2.default.getStorageSync(_enum.STORAGE_KEY.CAN_SHOW_FULL_ADD_MP), "boolean" != typeof c && _wepy2.default.setStorage({
                            key: _enum.STORAGE_KEY.CAN_SHOW_FULL_ADD_MP,
                            data: !0
                        }), updateProgram();

                      case 22:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onError",
        value: function(e) {
            (0, _track.trackError)(e);
        }
    }, {
        key: "onShow",
        value: function(e) {
            this.globalData.launchOps = e;
            var t = (e.path, e.query, e.scene);
            this.globalData.scene = t, this.globalData.canLaunchApp = canLaunchApp(t), (0, _track.trackNormalData)({
                action: "miniprogram_show",
                sourceRoute: e.path,
                sourceScene: e.scene
            });
        }
    }, {
        key: "onHide",
        value: function() {
            (0, _track.trackNormalData)({
                action: "miniprogram_hide"
            });
        }
    } ]), t;
}(_wepy2.default.app);

App(require("./npm/wepy/lib/wepy.js").default.$createApp(_default, {
    noPromiseAPI: [ "createSelectorQuery" ]
}));