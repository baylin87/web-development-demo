function getSearchFromKeyword(e) {
    var r = e.sid, t = e.keyword, o = e.pagination;
    return (0, _http.get)("SEARCH_USERS_FROM_KEYWORD", {
        transform: !0,
        params: {
            sid: r,
            keyword: t,
            page: o.page,
            rows: o.pageSize
        }
    });
}

function followUser(e) {
    var r = e.userId;
    return (0, _http.get)("FOLLOW", {
        params: {
            oid: r
        },
        transform: !0
    });
}

function unfollowUser(e) {
    var r = e.userId;
    return (0, _http.get)("UNFOLLOW", {
        params: {
            oid: r
        },
        transform: !0
    });
}

function getFollowings(e) {
    var r = e.userId, t = e.start, o = void 0 === t ? "" : t;
    return (0, _http.get)("SNS_USER_FOLLOWINGS", {
        resourceParams: {
            id: r
        },
        params: {
            start: o
        },
        transform: !0
    });
}

function getFollowers(e) {
    var r = e.userId, t = e.start, o = void 0 === t ? "" : t;
    return (0, _http.get)("SNS_USER_FOLLOWERS", {
        resourceParams: {
            id: r
        },
        params: {
            start: o
        },
        transform: !0
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.mapPage = exports.DEFAULT_DATA = void 0, exports.getSearchFromKeyword = getSearchFromKeyword, 
exports.followUser = followUser, exports.unfollowUser = unfollowUser, exports.getFollowings = getFollowings, 
exports.getFollowers = getFollowers;

var _http = require("./../utils/http.js"), _page = require("./../utils/page.js"), DEFAULT_META = {}, DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    users: []
}), mapPage = exports.mapPage = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments[1], t = arguments[2], o = t.page, s = t.pageSize, a = (0, 
    _page.mapPage)(e.users, r.users, {
        page: o,
        pageSize: s
    });
    return {
        users: a.list,
        pagination: a.pagination
    };
};