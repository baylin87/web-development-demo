function _asyncToGenerator(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(a, o) {
                try {
                    var s = r[a](o), u = s.value;
                } catch (e) {
                    return void t(e);
                }
                if (!s.done) return Promise.resolve(u).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(u);
            }
            return n("next");
        });
    };
}

function getHot() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.num, t = void 0 === r ? 4 : r;
    return (0, _http.get)("HOT", {
        params: {
            num: t
        }
    }).then(parseSearchResult);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.search = exports.searchAuto = exports.TRENDING_TYPE = void 0;

var searchAuto = exports.searchAuto = function() {
    var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = r.keyword, n = void 0 === t ? "" : t, a = r.num, o = void 0 === a ? 3 : a;
        return regeneratorRuntime.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (n) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", new Error("must provide keyword to searchAuto"));

              case 2:
                return e.abrupt("return", (0, _http.get)("SEARCH", {
                    params: {
                        keyword: n,
                        page: 1,
                        page_size: o
                    }
                }).then(parseSearchResult));

              case 3:
              case "end":
                return e.stop();
            }
        }, e, this);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}(), search = exports.search = function() {
    var e = _asyncToGenerator(regeneratorRuntime.mark(function e(r) {
        var t = r.keyword, n = r.type, a = r.pagination, o = void 0 === a ? _page.DEFAULT_PAGINATION_ARGS : a;
        return regeneratorRuntime.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", new Error("must provide keyword to searchFull"));

              case 2:
                return e.abrupt("return", (0, _http.get)("SEARCH", {
                    params: {
                        keyword: t,
                        type: n,
                        page: o.page,
                        page_size: o.pageSize
                    }
                }).then(parseSearchResult));

              case 3:
              case "end":
                return e.stop();
            }
        }, e, this);
    }));
    return function(r) {
        return e.apply(this, arguments);
    };
}();

exports.getHot = getHot;

var _http = require("./../utils/http.js"), _page = require("./../utils/page.js"), TRENDING_TYPE = exports.TRENDING_TYPE = {
    SEARCH: "search_trending",
    GOODS: "goods_trending"
}, searchResultKeyMap = {
    trending_data: "searchTrending",
    search_trending: "searchTrending",
    goods_trending: "goodsTrending"
}, parseSearchResult = function(e) {
    var r = {};
    return Object.keys(e).forEach(function(t) {
        var n = t;
        searchResultKeyMap[t] && (n = searchResultKeyMap[t]), r[n] = e[t];
    }), r;
};