function getSearchFromKeyword(e) {
    var r = e.sid, o = e.keyword, t = e.pagination, s = e.sort, n = void 0 === s ? "general" : s;
    return (0, _http.get)("SEARCH_NOTES_FROM_KEYWORD", {
        transform: !0,
        params: {
            sid: r,
            keyword: o,
            sort: n,
            page: t.page,
            perPage: t.pageSize
        }
    }).then(parseSearchFromKeyword);
}

function getTopicFromKeyword(e) {
    var r = e.keyword;
    return (0, _http.get)("SEARCH_TOPIC", {
        transform: !0,
        params: {
            keyword: r
        }
    }).then(parseTopicFromKeyword);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createData = exports.mapPage = exports.DEFAULT_DATA = void 0, exports.getSearchFromKeyword = getSearchFromKeyword, 
exports.getTopicFromKeyword = getTopicFromKeyword;

var _http = require("./../utils/http.js"), _page = require("./../utils/page.js"), _string = require("./../utils/string.js"), DEFAULT_META = {}, DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    notes: []
}), parseSearchFromKeyword = function(e) {
    var r = e.notes.slice(), o = [];
    return r.forEach(function(e) {
        o.push({
            id: e.id,
            image: e.imagesList[0],
            title: e.title,
            desc: e.desc,
            likes: e.likes,
            user: e.user,
            type: e.type,
            inlikes: e.inlikes
        });
    }), {
        totalCount: e.totalCount,
        notes: o
    };
}, parseOneboxString = function() {
    return (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "").replace(/·/g, " | ");
}, parseTopicFromKeyword = function(e) {
    var r = [], o = [];
    if (e && e.noteTopics && Array.isArray(e.noteTopics) && (r = e.noteTopics.slice()), 
    r.forEach(function(e) {
        o.push({
            name: e.name,
            link: e.link,
            id: e.id
        });
    }), e && e.recommendOthers && e.recommendOthers.id) {
        e.recommendOthers.desc = parseOneboxString(e.recommendOthers.desc);
        var t = e.recommendOthers.desc.split(" | ") || [], s = "城市" === t[0];
        return {
            topics: o,
            isOthers: !0,
            onebox: e.recommendOthers,
            isCity: s
        };
    }
    return e && e.recommendUser && e.recommendUser.id ? (e.recommendUser.info = parseOneboxString(e.recommendUser.info), 
    {
        topics: o,
        isUser: !0,
        onebox: e.recommendUser
    }) : e && e.recommendGoods && e.recommendGoods.desc ? {
        topics: o,
        isGoods: !0,
        onebox: e.recommendGoods
    } : {
        topics: o
    };
}, mapPage = exports.mapPage = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments[1], o = arguments[2], t = o.page, s = o.pageSize, n = o.homeFeeds, i = (0, 
    _page.mapPage)(e.notes, r.notes, {
        page: t,
        pageSize: s,
        homeFeeds: n
    }), a = i.list, c = i.pagination;
    return Object.assign({}, r, {
        notes: a,
        pagination: c
    });
}, createData = exports.createData = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    e || console.error("[notes-list] could not found notes array");
    var o = e.map(function(e) {
        return Object.assign(e, {
            title: (0, _string.escapeNoteString)(e.title),
            desc: (0, _string.escapeNoteString)(e.desc)
        });
    });
    return Object.assign({}, DEFAULT_DATA, r, {
        notes: o
    });
};