function getHotSearch(e) {
    var t = e.sid, r = e.openid;
    return (0, _http.get)("NOTES_HOT_SEARCH", {
        transform: !0,
        params: {
            openid: r,
            sid: t
        }
    }).then(parseHotSearch);
}

function getRecommendNotes(e) {
    var t = e.sid, r = e.keyword, o = e.openid;
    return (0, _http.get)("SEARCH_NOTES_AUTO_COMPLETE", {
        transform: !0,
        params: {
            keyword: r,
            openid: o,
            sid: t,
            source: "store"
        }
    }).then(parseRecommendNotes);
}

function getNotesPlaceholder(e) {
    var t = e.openid;
    return (0, _http.get)("SEARCH_NOTES_PLACEHOLDER", {
        transform: !0,
        params: {
            openid: t
        }
    }).then(parsePlaceholderSearch);
}

function hasValue(e) {
    var t = !1, r = -1;
    return this.historys.forEach(function(o, n) {
        o.name === e && (t = !0, r = n);
    }), {
        flag: t,
        index: r
    };
}

function removeEleBaseIndex(e) {
    e > -1 && this.historys.splice(e, 1);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getHotSearch = getHotSearch, exports.getRecommendNotes = getRecommendNotes, 
exports.getNotesPlaceholder = getNotesPlaceholder, exports.hasValue = hasValue, 
exports.removeEleBaseIndex = removeEleBaseIndex;

var _http = require("./../utils/http.js"), parseHotSearch = function(e) {
    return e || [];
}, parsePlaceholderSearch = function(e) {
    var t = getCurrentPages();
    return console.log("><><<<<<<<<<<<??>><>", t[t.length - 1].route), "pages/main/home/index" === t[t.length - 1].route ? e.home : "pages/main/store/index" === t[t.length - 1].route ? (console.log(">>>>>>>>>>>>>>store", e.store), 
    e.store) : void 0;
}, parseRecommendNotes = function(e) {
    return e.map(function(e) {
        return {
            name: e.text,
            description: e.desc,
            searchType: e.searchType
        };
    });
};