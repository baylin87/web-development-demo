function getHomeFeeds(e) {
    var t = e.oid, o = e.geo, r = e.cursorScore;
    return o ? (0, _http.get)("COMMUNITY_HOMEFEEDS", {
        transform: !0,
        params: {
            oid: t,
            cursorScore: r,
            geo: o
        }
    }) : (0, _http.get)("COMMUNITY_HOMEFEEDS", {
        transform: !0,
        params: {
            oid: t,
            cursorScore: r
        }
    });
}

function getHomeFeedsCategories(e) {
    var t = e.sid;
    return (0, _http.get)("COMMUNITY_CATEGORIES", {
        transform: !0,
        params: {
            sid: t
        }
    });
}

function getDefaultCategories() {
    return [ {
        name: "推荐",
        oid: "recommend"
    }, {
        name: "时尚",
        oid: "fasion"
    }, {
        name: "美妆",
        oid: "cosmetics"
    }, {
        name: "美食",
        oid: "food"
    }, {
        name: "运动",
        oid: "sport"
    }, {
        name: "旅行",
        oid: "travel"
    }, {
        name: "居家",
        oid: "home"
    }, {
        name: "母婴",
        oid: "babycare"
    }, {
        name: "读书",
        oid: "books"
    }, {
        name: "数码",
        oid: "digital"
    }, {
        name: "时尚男士",
        oid: "mens_fasion"
    } ];
}

function getHomeFeedsCategoriesWithoutSid() {
    var e = getDefaultCategories();
    return new Promise(function(t) {
        t(e);
    });
}

function getHomeFeedsWithoutSid(e) {
    var t = e.oid, o = e.page, r = e.pageSize;
    return (0, _http.get)("COMMUNITY_HOMEFEEDS", {
        transform: !0,
        params: {
            oid: t,
            page: o,
            pageSize: r
        }
    });
}

function checkIsDefaultCategories() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = getDefaultCategories();
    return 0 !== e.length && e.length === t.length && (e.forEach(function(e, o) {
        if (t[o] && e.oid !== t[o].oid) return !1;
    }), !0);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getHomeFeeds = getHomeFeeds, exports.getHomeFeedsCategories = getHomeFeedsCategories, 
exports.getDefaultCategories = getDefaultCategories, exports.getHomeFeedsCategoriesWithoutSid = getHomeFeedsCategoriesWithoutSid, 
exports.getHomeFeedsWithoutSid = getHomeFeedsWithoutSid, exports.checkIsDefaultCategories = checkIsDefaultCategories;

var _http = require("./../utils/http.js");