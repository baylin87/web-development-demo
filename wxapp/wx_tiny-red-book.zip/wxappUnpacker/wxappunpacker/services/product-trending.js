function filterGoods(e) {
    var r = e.slice(), t = [];
    return r.forEach(function(e) {
        /立减/.test(e.promotionText) || /选/.test(e.promotionText) || t.push(e);
    }), t;
}

function getSearchFromKeyword(e) {
    var r = e.sid, t = e.keyword, o = e.pagination;
    return (0, _http.get)("SEARCH_FROM_KEYWORD", {
        transform: !0,
        params: {
            sid: r,
            keyword: t,
            page: o.page,
            perPage: o.pageSize
        }
    }).then(parseSearchFromKeyword);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createData = exports.mapPage = exports.DEFAULT_DATA = void 0, exports.filterGoods = filterGoods, 
exports.getSearchFromKeyword = getSearchFromKeyword;

var _http = require("./../utils/http.js"), _parseUrl = require("./../utils/parse-url.js"), _page = require("./../utils/page.js"), _string = require("./../utils/string.js"), DEFAULT_META = {}, DEFAULT_DATA = exports.DEFAULT_DATA = Object.assign({}, DEFAULT_META, {
    goods: []
}), parseSearchFromKeyword = function(e) {
    var r = e.items.slice(), t = [];
    return r.forEach(function(e) {
        var r = e.promotionText ? [ {
            name: e.promotionText
        } ] : [];
        t.push({
            id: e.id,
            image: (0, _parseUrl.transUriToSafe)(e.image),
            title: e.title,
            desc: e.desc,
            discountPrice: e.discountPrice,
            price: e.price,
            vendorIcon: (0, _parseUrl.transUriToSafe)(e.vendorIcon),
            newArriving: e.newArriving || !1,
            promotionTag: r,
            promotionText: e.promotionText
        });
    }), {
        totalCount: e.totalCount,
        goods: t
    };
}, mapPage = exports.mapPage = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments[1], t = arguments[2], o = t.page, a = t.pageSize, i = t.homeFeeds, s = (0, 
    _page.mapPage)(e.goods, r.goods, {
        page: o,
        pageSize: a,
        homeFeeds: i
    }), n = s.list, p = s.pagination;
    return Object.assign({}, r, {
        goods: n,
        pagination: p
    });
}, createData = exports.createData = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    e || console.error("[goods-list] could not found goods array");
    var t = e.map(function(e) {
        return Object.assign(e, {
            title: (0, _string.escapeNoteString)(e.title),
            desc: (0, _string.escapeNoteString)(e.desc)
        });
    });
    return Object.assign({}, DEFAULT_DATA, r, {
        goods: t
    });
};