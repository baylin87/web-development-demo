function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function o(n, a) {
                try {
                    var s = t[n](a), i = s.value;
                } catch (e) {
                    return void r(e);
                }
                if (!s.done) return Promise.resolve(i).then(function(e) {
                    o("next", e);
                }, function(e) {
                    o("throw", e);
                });
                e(i);
            }
            return o("next");
        });
    };
}

function getNoteWithoutSid(e) {
    return (0, _http.get)("WEB_NOTE", {
        transform: !0,
        params: {
            id: e.id,
            from: "mp"
        }
    }).then(function(e) {
        return Object.assign(e, {
            tagInfo: e.tag_info
        });
    });
}

function getNote(e) {
    var t = e.id, r = e.sid;
    return (0, _http.get)("NOTE", {
        transform: !0,
        params: {
            sid: r
        },
        resourceParams: {
            id: t
        }
    });
}

function likeNote(e) {
    var t = e.noteId;
    return (0, _http.post)("LIKE_NOTE", {
        noteId: t
    }, {
        transform: !0,
        resourceParams: {
            noteId: t
        }
    });
}

function dislikeNote(e) {
    var t = e.noteId;
    return (0, _http.del)("LIKE_NOTE", {
        transform: !0,
        resourceParams: {
            noteId: t
        }
    });
}

function collectNote(e) {
    var t = e.noteId, r = e.sid;
    return (0, _http.post)("COLLECT_NOTE", {
        noteId: t
    }, {
        transform: !0,
        resourceParams: {
            noteId: t,
            sid: r
        }
    });
}

function deleteCollectNote(e) {
    var t = e.noteId, r = e.sid;
    return (0, _http.del)("COLLECT_NOTE", {
        transform: !0,
        data: {
            noteId: t
        },
        resourceParams: {
            noteId: t,
            sid: r
        }
    });
}

function shareNote(e) {
    var t = e.noteId, r = e.sid;
    return (0, _http.get)("SHARE_NOTE", {
        transform: !0,
        params: {
            sid: r
        },
        resourceParams: {
            noteId: t
        }
    });
}

function getHomeFeed(e) {
    return (0, _http.get)("DISCOVERY_HOMEFEEDS", {
        params: {
            page: e
        }
    });
}

function getNoteList(e) {
    var t = e.type, r = e.id, o = e.pagination, n = "homefeed" === t ? "DISCOVERY_HOMEFEEDS" : "RELATED_NOTES";
    return (0, _http.get)(n, {
        params: {
            num: 20,
            id: r,
            page: o.page,
            page_size: o.pageSize
        }
    });
}

function getNoteSummaryComment(e) {
    var t = e.id;
    return (0, _http.get)("COMMENT", {
        transform: !0,
        params: {
            type: "summary"
        },
        resourceParams: {
            id: t
        }
    });
}

function getNoteImageStickers(e) {
    return (0, _http.get)("IMAGE_STRICKERS", {
        transform: !0,
        params: {},
        resourceParams: {
            id: e
        }
    });
}

function getNoteCommentDetail(e) {
    var t = e.noteId, r = e.pageSize, o = e.endId, n = {
        pageSize: r || 6
    };
    return o && (n.endId = o), (0, _http.get)("NOTE_COMMENT_DETAIL", {
        transform: !0,
        params: n,
        resourceParams: {
            noteId: t
        }
    });
}

function getPinchNum(e) {
    return (0, _http.get)("PINCH_READ_NUM", {
        transform: !0,
        resourceParams: {
            id: e.id
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getTrending = void 0;

var getTrending = exports.getTrending = function() {
    var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
        var r, o, n = t.id, a = t.type, s = t.pagination;
        return regeneratorRuntime.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                r = void 0, o = void 0, e.t0 = a, e.next = e.t0 === _enum.TRENDING_TYPE.SEARCH_TRENDING ? 4 : e.t0 === _enum.TRENDING_TYPE.GOODS_TRENDING ? 6 : 8;
                break;

              case 4:
                return r = "SEARCH_TRENDING", e.abrupt("break", 10);

              case 6:
                return r = "GOODS_TRENDING", e.abrupt("break", 10);

              case 8:
                return o = "[discovery service] non-supported type; " + a, e.abrupt("break", 10);

              case 10:
                if (!o) {
                    e.next = 13;
                    break;
                }
                return console.log(o), e.abrupt("return");

              case 13:
                return e.abrupt("return", (0, _http.get)(r, {
                    params: {
                        id: n,
                        page: s.page,
                        page_size: s.pageSize
                    }
                }).then(function(e) {
                    return {
                        title: e.title,
                        image: e.image,
                        noteCount: e.note_count,
                        notes: e.notes
                    };
                }));

              case 14:
              case "end":
                return e.stop();
            }
        }, e, this);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}();

exports.getNoteWithoutSid = getNoteWithoutSid, exports.getNote = getNote, exports.likeNote = likeNote, 
exports.dislikeNote = dislikeNote, exports.collectNote = collectNote, exports.deleteCollectNote = deleteCollectNote, 
exports.shareNote = shareNote, exports.getHomeFeed = getHomeFeed, exports.getNoteList = getNoteList, 
exports.getNoteSummaryComment = getNoteSummaryComment, exports.getNoteImageStickers = getNoteImageStickers, 
exports.getNoteCommentDetail = getNoteCommentDetail, exports.getPinchNum = getPinchNum;

var _http = require("./../utils/http.js"), _enum = require("./../utils/enum.js"), _parseUrl = require("./../utils/parse-url.js");