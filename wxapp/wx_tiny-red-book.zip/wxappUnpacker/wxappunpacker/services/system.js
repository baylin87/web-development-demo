function getAbTest() {
    return (0, _http.get)("AB_TEST", {
        params: {}
    });
}

function collectFormId(t) {
    return (0, _http.post)("COLLECT_FORM_ID", {
        formId: t
    }, {
        transform: !0
    });
}

function getMineInfo() {
    return (0, _http.get)("MINE_INFO_DETAIL", {
        params: {}
    });
}

function editMineInfo() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.key, o = t.value;
    return (0, _http.post)("EDIT_MINE_INFO", {
        key: e,
        value: o
    }, {
        transform: !0,
        header: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAbTest = getAbTest, exports.collectFormId = collectFormId, exports.getMineInfo = getMineInfo, 
exports.editMineInfo = editMineInfo;

var _http = require("./../utils/http.js");