function comment(t) {
    var e = t.content, n = t.noteid, o = t.commentid;
    return (0, _http.post)("SEND_COMMENT", {
        content: e,
        noteid: n,
        commentid: o
    }, {
        transform: !0,
        header: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.comment = comment;

var _http = require("./../utils/http.js");