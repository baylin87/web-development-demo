function getJumpPageUrl(t) {
    var e = t.pathId;
    return (0, _http.get)("QR_LINK", {
        transform: !0,
        params: {
            pathId: e
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getJumpPageUrl = getJumpPageUrl;

var _http = require("./../utils/http.js");