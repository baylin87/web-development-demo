function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function trackLaunch() {
    return (0, _http.get)("TRACK_LAUNCHED");
}

function sendTrackInfo() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.category, t = e.seAc, o = e.seLa, a = e.sePr, s = e.url, n = e.from, i = e.e, u = e.co, c = e.aid;
    n && (fromSource = n);
    var p = {}, d = "TRACKING";
    fromSource && (p.from = fromSource), c && (p.aid = c), t = t || "", t = t.replace(/-/g, "_"), 
    u = u || {};
    for (var l in u) Object.prototype.hasOwnProperty.call(u, l) && (p[l] = u[l]);
    if (!systemInfo) try {
        systemInfo = _api2.default.getSystemInfoSync(), systemInfo.brand && "devtools" === systemInfo.brand && (d = "TRACKING_TEST");
    } catch (i) {
        systemInfo = {};
    }
    var f = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {}, _ = f.openid, m = f.appUserId, y = f.isNewWxmpUser, g = f.appUserInfo || {}, k = {
        schema: "xhs_mini_program/1-0-0",
        data: [ {
            schema: "mp-user/1-0-0",
            data: {
                openid: _,
                isNewWxmpUser: y,
                isAppUser: g.isAppUser
            }
        }, {
            schema: "page-info/1-0-0",
            data: p
        }, {
            schema: "system-info/1-0-0",
            data: {
                model: systemInfo.model || "",
                platform: systemInfo.platform || "",
                sdk: systemInfo.SDKVersion || "",
                system: systemInfo.system || "",
                version: systemInfo.version || ""
            }
        } ]
    }, h = _projectVersion2.default ? _projectVersion2.default : "1.0", T = {
        tna: "mpT",
        tv: "mp-0.1.0",
        aid: "xhs_marco#" + h,
        vp: systemInfo.screenWidth + "x" + systemInfo.screenHeight,
        p: "mp",
        e: i || "se",
        exp: "",
        eid: _uuid2.default.new().hex,
        seCa: r,
        seAc: t,
        uid: m ? (0, _md2.default)(m) : null,
        nuid: m || null,
        url: s,
        co: k
    };
    return a && (T.sePr = a), o && (T.seLa = o), T.co = JSON.stringify(T.co), console.log("trackMethod: " + d + ", trackItem:", T), 
    new Promise(function(e) {
        _abTest2.default.pageABTestMetaReady().then(function() {
            var r = _abTest2.default.getExpIds();
            T.exp = r.join("|"), (0, _http.post)(d, {
                schema: "payload",
                data: [ T ]
            }, {
                transform: !0
            }).then(function() {
                e();
            });
        });
    });
}

function wxTrack(e) {
    var r = e.action, t = e.label, o = e.property, a = e.uid, s = (0, _path.getPageUrl)(), n = s.route, i = s.url, u = s.from, c = s.scene, p = (0, 
    _routes.getCategory)(n);
    return sendTrackInfo({
        category: p,
        seAc: r,
        sePr: o,
        url: i,
        from: u,
        co: {
            scene: c
        }
    }), _api2.default.reportAnalytics("track", {
        category: p || this.$wxpage.route,
        action: r,
        label: t,
        property: o,
        uid: a || this.appUserId
    });
}

function goodsDetailTrack(e) {
    var r = e.xhsGS, t = _api2.default.getStorageSync("user_info");
    return sendTrackInfo({
        openid: t.openid,
        uid: t.appUserId,
        category: "goods_detail",
        seAc: "click_instance_buy",
        sePr: r,
        url: "pages/goods/index"
    });
}

function checkoutTrack(e) {
    var r = e.xhsGS, t = e.oid, o = _api2.default.getStorageSync("user_info");
    return sendTrackInfo({
        openid: o.openid,
        token: o.token,
        uid: o.appUserId,
        category: "order_checked",
        seAc: "pay_success",
        sePr: t,
        url: "pages/checkout/index?xhs_g_s=" + r
    });
}

function bindMobileTrack(e) {
    var r = e.action, t = e.url, o = e.status, a = _api2.default.getStorageSync("user_info");
    return sendTrackInfo({
        openid: a.openid,
        token: a.token,
        uid: a.appUserId,
        category: "pages/mine/index" === t ? "My_View" : "goods_detail",
        seAc: r,
        sePr: o,
        url: t
    });
}

function launchAppTrack(e) {
    var r = e.category, t = e.url, o = e.fail, a = _api2.default.getStorageSync("user_info");
    return sendTrackInfo({
        openid: a.openid,
        token: a.token,
        uid: a.appUserId,
        category: r,
        seAc: o ? "launch_app_failed" : "launch_app_clicked",
        url: t
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.trackLaunch = trackLaunch, exports.sendTrackInfo = sendTrackInfo, exports.wxTrack = wxTrack, 
exports.goodsDetailTrack = goodsDetailTrack, exports.checkoutTrack = checkoutTrack, 
exports.bindMobileTrack = bindMobileTrack, exports.launchAppTrack = launchAppTrack;

var _http = require("./../utils/http.js"), _enum = require("./../utils/enum.js"), _routes = require("./../routes.js"), _path = require("./../utils/path.js"), _abTest = require("./../utils/ab-test.js"), _abTest2 = _interopRequireDefault(_abTest), _api = require("./../utils/api.js"), _api2 = _interopRequireDefault(_api), _md = require("./../libs/md5.js"), _md2 = _interopRequireDefault(_md), _uuid = require("./../libs/uuid.js"), _uuid2 = _interopRequireDefault(_uuid), _projectVersion = require("./../project-version.js"), _projectVersion2 = _interopRequireDefault(_projectVersion), systemInfo = null, fromSource = "";