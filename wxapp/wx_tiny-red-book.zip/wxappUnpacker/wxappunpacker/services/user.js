function _interopRequireDefault(o) {
    return o && o.__esModule ? o : {
        default: o
    };
}

function getPlatform() {
    var o = _api2.default.getSystemInfoSync().platform;
    return "devtools" === o ? "ios" : o;
}

function loginWithCode(o) {
    return platform || (platform = getPlatform()), (0, _http.post)("LOGIN", {
        code: o,
        platform: platform
    }, {
        transform: !0
    });
}

function postUserInfoToServerAndGetSid(o) {
    return (0, _http.post)("USER_INFO", o, {
        transform: !0
    });
}

function WXMobileLogin(o) {
    return (0, _http.post)("WX_MOBILE_LOGIN", o, {
        transform: !0
    });
}

function mobileLogin(o) {
    return platform || (platform = platform = getPlatform()), o.platform = platform, 
    (0, _http.post)("MLOGIN", o, {
        transform: !0
    });
}

function telephoneLogin(o) {
    return (0, _http.post)("MOBILE_LOGIN", o, {
        transform: !0
    });
}

function getVerifyCode(o) {
    return platform || (platform = platform = getPlatform()), o.platform = platform, 
    (0, _http.post)("VFC_CODE", o);
}

function becomeFriend(o) {
    var e = o.fromUid, t = o.toUid, r = o.sid;
    return (0, _http.post)("WX_FRIEND", {
        fromUid: e,
        toUid: t
    }, {
        resourceParams: {
            sid: r
        },
        transform: !0
    });
}

function becomeRawFriend(o) {
    var e = o.fromUnionId, t = void 0 === e ? "" : e, r = o.fromUserId, n = void 0 === r ? "" : r, i = o.toUnionId, p = void 0 === i ? "" : i, s = o.toUserId, f = void 0 === s ? "" : s, l = o.source, d = void 0 === l ? "" : l;
    return (0, _http.post)("WX_RAW_FRIEND", {
        fromUnionid: t,
        fromUserid: n,
        toUnionid: p,
        toUserid: f,
        source: d
    }, {
        transform: !0
    });
}

function logout() {
    return (0, _http.get)("LOGOUT");
}

function getPhoneZones() {
    return (0, _http.get)("GET_PHONE_ZONES");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getPhoneZones = exports.becomeRawFriend = exports.becomeFriend = exports.getVerifyCode = exports.WXMobileLogin = exports.telephoneLogin = exports.mobileLogin = exports.logout = exports.postUserInfoToServerAndGetSid = exports.loginWithCode = void 0;

var _http = require("./../utils/http.js"), _api = require("./../utils/api.js"), _api2 = _interopRequireDefault(_api), platform = null;

exports.loginWithCode = loginWithCode, exports.postUserInfoToServerAndGetSid = postUserInfoToServerAndGetSid, 
exports.logout = logout, exports.mobileLogin = mobileLogin, exports.telephoneLogin = telephoneLogin, 
exports.WXMobileLogin = WXMobileLogin, exports.getVerifyCode = getVerifyCode, exports.becomeFriend = becomeFriend, 
exports.becomeRawFriend = becomeRawFriend, exports.getPhoneZones = getPhoneZones;