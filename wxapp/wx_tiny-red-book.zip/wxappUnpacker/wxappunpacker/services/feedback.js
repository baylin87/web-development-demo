function sendFeedback(e) {
    var t = e.sid, n = e.content, o = e.type, r = e.deviceinfo, s = e.imageList;
    return (0, _http.post)("FEEDBACK", {
        content: n,
        type: o,
        deviceinfo: r,
        imageList: s,
        sid: t
    }, {
        transform: !0
    });
}

function getUploadToken() {
    return (0, _http.get)("CI_TOKEN", {
        extractData: !1
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.sendFeedback = sendFeedback, exports.getUploadToken = getUploadToken;

var _http = require("./../utils/http.js");