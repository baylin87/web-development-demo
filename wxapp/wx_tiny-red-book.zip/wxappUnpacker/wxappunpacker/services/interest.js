function getTags() {
    return (0, _http.get)("INTEREST_TAGS", {
        transform: !0
    });
}

function likeTags(e) {
    return (0, _http.post)("INTEREST_TAGS", {
        tags: e
    }, {
        transform: !0
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getTags = getTags, exports.likeTags = likeTags;

var _http = require("./../utils/http.js"), _enum = require("./../utils/enum.js"), _parseUrl = require("./../utils/parse-url.js");