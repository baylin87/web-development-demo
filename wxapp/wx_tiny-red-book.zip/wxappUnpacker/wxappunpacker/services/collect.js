function getFaved(t) {
    var r = t.num, e = void 0 === r ? 10 : r, a = t.bottomStart;
    return a ? (0, _http.get)("FAVED", {
        transform: !0,
        params: {
            num: e,
            bottomStart: a
        }
    }) : (0, _http.get)("FAVED", {
        transform: !0,
        params: {
            num: e
        }
    });
}

function getAuthorFaved(t) {
    var r = t.userId, e = t.num, a = void 0 === e ? 10 : e, o = t.bottomStart;
    return (0, _http.get)("AUTHORFAVED", {
        transform: !0,
        params: {
            num: a,
            bottomStart: o
        },
        resourceParams: {
            userId: r
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getFaved = getFaved, exports.getAuthorFaved = getAuthorFaved;

var _http = require("./../utils/http.js");