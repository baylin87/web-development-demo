function getHomeFeeds(e) {
    var r = e.cursorScore, t = e.categoryid;
    return (0, _http.get)("HOMEFEEDS", {
        transform: !0,
        params: {
            source: "wx",
            cursorScore: r,
            categoryid: t
        }
    }).then(parseHomeFeeds);
}

function checkIfNewUser(e) {
    var r = e.sid;
    return (0, _http.get)("CHECK_IF_NEW_USER", {
        transform: !0,
        params: {
            source: "wx",
            sid: r
        }
    });
}

function getFulisheCategoryBanner(e) {
    var r = e.tabId, t = {};
    return r && (t.tabId = r), (0, _http.get)("FULISHE_CATEGORIES_BANNERS", {
        transform: !0,
        params: t
    });
}

function claimCoupon(e, r) {
    return (0, _http.post)("CLAIM_COUPON", {
        version: 2,
        sid: r
    }, {
        transform: !0,
        resourceParams: {
            couponId: e
        }
    });
}

function activityBannerEntry() {
    return (0, _http.get)("ACTIVITY_BANNER_ENTRY", {
        transform: !0
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getHomeFeeds = getHomeFeeds, exports.checkIfNewUser = checkIfNewUser, 
exports.getFulisheCategoryBanner = getFulisheCategoryBanner, exports.claimCoupon = claimCoupon, 
exports.activityBannerEntry = activityBannerEntry;

var _http = require("./../utils/http.js"), _parseUrl = require("./../utils/parse-url.js"), parseHomeFeeds = function(e) {
    var r = [], t = e.length > 0 && e.slice(-1)[0], o = t && t.cursorScore, n = e.length > 0 || !1;
    return e.forEach(function(e) {
        var t = e.type, o = e.id, n = e.image, s = e.link, a = e.desc, i = e.title, c = e.itemPrice, p = e.newArriving, u = e.vendorIcon, m = e.promotionText;
        if (!/立减|选/.test(m)) {
            var g = m ? [ {
                name: m
            } ] : [], d = {
                type: t,
                id: o,
                image: (0, _parseUrl.transUriToSafe)(n),
                title: i,
                link: s,
                desc: a,
                newArriving: p || !1,
                vendorIcon: (0, _parseUrl.transUriToSafe)(u),
                promotionTag: g
            };
            c && Array.isArray(c) && c.forEach(function(e) {
                var r = e.type, t = e.price;
                switch (r) {
                  case "origin_price":
                    d.price = t;
                    break;

                  case "sale_price":
                    d.discountPrice = t;
                    break;

                  case "member_price":
                    d.memberPrice = t;
                }
            }), r.push(d);
        }
    }), {
        cursorScore: o,
        goods: r,
        hasMore: n
    };
};