function getUserInfo(e) {
    var r = e.sid, t = e.userId;
    return (0, _http.get)("SNS_USER_INFO", {
        transform: !0,
        params: {
            sid: r
        },
        resourceParams: {
            userId: t
        }
    });
}

function getNoteUser(e) {
    var r = e.sid, t = e.userId, s = e.page, a = e.pageSize;
    return (0, _http.get)("SNS_NOTE_USER", {
        transform: !0,
        params: {
            sid: r,
            page: s,
            pageSize: a
        },
        resourceParams: {
            userId: t
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getUserInfo = getUserInfo, exports.getNoteUser = getNoteUser;

var _http = require("./../utils/http.js");