function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, r) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !r || "object" != typeof r && "function" != typeof r ? e : r;
}

function _inherits(e, r) {
    if ("function" != typeof r && null !== r) throw new TypeError("Super expression must either be null or a function, not " + typeof r);
    e.prototype = Object.create(r && r.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), r && (Object.setPrototypeOf ? Object.setPrototypeOf(e, r) : e.__proto__ = r);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, r) {
        for (var t = 0; t < r.length; t++) {
            var a = r[t];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(r, t, a) {
        return t && e(r.prototype, t), a && e(r, a), r;
    };
}(), _wepy = require("./../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _track = require("./../../../utils/track.js"), _path = require("./../../../utils/path.js"), _enum = require("./../../../utils/enum.js"), _parseUrl = require("./../../../utils/parse-url.js"), _urlParse = require("./../../../npm/url-parse/index.js"), _urlParse2 = _interopRequireDefault(_urlParse), _base = require("./../../../mixins/base.js"), _base2 = _interopRequireDefault(_base), Mine = function(e) {
    function r() {
        var e, t, a, n;
        _classCallCheck(this, r);
        for (var i = arguments.length, o = Array(i), s = 0; s < i; s++) o[s] = arguments[s];
        return t = a = _possibleConstructorReturn(this, (e = r.__proto__ || Object.getPrototypeOf(r)).call.apply(e, [ this ].concat(o))), 
        a.config = {
            navigationBarTitleText: "",
            navigationBarBackgroundColor: "#FFFFFF",
            navigationBarTextStyle: "black",
            enablePullDownRefresh: !1
        }, a.mixins = (0, _base2.default)({
            TrackerMixin: !1,
            IntervalMixin: !1,
            PerformancelMixin: !1
        }), a.data = {
            link: "",
            shareInfo: {}
        }, n = t, _possibleConstructorReturn(a, n);
    }
    return _inherits(r, e), _createClass(r, [ {
        key: "bindmessage",
        value: function(e) {
            var r = this, t = e.detail;
            t = t || {}, (t.data || []).forEach(function(e) {
                var t = e.methodName, a = e.data;
                if ("setShareInfo" === t) {
                    a = a || {};
                    var n = a, i = n.title, o = n.linkurl, s = n.image;
                    i && (r.shareInfo.title = i), s && -1 === s.indexOf("logo-normal") && (r.shareInfo.imageUrl = s), 
                    o && (r.shareInfo.link = encodeURIComponent(decodeURIComponent(o)));
                }
            });
        }
    }, {
        key: "onShareAppMessage",
        value: function() {
            var e = (0, _path.makeSharePath)("HomePage");
            try {
                var r = this.$wxpage, t = r.route, a = r.options, n = [], i = [ "sid", "scene" ];
                for (var o in a) {
                    var s = a[o];
                    "link" === o && s && (this.shareInfo.link && (s = this.shareInfo.link), s = decodeURIComponent(s), 
                    s = (0, _parseUrl.cleanSpecialKeys)(s), s = encodeURIComponent(s)), -1 === i.indexOf(o) && n.push(o + "=" + s);
                }
                e = t + "?" + n.join("&");
            } catch (e) {}
            (0, _track.trackNormalData)({
                action: "share",
                property: e
            });
            var l = {
                path: e
            };
            return this.shareInfo.title && (l.title = this.shareInfo.title), this.shareInfo.imageUrl && (l.imageUrl = this.shareInfo.imageUrl), 
            l;
        }
    }, {
        key: "onLoad",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            console.log("webview", e);
            var r = e.link || "", t = (0, _parseUrl.getAbsoluteLink)({
                link: decodeURIComponent(r)
            }), a = [ /\/vendor\/[\S]{24}\/events\/[\S]{24}/, /\/vendor\/[\S]{24}/, /\/goods\/[\S]{24}/, /\/event\/page\/sale_event\/[\S]{24}/, /\/store\/cs\/index/, /\/page\//, /\/activity\//, /\/tag\/custom/ ], n = _wepy2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO) || {}, i = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), o = i.sid;
            t = (0, _parseUrl.cleanSpecialKeys)(t), t = (0, _parseUrl.changeQuery)({
                link: t,
                type: "set",
                key: "_mpversion",
                value: new Date().getTime()
            }), t = (0, _parseUrl.changeQuery)({
                link: t,
                type: "set",
                key: "sid",
                value: o
            });
            var s = !1;
            t.indexOf("noShare=yes") > -1 && (s = !1), a.some(function(e) {
                if (e.test(t)) return s = !0, !0;
            }), !s && wx.canIUse("hideShareMenu") && wx.hideShareMenu(), (0, _track.trackPageview)(), 
            (0, _track.trackNormalData)({
                action: "webview_pv",
                label: t
            });
            var l = n.openid;
            this.$parent.canLaunchApp && (t = (0, _parseUrl.changeQuery)({
                link: t,
                type: "set",
                key: "canLaunchAppFromMp",
                value: !0
            })), l && (t = (0, _parseUrl.changeQuery)({
                link: t,
                type: "set",
                key: "openid",
                value: l
            })), t = (0, _parseUrl.changeQuery)({
                link: t,
                type: "set",
                key: "isMiniProgram",
                value: "true"
            }), this.link = t;
        }
    }, {
        key: "onUnload",
        value: function() {
            (0, _track.trackNormalData)({
                action: "page_unload"
            });
        }
    } ]), r;
}(_wepy2.default.page);

Page(require("./../../../npm/wepy/lib/wepy.js").default.$createPage(Mine, "pages/main/webview/index"));