function _interopRequireDefault(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}

var _wepy = require("./../../../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _path = require("./../../../../../utils/path.js"), _track = require("./../../../../../utils/track.js"), _page = require("./../../../../../utils/page.js"), systemInfo = wx.getSystemInfoSync(), isAndroid = "android" === systemInfo.platform, ScreenWidth = "750rpx", CurrentSystemInfo = _wepy2.default.$instance.globalData.systemInfo, rpx2px = function(a) {
    return a * systemInfo.screenWidth / 750;
}, px2rpx = function(a) {
    return 750 * a / CurrentSystemInfo.screenWidth;
};

Component({
    behaviors: [],
    properties: {
        navigationBarConfig: {
            type: Object,
            observer: function(a, t, e) {
                null != t && this.setNavigationBar(a);
            }
        }
    },
    data: {
        title: "",
        isIphoneX: !1,
        navigationBarTrueHeight: (0, _page.getTopSectionHeight)(),
        navigationBarStyles: "",
        navigationBarIconsNum: 0,
        canUseCustomNavigationBar: !0,
        noShowNavigationBar: !1,
        showBackIcon: !1,
        showHomePageIcon: !1,
        leftSideInnerStyle: ""
    },
    ready: function() {
        this.data.isIphoneX = _wepy2.default.$instance.globalData.isIPhoneX;
        var a = getCurrentPages(), t = (0, _page.getNavigationBarInfo)();
        this.data.showBackIcon = a.length > 1, this.data.showBackIcon && (this.data.navigationBarIconsNum += 1), 
        this.data.canUseCustomNavigationBar = t.canCustom, this.data.noShowNavigationBar = t.noShow;
        this.canUseCustomNavigationBar && this.noShowNavigationBar && (this.data.navigationBarTrueHeight = 0), 
        this.data.pageContentClass = "", this.data.pageContainerClass = " ready";
        var e = rpx2px(64) - 2, i = rpx2px(174) - 2;
        isAndroid && (e -= 1, i -= 1), e += "px", i += "px", this.data.leftSideInnerStyle = "height: " + e + ";max-width: " + i + ";", 
        this.setNavigationBar(this.properties.navigationBarConfig);
    },
    moved: function() {},
    detached: function() {},
    show: function() {},
    methods: {
        handleGoLastPage: function() {
            this.triggerEvent("navigateBack"), (0, _track.trackNormalData)({
                action: "navigate_back"
            }), (0, _path.navigateBack)();
        },
        handleHomePage: function() {
            this.triggerEvent("switchHomePage"), (0, _track.trackNormalData)({
                action: "navigate_home_page"
            }), (0, _path.switchTab)("HomePage");
        },
        setAllData: function() {
            this.setData({
                title: this.data.title,
                isIphoneX: this.data.isIphoneX,
                navigationBarTrueHeight: this.data.navigationBarTrueHeight,
                navigationBarStyles: this.data.navigationBarStyles,
                navigationBarIconsNum: this.data.navigationBarIconsNum,
                canUseCustomNavigationBar: this.data.canUseCustomNavigationBar,
                noShowNavigationBar: this.data.noShowNavigationBar,
                showBackIcon: this.data.showBackIcon,
                showHomePageIcon: this.data.showHomePageIcon,
                leftSideInnerStyle: this.data.leftSideInnerStyle
            });
        },
        setNavigationBar: function() {
            var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = (0, 
            _path.getPageUrl)();
            this.data.showHomePageIcon = (0, _page.isShowHomePage)(t.route), this.data.showHomePageIcon && (this.data.navigationBarIconsNum += 1), 
            a.titleText && (this.data.title = a.titleText, wx.setNavigationBarTitle({
                title: a.titleText
            }));
            var e = "#ff2741", i = "#ffffff";
            a.backgroundColor && (e = a.backgroundColor);
            var n = {
                black: "#000000",
                white: "#ffffff"
            };
            n[a.textStyle] && (i = n[a.textStyle]);
            var o = (0, _page.getTrueStatusBarHeight)();
            this.data.navigationBarStyles = "color: " + i + ";background-color: " + e + ";padding-top: " + o + "px;", 
            wx.setNavigationBarColor && wx.setNavigationBarColor({
                frontColor: i,
                backgroundColor: e
            }), this.setAllData();
        }
    }
});