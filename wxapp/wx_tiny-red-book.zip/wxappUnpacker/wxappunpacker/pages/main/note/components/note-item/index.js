function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _toConsumableArray(t) {
    if (Array.isArray(t)) {
        for (var e = 0, a = Array(t.length); e < t.length; e++) a[e] = t[e];
        return a;
    }
    return Array.from(t);
}

var _appuser = require("./../../../../../services/appuser.js"), _discovery = require("./../../../../../services/discovery.js"), _path = require("./../../../../../utils/path.js"), _track = require("./../../../../../utils/track.js"), _user = require("./../../../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _vuefy = require("./../../../../../libs/vuefy.js");

Component({
    behaviors: [],
    properties: {
        renderNoteListData: Array,
        user: Object,
        poi: Object,
        note: Object,
        commentList: Array,
        imageTags: Array,
        swiperHeight: Number,
        isExpand: Boolean,
        isFirst: Boolean,
        index: String,
        coverImgUrl: String,
        startLoadTime: Number,
        noteItemHeight: {
            type: Number,
            observer: function(t, e, a) {
                e > 0 && t !== e && this.setData({
                    isSettingHeight: !1
                });
            }
        }
    },
    data: {
        isFollowed: null,
        isSettingHeight: !1,
        subComment: [],
        commentsTotal: 0,
        isAddComment: !1,
        videoList: [],
        current: 1,
        showModal: !1,
        opacity: 1
    },
    attached: function(t) {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {
            isShowLocation: function() {
                return 0 !== Object.keys(this.data.poi).length;
            },
            totalImgCount: function() {
                var t = this.data.note;
                return Number(t.imagesList.length);
            },
            showFirstImage: function() {
                var t = this.data, e = t.index, a = t.note;
                return !(!a.type || "normal" !== a.type) && "0" === e;
            }
        });
        var t = this.data, e = t.user, a = t.note, o = t.commentList, n = t.renderNoteListData, i = [], r = this.data, s = r.startLoadTime;
        if ("0" === r.index) {
            var u = Date.now(), l = u - s;
            (0, _track.trackNormalData)({
                action: "FMP",
                property: l
            }), console.log(l);
        }
        n.forEach(function(t) {
            "video" === t.noteList[0].type && i.push(t.noteList[0].video.id);
        }), this.triggerEvent("ready"), this.setData({
            subComment: o,
            commentsTotal: a.commentsCount,
            videoList: i
        }), e && e.hasOwnProperty("followed") && this.setData({
            isFollowed: e.followed
        });
    },
    show: function() {},
    methods: {
        handleTriggerExpand: function() {
            this.setData({
                isSettingHeight: !0
            }), this.triggerEvent("triggerexpand");
        },
        handleTriggleFollow: function() {
            var t = this.data, e = t.isFollowed, a = t.user;
            e ? this.setData({
                showModal: !0
            }) : this._followAppUser(a);
        },
        handleTapAvatar: function(t) {
            var e = t.currentTarget.dataset.id;
            (0, _track.trackNormalData)({
                action: "avatar-tap",
                label: "author-avatar",
                property: e
            }), _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: e
                });
            });
        },
        handleCreateComment: function(t) {
            t.detail && t.detail.noteId && this._fetchNoteSummaryComment({
                id: t.detail.noteId
            });
        },
        handleShareIcon: function(t) {
            this.selectComponent("#note-action-bar-" + t).handleTapShare();
        },
        handleTapPoi: function() {
            var t = this.data.poi;
            t.link && (0, _path.navigateTo)("Webview", {
                link: t.link
            });
        },
        handleNoteImageSwitched: function(t) {
            var e = t.detail.current;
            this.setData({
                current: e
            });
        },
        handleBackhome: function() {
            "video" === this.data.note.type && this.selectComponent("#note").handleBackhome();
        },
        handleHasReaded: function() {
            this.selectComponent("#pinch-tip") && this.selectComponent("#pinch-tip").handleHasReaded();
        },
        handleFirstImageSwitched: function() {
            this.triggerEvent("firstImageLoaded"), this.setData({
                opacity: 0
            });
        },
        _followAppUser: function(t) {
            var e = this;
            (0, _appuser.followUser)({
                userId: t.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "follow-tap",
                    label: "follow-button",
                    property: t.id
                }), e.setData({
                    isFollowed: !0
                });
            });
        },
        _unfollowAppUser: function(t) {
            var e = this, a = t.detail.user;
            (0, _appuser.unfollowUser)({
                userId: a.id
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "unfollow-tap",
                    label: "unfollow-button",
                    property: a.id
                }), e.setData({
                    isFollowed: !1
                });
            });
        },
        _fetchNoteSummaryComment: function(t) {
            var e = this, a = t.id, o = this.data.subComment;
            (0, _discovery.getNoteCommentDetail)({
                noteId: a,
                pageSize: 1
            }).then(function(t) {
                var a = t.comments.map(function(t) {
                    return t.user.name = t.user.nickname, t;
                }), n = [].concat(_toConsumableArray(o));
                n.splice(0, 1, a[0]), e.setData({
                    subComment: n,
                    commentsTotal: t.total,
                    isAddComment: !0
                });
            });
        }
    }
});