var _track = require("./../../../../../utils/track.js");

Component({
    options: {
        multipleSlots: !0
    },
    behaviors: [],
    properties: {
        showModal: Boolean,
        modalWidth: Number,
        background: String
    },
    data: {},
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {},
    show: function() {},
    methods: {
        handleTabCloseModal: function() {
            this.setData({
                showModal: !1
            }), (0, _track.trackClick)({
                label: "cancel_to_contact",
                timeStamp: new Date().getTime()
            });
        },
        handleToContact: function() {
            (0, _track.trackClick)({
                label: "to_contact",
                timeStamp: new Date().getTime()
            });
        }
    }
});