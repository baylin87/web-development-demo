function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function getUnExpandFormatedDesc(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 128, a = 0, r = [], n = !1, i = 0;
    return !!Array.isArray(e) && (e.some(function(e) {
        var s = [];
        return i++, e.some(function(e) {
            var r = void 0;
            switch (e.type) {
              case "text":
                for (var o = 0; o < e.text.length; o++) {
                    var u = e.text.charCodeAt(o);
                    if (a += u >= 19968 && u <= 40869 ? 2 : u >= 48 && u <= 57 ? 1 : u >= 65 && u <= 90 || u >= 97 && u <= 122 ? 1 : 2, 
                    i > 2) n = !0; else if (a > t) {
                        n = !0, r = {
                            type: "text",
                            text: e.text.substring(0, o - 8).concat("...")
                        };
                        break;
                    }
                }
                break;

              case "image":
                a += 2, i > 2 ? n = !0 : a > t && (n = !0, r = {
                    type: "text",
                    text: "..."
                });
                break;

              case "userTag":
                for (var d = 0; d < e.text.length; d++) {
                    var c = e.text.charCodeAt(d);
                    a += c >= 19968 && c <= 40869 ? 2 : c >= 48 && c <= 57 ? 1 : c >= 65 && c <= 90 || c >= 97 && c <= 122 ? 1 : 2;
                }
                a += 4, i > 2 ? n = !0 : a > t && (n = !0, r = {
                    type: "text",
                    text: "..."
                });
                break;

              case "pageTag":
                for (var p = 0; p < e.text.length; p++) {
                    var h = e.text.charCodeAt(p);
                    a += h >= 19968 && h <= 40869 ? 2 : h >= 48 && h <= 57 ? 1 : h >= 65 && h <= 90 || h >= 97 && h <= 122 ? 1 : 2;
                }
                a += 4, i > 2 ? n = !0 : a > t && (n = !0, r = {
                    type: "text",
                    text: "..."
                });
            }
            return n ? s.push(r) : s.push(e), n;
        }), n ? r.push(s) : r.push(e), n;
    }), {
        canExpand: n,
        unExpandFormatedDesc: r
    });
}

var _vuefy = require("./../../../../../libs/vuefy.js"), _path = require("./../../../../../utils/path.js"), _user = require("./../../../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _discovery = require("./../../../../../utils/discovery.js");

Component({
    behaviors: [],
    properties: {
        formatedDesc: Array,
        isExpand: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        unExpandFormatedDesc: [],
        canExpand: !1
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {}), (0, _vuefy.watch)(this, {
            formatedDesc: function(e) {
                var t = getUnExpandFormatedDesc(e), a = t.unExpandFormatedDesc, r = t.canExpand;
                this.setData({
                    unExpandFormatedDesc: a,
                    canExpand: r
                });
            }
        });
    },
    show: function() {},
    methods: {
        handleTriggerExpand: function() {
            this.setData({
                isExpand: !this.data.isExpand
            }), this.triggerEvent("triggerexpand");
        },
        handlePageTap: function(e) {
            var t = e.target.dataset, a = t.type, r = t.link;
            if ("goods" === a) return void (0, _path.navigateTo)("Webview", {
                link: "/goods/" + (0, _discovery.getGoodsId)(r)
            });
            "vendor" !== a && (0, _path.navigateTo)("Webview", {
                link: r
            });
        },
        handleUserTap: function(e) {
            var t = e.target.dataset.itemId;
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: t
                });
            });
        }
    }
});