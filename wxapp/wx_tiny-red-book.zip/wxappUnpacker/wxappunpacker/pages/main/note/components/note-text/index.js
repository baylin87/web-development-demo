var _discovery = require("./../../../../../utils/discovery.js"), _vuefy = require("./../../../../../libs/vuefy.js");

Component({
    behaviors: [],
    properties: {
        desc: {
            type: String
        },
        hashTag: {
            type: Array
        },
        ats: {
            type: Array
        },
        isExpand: Boolean
    },
    data: {
        formatedDesc: []
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {
            formatedDesc: function() {
                var e = this.data.desc, t = this.data.hashTag || [], r = this.data.ats || [];
                return e.split("\n").map(function(e) {
                    return (0, _discovery.getFormatedExpressionArr)(e, t, r);
                });
            }
        });
    },
    show: function() {},
    methods: {
        handleTriggerExpand: function() {
            this.triggerEvent("triggerexpand");
        }
    }
});