function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _defineProperty(e, t, a) {
    return t in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e;
}

var _Component, _vuefy = require("./../../../../../libs/vuefy.js"), _track = require("./../../../../../utils/track.js"), _user = require("./../../../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _eventBus = require("./../../../../../libs/event-bus.js"), _eventBus2 = _interopRequireDefault(_eventBus), _discovery = require("./../../../../../services/discovery.js"), LIKE_ICON_SRC = "../../../../../assets/images/4x_icon_like_red_20.png", UNLIKE_ICON_SRC = "../../../../../assets/images/like_grey.png", COLLECT_ICON_SRC = "../../../../../assets/images/4x_icon_collect_yellow_20.png", UNCOLLECT_ICON_SRC = "../../../../../assets/images/collect_grey.png", SHARE_ICON_SRC = "../../../../../assets/images/share.png";

Component((_Component = {
    behaviors: [],
    properties: {
        liked: Boolean,
        collected: Boolean,
        likedCount: Number,
        sharedCount: Number,
        collectedCount: Number,
        noteId: String,
        shareImage: String,
        shareTitle: String,
        shareDesc: String,
        shareType: String,
        index: String
    },
    data: {
        shareIconSrc: SHARE_ICON_SRC,
        hasCollected: null,
        collectNum: null,
        hasLiked: null,
        likeNum: null,
        sharedNum: null
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        var e = this.data, t = e.collected, a = e.collectedCount, o = e.liked, n = e.likedCount, r = e.sharedCount;
        this.setData({
            hasCollected: t,
            collectNum: a,
            hasLiked: o,
            likeNum: n,
            sharedNum: r
        }), (0, _vuefy.computed)(this, {
            likeIconSrc: function() {
                return this.data.hasLiked ? LIKE_ICON_SRC : UNLIKE_ICON_SRC;
            },
            collectIconSrc: function() {
                return this.data.hasCollected ? COLLECT_ICON_SRC : UNCOLLECT_ICON_SRC;
            },
            likeNumText: function() {
                var e = this.data.likeNum;
                return e ? this._formatNum(e) : "";
            },
            collectNumText: function() {
                var e = this.data.collectNum;
                return e ? this._formatNum(e) : "";
            },
            sharedNumText: function() {
                var e = this.data.sharedNum;
                return e ? this._formatNum(e) : "";
            }
        });
    },
    show: function() {}
}, _defineProperty(_Component, "show", function() {}), _defineProperty(_Component, "methods", {
    handleTapCollect: function() {
        var e = this, t = this.data, a = t.noteId, o = t.hasCollected, n = t.collectNum;
        (0, _track.trackNormalData)({
            action: "collect-tap",
            label: "footer-action-bar"
        }), _user2.default.ensureLogin().then(function() {
            o ? (0, _discovery.deleteCollectNote)({
                noteId: a
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "collect-decrease",
                    label: "footer-action-bar"
                }), e.setData({
                    hasCollected: !1,
                    collectNum: n - 1
                });
            }) : (0, _discovery.collectNote)({
                noteId: a
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "collect-increase",
                    label: "footer-action-bar"
                }), e.setData({
                    hasCollected: !0,
                    collectNum: n + 1
                });
            });
        });
    },
    handleTapLike: function() {
        var e = this, t = this.data, a = t.noteId, o = t.hasLiked, n = t.likeNum;
        (0, _track.trackNormalData)({
            action: "like-tap",
            label: "footer-action-bar"
        }), _user2.default.ensureLogin().then(function() {
            o ? (0, _discovery.dislikeNote)({
                noteId: a
            }).then(function() {
                (0, _track.trackNormalData)({
                    action: "like-decrease",
                    label: "footer-action-bar"
                }), e.setData({
                    hasLiked: !1,
                    likeNum: n - 1
                });
            }) : (0, _discovery.likeNote)({
                noteId: a
            }).then(function(t) {
                (0, _track.trackNormalData)({
                    action: "like-increase",
                    label: "footer-action-bar"
                }), e.setData({
                    hasLiked: !0,
                    likeNum: n + 1
                }), _eventBus2.default.emit("showFullAddMp");
            });
        });
    },
    handleTapShare: function() {
        var e = this.data.sharedNum;
        console.log(e), this.setData({
            sharedNum: e + 1
        });
    },
    _formatNum: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return e >= 1e4 ? (e = Math.round(10 * (e / 1e4).toFixed(1)) / 10) + "万" : e;
    }
}), _Component));