var _vuefy = require("./../../../../../libs/vuefy.js");

Component({
    behaviors: [],
    properties: {
        time: String
    },
    data: {},
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {
            showNoteTime: function() {
                var t = this.data.time, e = new Date(1e3 * t), n = e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : "" + (e.getMonth() + 1), r = e.getDate() < 10 ? "0" + e.getDate() : "" + e.getDate();
                if (this.isToday(e)) {
                    return "今天 " + ("" + e.getHours()) + ":" + ("" + e.getMinutes());
                }
                return this.isCurrentYear(e) ? n + "-" + r : e.getFullYear() + "-" + n + "-" + r;
            }
        });
    },
    show: function() {},
    methods: {
        isToday: function(t) {
            return t.toDateString() === new Date().toDateString();
        },
        isCurrentYear: function(t) {
            return t.getFullYear() === new Date().getFullYear();
        }
    }
});