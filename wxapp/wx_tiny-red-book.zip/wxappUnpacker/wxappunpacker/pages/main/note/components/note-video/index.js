function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _defineProperty(e, t, i) {
    return t in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e;
}

var _data, _wepy = require("./../../../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _video = require("./../../utils/video.js"), _video2 = _interopRequireDefault(_video), _system = require("./../../../../../utils/system.js"), _system2 = _interopRequireDefault(_system), _vuefy = require("./../../../../../libs/vuefy.js"), CurrentSystemInfo = wx.getSystemInfoSync({
    success: function(e) {
        return e;
    }
});

Component({
    behaviors: [],
    properties: {
        images: Object,
        video: {
            type: Object,
            value: {}
        },
        videoHeight: Number,
        noteId: String,
        shareImage: String,
        shareTitle: String,
        shareDesc: String,
        shareType: String,
        index: String,
        videoList: Array,
        isFirst: Boolean
    },
    data: (_data = {
        videoIsPlaying: !1,
        videoIsAlready: !1,
        videoIsStoped: !1,
        isShowShareBox: !1,
        showControls: !1,
        isAutoplay: !0,
        isLoop: !1,
        isMuted: !1,
        showFullscreenBtn: !1,
        showCenterPlayBtn: !1,
        showProgress: !1
    }, _defineProperty(_data, "isShowShareBox", !1), _defineProperty(_data, "isFullScreen", !1), 
    _defineProperty(_data, "isIphoneX", !1), _defineProperty(_data, "videoTimeout", null), 
    _data),
    attached: function() {},
    moved: function() {
        var e = this;
        _video2.default.destroyAll({
            onDestroyAllCallBack: function() {
                e.setData({
                    videoIsPlaying: !1,
                    videoIsAlready: !1
                });
            }
        });
    },
    detached: function() {},
    ready: function() {
        this.setData({
            isIphoneX: _wepy2.default.$instance.globalData.isIPhoneX
        }), (0, _vuefy.computed)(this, {
            isIOS: function() {
                return !_system2.default.isAndroid();
            }
        });
        var e = this;
        _video2.default.destroy({
            videoIds: this.data.videoList,
            onDestroyCallBack: function() {
                e.setData({
                    videoIsPlaying: !1,
                    videoIsAlready: !1
                });
            }
        }), this.data.isFirst && (_video2.default.start({
            videoId: this.data.video.id,
            self: this
        }), this.setData({
            videoIsPlaying: _video2.default.getIsPlaying({
                videoId: this.data.video.id
            }),
            videoIsAlready: !0
        }));
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {
            var e = this;
            _video2.default.destroyAll({
                onDestroyAllCallBack: function() {
                    e.setData({
                        videoIsPlaying: !1,
                        videoIsAlready: !1
                    });
                }
            }), clearTimeout(this.videoTimeout);
        }
    },
    methods: {
        onTimeout: function(e) {
            var t = this;
            this.videoTimeout = setTimeout(function() {
                t.setData({
                    videoIsStoped: _video2.default.getIsStoped({
                        videoId: e
                    })
                });
            }, 50);
        },
        handlePlayIcon: function(e) {
            var t = e.currentTarget.dataset.id;
            _video2.default.start({
                videoId: t,
                self: this
            }), this.setData({
                videoIsPlaying: _video2.default.getIsPlaying({
                    videoId: t
                }),
                videoIsStoped: _video2.default.getIsStoped({
                    videoId: t
                }),
                videoIsAlready: !0,
                isShowShareBox: !1
            });
        },
        handleCoverPlayIcon: function(e) {
            var t = e.currentTarget.dataset.id;
            this.data.videoIsPlaying || _video2.default.start({
                videoId: t,
                self: this
            }), this.setData({
                videoIsPlaying: _video2.default.getIsPlaying({
                    videoId: t
                }),
                videoIsStoped: _video2.default.getIsStoped({
                    videoId: t
                })
            });
        },
        handleVideo: function(e) {
            var t = e.currentTarget.dataset.id, i = this.data, d = i.videoIsPlaying, a = i.isShowShareBox;
            d ? _video2.default.pause({
                videoId: t
            }) : a || _video2.default.start({
                videoId: t,
                self: this
            }), this.setData({
                videoIsPlaying: _video2.default.getIsPlaying({
                    videoId: t
                }),
                videoIsStoped: _video2.default.getIsStoped({
                    videoId: t
                })
            });
        },
        showShareBox: function(e) {
            var t = e.currentTarget.dataset.id;
            _video2.default.ended({
                videoId: t
            }), this.setData({
                isShowShareBox: !0
            });
        },
        handleNoteItemPause: function(e) {
            var t = e.currentTarget.dataset.id;
            this.setData({
                videoIsStoped: _video2.default.getIsStoped({
                    videoId: t
                })
            });
        },
        handlePlay: function(e) {
            var t = e.currentTarget.dataset.id;
            this.onTimeout(t);
        },
        handleReplay: function(e) {
            var t = e.currentTarget.dataset.id;
            _video2.default.replay({
                videoId: t
            }), this.setData({
                isShowShareBox: !1,
                videoIsPlaying: _video2.default.getIsPlaying({
                    videoId: t
                }),
                videoIsStoped: _video2.default.getIsStoped({
                    videoId: t
                })
            });
        },
        handleRequestFullScreen: function(e) {
            var t = e.currentTarget.dataset.id;
            _video2.default.requestFullScreen({
                videoId: t
            }), this.setData({
                isFullScreen: !0
            });
        },
        handleExitFullScreen: function(e) {
            var t = e.currentTarget.dataset.id;
            _video2.default.exitFullScreen({
                videoId: t
            }), this.setData({
                isFullScreen: !1
            });
        },
        handleOffSound: function() {
            this.setData({
                isMuted: !0
            });
        },
        handleOnSound: function() {
            this.setData({
                isMuted: !1
            });
        },
        handleBackhome: function() {
            var e = this;
            _video2.default.destroyAll({
                onDestroyAllCallBack: function() {
                    e.setData({
                        videoIsPlaying: !1,
                        videoIsAlready: !1
                    });
                }
            });
        }
    }
});