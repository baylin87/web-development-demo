function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _interval = require("./../../../../../utils/interval.js"), _interval2 = _interopRequireDefault(_interval), _path = require("./../../../../../utils/path.js"), _image = require("./../../../../../utils/image.js"), _vuefy = require("./../../../../../libs/vuefy.js"), _eventBus = require("./../../../../../libs/event-bus.js"), _eventBus2 = _interopRequireDefault(_eventBus), time = void 0;

Component({
    behaviors: [],
    properties: {
        images: Object,
        imageTags: Array,
        swiperHeight: Number,
        noteIndex: String
    },
    data: {
        current: 1,
        opacity: 0,
        zindex: 0,
        stickerPointData: {},
        hideTag: !1
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {
            formatedImages: function() {
                return this.data.images.map(function(e) {
                    return Object.assign({}, e, {
                        url: (0, _image.getFormatedUrl)({
                            url: e.url,
                            width: 800,
                            quality: 85
                        })
                    });
                });
            }
        });
        wx.createAnimation({
            transformOrigin: "50% 50%",
            duration: 1e3,
            timingFunction: "ease",
            delay: 0
        });
    },
    show: function() {},
    methods: {
        handleAudioTagTap: function() {
            _eventBus2.default.emit("tapAudioTagTap");
        },
        handleSwiperTagTap: function(e) {
            var t = e.currentTarget.dataset.sticker, i = t.event.value.link || "", a = i.indexOf("/goods/"), n = i.indexOf("/user/"), r = "goods" === t.type, u = "user" === t.type, s = i.indexOf("/page/") > -1 || i.indexOf("/tag/") > -1;
            if (r) {
                var o = i.substr(a + "/goods/".length, 24);
                return void (0, _path.navigateTo)("Webview", {
                    link: "/goods/" + o
                });
            }
            if (u) {
                var d = i.substr(n + "/user/".length, 24);
                return void (0, _path.navigateTo)("AuthorPage", {
                    author_id: d
                });
            }
            if (!s || !i) return void (0, _path.navigateTo)("SearchResult", {
                keyValue: t.event.value.name
            });
            (0, _path.navigateTo)("Webview", {
                link: i
            });
        },
        handleSwiperItemTap: function() {
            this.setData({
                hideTag: !this.data.hideTag
            });
        },
        handleImageLoad: function(e) {
            0 === e.target.dataset.index && "0" === this.data.noteIndex && this.triggerEvent("firstImageSwitched"), 
            this.setData({
                opacity: 1,
                zindex: 1
            });
        },
        handleNoteImageSwitched: function(e) {
            var t = e.detail.current;
            this.setData({
                current: t + 1
            }), this.triggerEvent("noteImageSwitched", {
                current: t + 1
            });
        }
    }
});