var _track = require("./../../../../../utils/track.js"), _path = require("./../../../../../utils/path.js"), _discovery = require("./../../../../../services/discovery.js"), isShowActivity = !1;

Component({
    properties: {},
    data: {
        isShowPinchTip: !0,
        hasReadNum: 0
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        var t = this, e = wx.getStorageSync("pick_face_entrance_readed_num") || 0;
        e > 3 && this.setData({
            isShowPinchTip: !1
        }), this.createIntersectionObserver && this.createIntersectionObserver().relativeToViewport().observe("#target", function(t) {
            t.intersectionRatio > 0 && (isShowActivity || wx.setStorage({
                key: "pick_face_entrance_readed_num",
                data: e + 1
            }), isShowActivity = !0);
        }), (0, _discovery.getPinchNum)({
            id: "5bf7f920672e141d92bd4d14"
        }).then(function(e) {
            e && (t.setData({
                hasReadNum: e
            }), (0, _track.trackNormalData)({
                action: "read_count_new_notedetail"
            }));
        }).catch(function(t) {
            console.log(t), (0, _track.trackNormalData)({
                action: "read_count_error_new_notedetail"
            });
        });
    },
    pageLifetimes: {
        hide: function() {
            isShowActivity = !1;
        }
    },
    methods: {
        handleTapGame: function() {
            (0, _track.trackNormalData)({
                action: "game_competition_from_new_notedetail"
            }), (0, _path.navigateTo)("ActivityDrawFaceIndex");
        },
        handleHasReaded: function() {
            isShowActivity = !1;
        }
    }
});