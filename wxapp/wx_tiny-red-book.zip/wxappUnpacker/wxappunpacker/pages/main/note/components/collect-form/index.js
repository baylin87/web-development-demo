function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _wepy = require("./../../../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _system = require("./../../../../../services/system.js"), _enum = require("./../../../../../utils/enum.js"), _track = require("./../../../../../utils/track.js");

Component({
    behaviors: [],
    properties: {
        fromSource: {
            type: String,
            value: "default"
        }
    },
    data: {
        isTaped: !1
    },
    lifetimes: {
        attached: function() {},
        moved: function() {},
        detached: function() {},
        ready: function() {}
    },
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        reset: function() {
            this.setData({
                isTaped: !1
            });
        },
        handleForm: function() {},
        submit: function(e) {
            var t = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), i = e.detail.formId, r = this.data.fromSource;
            if (t = t || {}, this.data.isTaped || !t.sid || "the formId is a mock one" === i) return void this.triggerEvent("submit");
            this.setData({
                isTaped: !0
            }), (0, _system.collectFormId)(i), (0, _track.trackNormalData)({
                action: "collect_form_id",
                label: r
            }), this.triggerEvent("submit");
        }
    }
});