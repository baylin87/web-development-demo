function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _wepy = require("./../../../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _discovery = require("./../../../../../utils/discovery.js"), _user = require("./../../../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _system = require("./../../../../../utils/system.js"), _system2 = _interopRequireDefault(_system), _vuefy = require("./../../../../../libs/vuefy.js"), _path = require("./../../../../../utils/path.js");

Component({
    behaviors: [],
    properties: {
        commentsCount: Number,
        commentList: Array,
        noteId: String
    },
    data: {
        formatedDescArray: [],
        appUserAvatar: _user2.default.getUserInfo() && _user2.default.getUserInfo().appUserInfo && _user2.default.getUserInfo().appUserInfo.avatar,
        showCommentInput: !1,
        focus: !0
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {
            commentListData: function() {
                return this.data.commentList.map(function(e) {
                    var t = e.content, n = t.split("\n"), o = n.map(function(e) {
                        return (0, _discovery.getFormatedExpressionArr)(e, [], []);
                    });
                    return Object.assign({}, e, {
                        formatedDesc: o
                    });
                });
            }
        });
    },
    show: function() {},
    methods: {
        handleGoCommentPage: function() {
            var e = this.data.noteId;
            _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("NoteCommentDetail", {
                    id: e
                });
            });
        },
        handleShowCommentInput: function() {
            var e = this, t = this.data.noteId;
            _user2.default.ensureLogin().then(function() {
                if (_system2.default.isAndroid() && e.data.commentList.length > 0) return void (0, 
                _path.navigateTo)("NoteCommentDetail", {
                    id: t
                });
                e.setData({
                    commentid: "",
                    showCommentInput: !0
                });
            });
        },
        handleHideCommentInput: function() {
            this.setData({
                showCommentInput: !1
            });
        },
        handleCommented: function() {
            var e = this.data.noteId;
            this.setData({
                showCommentInput: !1
            }), this.triggerEvent("createComment", {
                noteId: e
            });
        }
    }
});