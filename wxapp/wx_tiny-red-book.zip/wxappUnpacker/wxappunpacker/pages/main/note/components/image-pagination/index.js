var _vuefy = require("./../../../../../libs/vuefy.js");

Component({
    properties: {
        current: Number,
        totalImgCount: Number
    },
    data: {
        maxShowNorDoTCount: 3,
        activePosition: Math.ceil(1.5)
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {
            showSmallDot: function() {
                var t = this.data;
                return t.totalImgCount - 2 > t.maxShowNorDoTCount;
            },
            showLeftSmallDot: function() {
                var t = this.data, o = t.current, n = t.totalImgCount, a = t.maxShowNorDoTCount, r = t.activePosition, e = n - (a - r) - 1;
                return console.log(e), o <= a && o < e;
            },
            showRightSmallDot: function() {
                var t = this.data;
                return t.current >= t.totalImgCount - (t.maxShowNorDoTCount - t.activePosition) - 1;
            },
            showBothSideSmallDot: function() {
                var t = this.data, o = t.current, n = t.totalImgCount, a = t.maxShowNorDoTCount, r = t.activePosition, e = n - (a - r) - 1, u = o > a && o < e;
                return console.log(u), u;
            },
            showFirstActiveDot: function() {
                var t = this.data, o = t.current;
                t.totalImgCount;
                return 1 === o;
            },
            showLastActiveDot: function() {
                var t = this.data;
                return t.current === t.totalImgCount;
            },
            showCenterActiveDot: function() {
                var t = this.data;
                return t.current === t.totalImgCount;
            }
        });
    },
    pageLifetimes: {
        show: function() {}
    },
    methods: {}
});