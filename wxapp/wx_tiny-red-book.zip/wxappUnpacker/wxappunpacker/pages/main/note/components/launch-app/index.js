function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _wepy = require("./../../../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _vuefy = require("./../../../../../libs/vuefy.js"), _tracker = require("./../../../../../services/tracker.js"), _track = require("./../../../../../utils/track.js"), launchOps = _wepy2.default.$instance.globalData.launchOps;

Component({
    behaviors: [],
    properties: {
        launchAppParameter: String,
        show: Boolean
    },
    data: {
        showModal: !1
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {
        (0, _vuefy.computed)(this, {});
    },
    show: function() {},
    methods: {
        handleOpenModal: function() {
            this.setData({
                showModal: !0
            }), (0, _track.trackClick)({
                label: "open_contact_modal",
                timeStamp: new Date().getTime()
            });
        },
        handleTapLaunchApp: function() {
            (0, _tracker.launchAppTrack)({
                category: launchOps.path,
                url: launchOps.path + "?id=" + launchOps.query.id + "&scene=" + launchOps.scene
            });
        },
        handleLaunchAppError: function(e) {
            console.log(e), (0, _tracker.launchAppTrack)({
                category: launchOps.path,
                url: launchOps.path + "?id=" + launchOps.query.id + "&scene=" + launchOps.scene,
                fail: !0
            }), (0, _track.trackClick)({
                label: "open_contact_modal",
                timeStamp: new Date().getTime()
            }), this.setData({
                showModal: !0
            });
        }
    }
});