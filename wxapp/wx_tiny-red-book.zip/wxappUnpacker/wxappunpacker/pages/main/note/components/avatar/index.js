function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _icons = require("./../../../../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons);

Component({
    behaviors: [],
    properties: {
        imageSrc: String,
        isOfficialVerified: Boolean,
        width: {
            type: Number,
            value: 80
        },
        hasBorder: Boolean
    },
    data: {
        officalVerifiedSrc: (0, _icons.getAbsoluteUrl)("ci.xiaohongshu.com", _icons2.default.officalVerified)
    },
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {},
    show: function() {},
    methods: {}
});