function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _icons = require("./../../../../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), _page = require("./../../../../../utils/page.js"), _track = require("./../../../../../utils/track.js");

Component({
    behaviors: [],
    properties: {
        addMyMp: Object
    },
    data: {
        closeIcon: "https://ci.xiaohongshu.com/" + _icons2.default.close,
        addToMyMpStyle: "content",
        statusHeight: (0, _page.getTrueStatusBarHeight)()
    },
    lifetimes: {
        attached: function() {},
        moved: function() {},
        detached: function() {},
        ready: function() {}
    },
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        handleCloseAddMyMp: function() {
            (0, _track.trackClick)({
                label: "close_full_screen_pin_mini_program",
                context: {},
                timeStamp: new Date().getTime()
            }), this.triggerEvent("closeFullAddMyMp");
        }
    }
});