function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _path = require("./../../../../../utils/path.js"), _user = require("./../../../../../utils/user.js"), _user2 = _interopRequireDefault(_user);

Component({
    options: {},
    behaviors: [],
    properties: {
        cooperateName: String,
        cooperateId: String
    },
    data: {},
    attached: function() {},
    moved: function() {},
    detached: function() {},
    ready: function() {},
    show: function() {},
    methods: {
        handleTapedCooperate: function() {
            var e = this.data.cooperateId;
            console.log(e), _user2.default.ensureLogin().then(function() {
                (0, _path.navigateTo)("AuthorPage", {
                    author_id: e
                });
            });
        }
    }
});