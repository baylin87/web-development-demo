function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var _enum = require("./../../../../../utils/enum.js"), _track = require("./../../../../../utils/track.js"), _user = require("./../../../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _comment = require("./../../../../../services/comment.js"), userInfo = _user2.default.getUserInfo();

Component({
    behaviors: [],
    properties: {
        noteid: String,
        commentid: {
            type: String,
            value: ""
        },
        commentHolder: {
            type: String,
            value: "写评论..."
        },
        focus: {
            type: Boolean,
            value: !1
        },
        hasMask: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        avatar: userInfo && userInfo.appUserInfo && userInfo.appUserInfo.avatar,
        content: "",
        adjustPosition: !1,
        inputStyle: ""
    },
    lifetimes: {
        attached: function() {},
        moved: function() {},
        detached: function() {},
        ready: function() {}
    },
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        handleToComment: function() {
            var t = this;
            _user2.default.ensureLogin().then(function() {
                var e = t.data, n = e.content, o = e.noteid, u = e.commentid;
                n && (0, _comment.comment)({
                    content: n,
                    noteid: o,
                    commentid: u
                }).then(function(e) {
                    (0, _track.trackNormalData)({
                        action: "comment_submit"
                    }), t.triggerEvent("commented"), t.setData({
                        content: ""
                    });
                }).catch(function(t) {
                    console.log(t);
                });
            });
        },
        handleInputBlur: function(t) {
            this.setData({
                inputStyle: "bottom: 0;"
            });
        },
        handleInputFocus: function(t) {
            var e = t.detail.height;
            this.setData({
                inputStyle: "bottom: " + e + "px;"
            });
        },
        handleHideInput: function() {
            this.triggerEvent("blur");
        },
        handleInputValue: function(t) {
            this.setData({
                content: t.detail.value
            });
        }
    }
});