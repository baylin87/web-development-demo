function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.TagUtil = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), _icons = require("./../../../../utils/icons.js"), TagUtil = exports.TagUtil = function() {
    function e() {
        _classCallCheck(this, e);
    }
    return _createClass(e, [ {
        key: "transform",
        value: function(e) {
            return e.map(function(e) {
                var t = [];
                return e.stickers.floating ? e.stickers.floating.map(function(e) {
                    var t = {};
                    try {
                        t.anchorCenter = JSON.parse("[" + e.anchorCenter.replace("{", "").replace("}", "") + "]"), 
                        t.containerSize = JSON.parse("[" + e.containerSize.replace("{", "").replace("}", "") + "]"), 
                        t.unitCenter = JSON.parse("[" + e.unitCenter.replace("{", "").replace("}", "") + "]");
                    } catch (t) {
                        return e;
                    }
                    t.icon = (0, _icons.getStickerUrl)(e.type), "audio" === e.type && (t.duration = (e.audioInfo.duration / 1e3).toFixed(0));
                    var r = 1 === e.style, n = 100 * t.unitCenter[0], a = (t.unitCenter[1], 206), i = 4;
                    return (r && n >= 55 || !r && n <= 45) && (i = 10), r && n <= 20 || !r && n >= 80 ? (i = 1.28, 
                    t.innerStyle = r ? "margin-left: -50%;" : "margin-left: -65%;") : t.innerStyle = "margin-left: -50%;", 
                    a = r ? (100 - n) * i : n * i, t.textStyle = "max-width: " + a + "rpx;", Object.assign({}, e, t);
                }) : t;
            });
        }
    } ]), e;
}();