function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function i(a, o) {
                try {
                    var r = t[a](o), s = r.value;
                } catch (e) {
                    return void n(e);
                }
                if (!r.done) return Promise.resolve(s).then(function(e) {
                    i("next", e);
                }, function(e) {
                    i("throw", e);
                });
                e(s);
            }
            return i("next");
        });
    };
}

var _wepy = require("./../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _discovery = require("./../../../services/discovery.js"), _note = require("./../../../services/note.js"), _page = require("./../../../utils/page.js"), _path = require("./../../../utils/path.js"), _discovery2 = require("./../../../utils/discovery.js"), _image = require("./../../../utils/image.js"), _vuefy = require("./../../../libs/vuefy.js"), _enum = require("./../../../utils/enum.js"), _throttle = require("./../../../libs/throttle.js"), _throttle2 = _interopRequireDefault(_throttle), _eventBus = require("./../../../libs/event-bus.js"), _eventBus2 = _interopRequireDefault(_eventBus), _track = require("./../../../utils/track.js"), _user = require("./../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _tag = require("./utils/tag.js"), RUNWAY_ITEMS = 2, notes = [], guardIndex = 0, start = void 0, end = void 0, calculateGuardIndexFunction = void 0, CurrentSystemInfo = _wepy2.default.getSystemInfoSync(), pinchTipHeight = 110, pinchTipMargin = 20;

Page({
    data: {
        renderNoteListData: [],
        screenTopNotePlaceholderHeight: 0,
        page: 1,
        noteId: "",
        noteType: "",
        coverImgUrl: "",
        navigationBarConfig: {
            titleText: "笔记详情",
            backgroundColor: "#FFFFFF",
            textStyle: "black"
        },
        navigationBarTrueHeight: (0, _page.getTopSectionHeight)(),
        isFetchingFeeds: !1,
        isShowFullAddMp: !1,
        isFirstPainting: !0,
        canLaunchApp: _wepy2.default.$instance.globalData.canLaunchApp,
        startLoadTime: null
    },
    onLoad: function(e) {
        var t = e.id, n = e.firstImageId;
        t !== this.data.noteId && this.reset(), (0, _track.trackPageview)(), (0, _vuefy.computed)(this, {
            launchAppParameter: function() {
                return "xhsdiscover://portrait_feed/" + this.data.noteId + "?sourceId=miniprogram&feedType=multiple&title=%e7%ac%94%e8%ae%b0";
            }
        }), this.init(t), this.setData({
            noteId: t,
            coverImgUrl: "http://ci.xiaohongshu.com/" + n + "?imageView2/0//w/300/q/85",
            startLoadTime: Date.now(),
            canLaunchApp: _wepy2.default.$instance.globalData.canLaunchApp
        });
    },
    onReady: function() {
        var e = this.data.startLoadTime, t = new Date().getTime(), n = t - e;
        (0, _track.trackNormalData)({
            action: "FCP",
            property: n
        });
    },
    onShow: function() {
        var e = this.data, t = e.noteId, n = e.renderNoteListData;
        0 === notes.length && n.length > 0 && (this.reset(), this.setData({
            screenTopNotePlaceholderHeight: 0,
            renderNoteListData: []
        }), this.init(t, 1)), this.initEventBus();
    },
    onHide: function() {
        _eventBus2.default.off("showFullAddMp"), _eventBus2.default.off("tapAudioTagTap");
    },
    onUnload: function() {
        this && this.selectComponent && this.selectComponent("#note-item-0") && (this.selectComponent("#note-item-0").handleBackhome(), 
        this.selectComponent("#note-item-0").handleHasReaded()), this.reset(), _eventBus2.default.off("showFullAddMp"), 
        _eventBus2.default.off("tapAudioTagTap");
    },
    onShareAppMessage: function(e) {
        var t = this;
        if (e.target && e.target.dataset) {
            var n = e.target.dataset, i = n.id, a = n.title, o = n.type, r = n.desc, s = n.image, c = n.index, u = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), d = u.appUserId, h = {
                id: i,
                type: o,
                appuid: d
            }, l = void 0;
            return a = (0, _discovery2.getNoTagNoFaceIconText)(a) || (0, _discovery2.getNoTagNoFaceIconText)(r), 
            s && (l = (0, _image.getFormatedUrl)({
                url: s,
                abbrevType: 5,
                width: 400,
                height: 500
            })), (0, _track.trackNormalData)({
                action: "share",
                property: i
            }), {
                title: a,
                desc: "小红书·标记我的生活",
                path: (0, _path.makeSharePath)("NoteDetail", h),
                imageUrl: l,
                success: function() {
                    _user2.default.checkLogin() && ((0, _discovery.shareNote)({
                        noteId: i
                    }).then(function() {
                        (0, _track.trackNormalData)({
                            action: "share-success",
                            label: "share-icon",
                            property: i
                        }), t.selectComponent("#note-item-" + c).handleShareIcon(c);
                    }), t.showFullAddMp());
                }
            };
        }
    },
    onPageScroll: function(e) {
        try {
            e && void 0 === e.scrollTop || (calculateGuardIndexFunction || (calculateGuardIndexFunction = (0, 
            _throttle2.default)(this.calculateGuardIndex, 100)), calculateGuardIndexFunction(e.scrollTop));
        } catch (e) {}
    },
    init: function() {
        function e(e, n) {
            return t.apply(this, arguments);
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, n) {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, this.fetchNoteFeed(t, n);

                  case 3:
                    Array.isArray(notes) && notes[0].noteList && Array.isArray(notes[0].noteList) && notes[0].noteList[0].id && t !== notes[0].noteList[0].id && wx.showToast({
                        title: "该笔记已删除，推荐其它相关笔记",
                        icon: "none",
                        duration: 2e3
                    }), this.setData({
                        id: t,
                        renderNoteListData: notes.slice(0, RUNWAY_ITEMS + 1),
                        isFirstPainting: !1
                    }), e.next = 10;
                    break;

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), console.log(e.t0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 0, 7 ] ]);
        }));
        return e;
    }(),
    initImageStickers: function() {
        function e() {
            return t.apply(this, arguments);
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = this.data.renderNoteListData, e.next = 3, (0, _note.getNoteImageStickers)(notes[0].noteList[0].id).then(function(e) {
                        t[0].imageTags = _tag.TagUtil.prototype.transform(e);
                    });

                  case 3:
                    return e.next = 5, (0, _note.getNoteImageStickers)(notes[1].noteList[0].id).then(function(e) {
                        t[1].imageTags = _tag.TagUtil.prototype.transform(e);
                    });

                  case 5:
                    this.setData({
                        renderNoteListData: t
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return e;
    }(),
    reset: function() {
        notes = [], guardIndex = 0, start = void 0, end = void 0, calculateGuardIndexFunction = void 0, 
        this.setData({
            isFirstPainting: !0
        });
    },
    calculateGuardIndex: function(e) {
        for (var t = 0; t < notes.length - 1; t++) {
            if (!notes[t + 1] || void 0 === notes[t + 1].noteItemTopHeight) return;
            if (e > notes[t].noteItemTopHeight && e < notes[t + 1].noteItemTopHeight) {
                if (guardIndex === t) return;
                start = Math.max(0, t - RUNWAY_ITEMS), end = t + RUNWAY_ITEMS + 1, this.render(start, end, t), 
                guardIndex = t;
            }
        }
    },
    render: function(e, t, n) {
        var i = this, a = void 0;
        if (void 0 === notes[n + 1].imageTags) {
            var o = notes[n + 1].noteList[0].id;
            a = (0, _note.getNoteImageStickers)(o).then(function(e) {
                return notes[n + 1].imageTags = _tag.TagUtil.prototype.transform(e), e;
            });
        } else a = new Promise(function(e) {
            return e();
        });
        notes[e] && (t > notes.length ? Promise.all([ this.fetchNoteFeed(), a ]).then(function() {
            i.setData({
                screenTopNotePlaceholderHeight: notes[e].noteItemTopHeight,
                renderNoteListData: notes.slice(e, t)
            });
        }) : a.then(function() {
            i.setData({
                screenTopNotePlaceholderHeight: notes[e].noteItemTopHeight,
                renderNoteListData: notes.slice(e, t)
            });
        }));
    },
    setNoteItemTopHeight: function(e) {
        var t = this, n = Number(e.slice(10, e.length)), i = wx.getStorageSync("pick_face_entrance_readed_num") || 0;
        wx.createSelectorQuery && notes[n] && !notes[n].noteItemTopHeight && 0 !== notes[n].noteItemTopHeight && wx.createSelectorQuery().select("#note-item-" + n).boundingClientRect().selectViewport().scrollOffset().exec(function(e) {
            if (notes && notes[n]) try {
                notes[n].noteItemTopHeight = e[1].scrollTop + e[0].top - t.data.navigationBarTrueHeight, 
                notes[n].noteItemHeight = i > 3 && 0 === n ? e[0].height - pinchTipMargin - pinchTipHeight : e[0].height - 10;
            } catch (e) {
                console.log(e);
            }
        });
    },
    fetchNoteFeed: function(e, t, n) {
        var i = this;
        if (this.data.isFetchingFeeds) return new Promise(function(e, t) {
            t("isfetching");
        });
        this.setData({
            isFetchingFeeds: !0
        });
        var a = e || this.data.noteId, o = t || this.data.page;
        return (0, _note.getNoteFeed)({
            id: a,
            page: o,
            num: n
        }).then(function(e) {
            if (0 === e.length && (0, _track.trackNormalData)({
                action: "get-notefeed-null"
            }), notes.length > 0) {
                var t = notes[notes.length - 1].index;
                e.forEach(function(e, n) {
                    e.index = t + n + 1, e.swiperHeight = 2 * CurrentSystemInfo.screenWidth * e.noteList[0].imagesList[0].height / e.noteList[0].imagesList[0].width, 
                    e.isExpand = !1, e.isFirst = !1;
                }), notes = notes.concat(e);
            } else e.forEach(function(e, t) {
                e.index = t, e.swiperHeight = 2 * CurrentSystemInfo.screenWidth * e.noteList[0].imagesList[0].height / e.noteList[0].imagesList[0].width, 
                i.data.canLaunchApp ? e.isExpand = 0 === e.index : e.isExpand = !1, e.isFirst = 0 === e.index;
            }), notes = e;
            return i.setData({
                isFetchingFeeds: !1,
                page: i.data.page + 1
            }), notes;
        }, function() {
            (0, _track.trackNormalData)({
                action: "get-notefeed-err"
            }), i.setData({
                isFetchingFeeds: !1
            });
        });
    },
    handleNoteItemReady: function(e) {
        this.setNoteItemTopHeight(e.target.id);
    },
    handleTriggerExpand: function(e) {
        var t = this, n = e.target.id, i = Number(n.slice(10, n.length));
        notes[i].isExpand = !notes[i].isExpand, wx.createSelectorQuery().select("#note-item-" + i).boundingClientRect().exec(function(e) {
            var n = e[0].height, a = notes[i].noteItemHeight, o = n - a;
            o < 0 && wx.pageScrollTo({
                scrollTop: notes[i].noteItemTopHeight + 61 + notes[i].swiperHeight / 2 - pinchTipHeight
            }), notes[i].noteItemHeight = n - 10;
            for (var r = i + 1; r < notes.length - 1; r++) notes[r].noteItemTopHeight += o;
            t.setData({
                renderNoteListData: notes.slice(start, end)
            });
        });
    },
    initEventBus: function() {
        var e = this;
        _eventBus2.default.on("showFullAddMp", function() {
            e.showFullAddMp();
        }), _eventBus2.default.on("tapAudioTagTap", function() {
            e.selectComponent("#launch-app").handleOpenModal();
        });
    },
    showFullAddMp: function() {
        var e = this;
        wx.getStorageSync(_enum.STORAGE_KEY.CAN_SHOW_FULL_ADD_MP) && setTimeout(function() {
            e.setData({
                isShowFullAddMp: !0
            }), wx.setStorage({
                key: _enum.STORAGE_KEY.CAN_SHOW_FULL_ADD_MP,
                data: !1
            });
        }, 500);
    },
    handleCloseFullAddMyMp: function() {
        this.setData({
            isShowFullAddMp: !1
        });
    }
});