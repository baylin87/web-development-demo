function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, i) {
            function n(r, o) {
                try {
                    var a = t[r](o), s = a.value;
                } catch (e) {
                    return void i(e);
                }
                if (!a.done) return Promise.resolve(s).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(s);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var i = arguments[t];
        for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (e[n] = i[n]);
    }
    return e;
}, _createClass = function() {
    function e(e, t) {
        for (var i = 0; i < t.length; i++) {
            var n = t[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, i, n) {
        return i && e(t.prototype, i), n && e(t, n), t;
    };
}(), _wepy = require("./../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _index = require("./../../../components/search/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./../../../components/error-panel/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("./../../../components/goods-list/index.js"), _index6 = _interopRequireDefault(_index5), _goodsListItem = require("./../../../components/goods-list/goods-list-item.js"), _goodsListItem2 = _interopRequireDefault(_goodsListItem), _index7 = require("./../../../components/toast/index.js"), _index8 = _interopRequireDefault(_index7), _index9 = require("./../../../components/page/index.js"), _index10 = _interopRequireDefault(_index9), _index11 = require("./../../../components/fixed/index.js"), _index12 = _interopRequireDefault(_index11), _banners = require("./banners.js"), _banners2 = _interopRequireDefault(_banners), _path = require("./../../../utils/path.js"), _home = require("./../../../services/home.js"), _track = require("./../../../utils/track.js"), _tracking = require("./../../../mixins/tracking.js"), _tracking2 = _interopRequireDefault(_tracking), _tracker = require("./../../../mixins/tracker.js"), _tracker2 = _interopRequireDefault(_tracker), _checkLogin = require("./../../../mixins/check-login.js"), _checkLogin2 = _interopRequireDefault(_checkLogin), _page = require("./../../../utils/page.js"), _user = require("./../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _noteSearch = require("./../../../services/note-search.js"), _productTrending = require("./../../../services/product-trending.js"), _enum = require("./../../../utils/enum.js"), Home = function(e) {
    function t() {
        var e, i, n, r;
        _classCallCheck(this, t);
        for (var o = arguments.length, a = Array(o), s = 0; s < o; s++) a[s] = arguments[s];
        return i = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        n.config = {
            enablePullDownRefresh: !0
        }, n.$repeat = {
            goods: {
                com: "Goods-list-item2",
                props: "item.sync"
            }
        }, n.$props = {
            "Goods-list-item1": {
                "v-bind:item.sync": {
                    value: "item",
                    type: "item",
                    for: "goods",
                    item: "item",
                    index: "index",
                    key: "index"
                }
            },
            "Goods-list-item2": {
                "v-bind:item.sync": {
                    value: "item",
                    type: "item",
                    for: "goods",
                    item: "item",
                    index: "index",
                    key: "index"
                }
            },
            "Quark-search-home": {
                type: "home",
                "v-bind:placeHolder.sync": "placeholder",
                "xmlns:v-on": ""
            },
            "Error-panel": {},
            "Goods-list": {
                "v-bind:goods.sync": "goods"
            },
            banners: {
                "v-bind:bannerList.sync": "bannerList"
            },
            Page: {
                "xmlns:v-bind": "",
                "v-bind:navigationBarConfig.sync": "navigationBarConfig"
            },
            FixedConatiner: {
                class: "category-list"
            }
        }, n.$events = {
            "Goods-list-item1": {
                "v-on:handleGoodsItemTap": "handleGoodsItemTap"
            },
            "Goods-list-item2": {
                "v-on:handleGoodsItemTap": "handleGoodsItemTap"
            },
            "Quark-search-home": {
                "v-on:goSearchPage": "search"
            }
        }, n.components = {
            "Quark-search-home": _index2.default,
            "Error-panel": _index4.default,
            "Goods-list": _index6.default,
            "Goods-list-item1": _goodsListItem2.default,
            "Goods-list-item2": _goodsListItem2.default,
            "Quark-toast": _index8.default,
            banners: _banners2.default,
            Page: _index10.default,
            FixedConatiner: _index12.default
        }, n.mixins = [ _tracking2.default, _tracker2.default, _checkLogin2.default ], n.data = {
            miniProgram_info: {},
            navigationBarConfig: {
                titleText: "商城",
                backgroundColor: "#FFFFFF",
                textStyle: "black"
            },
            error: !1,
            goods: [],
            isFetchingFeeds: !1,
            isFetchingMoreData: !1,
            tabItemsOffset: [],
            offsetX: 0,
            searchHeader: 0,
            tabbarContainerDimension: {
                height: 0,
                width: 0
            },
            lastScrollTop: -1,
            isHideCategoy: !1,
            windowWidth: wx.getSystemInfoSync().windowWidth,
            isOnEarth: !1,
            placeholder: "搜索小红书的商品",
            categoryActiveIndex: 0,
            categoryAnimationData: {},
            feedsAnimationData: {},
            categoryList: [],
            categoryAll: {
                id: "000000012345678912000000",
                name: "更多"
            },
            bannerList: [],
            bannerTop: 95
        }, n.computed = {
            windowHeight: function() {
                return wx.getSystemInfoSync().windowHeight;
            },
            goodsContainerStyle: function() {
                return (0 !== this.categoryActiveIndex ? "margin-top: " + (this.searchHeader + this.tabbarContainerDimension.height + 10) + "px;" : "") + "min-height: " + 2 * this.windowHeight + "rpx";
            },
            tabbarContainerDimension: function() {
                return this.tabItemsOffset.reduce(function(e, t) {
                    return {
                        width: e.width + t.width,
                        height: t.height
                    };
                }, {
                    width: 0
                });
            }
        }, n.watch = {
            categoryActiveIndex: function(e, t) {
                if (e !== t) {
                    var i = this.tabItemsOffset[e], n = i.left, r = i.width, o = this.tabbarContainerDimension.width, a = Math.max(n - this.windowWidth / 2 + r / 2, 0), s = Math.min(a, o - this.windowWidth);
                    this.offsetX = s, this.$apply();
                }
            }
        }, n.methods = {
            countStyle: function() {
                var e = this;
                this.categoryList.forEach(function(t, i) {
                    var n = "#tabbar-item-" + t.id;
                    wx.createSelectorQuery().select(n).boundingClientRect(function(t) {
                        var n = t || {}, r = n.left, o = n.right, a = n.width, s = n.height;
                        e.tabItemsOffset[i] = {
                            left: r,
                            right: o,
                            width: a,
                            height: s
                        };
                    }).exec();
                });
            },
            search: function() {
                _user2.default.ensureLogin().then(function() {
                    (0, _path.navigateTo)("SearchIndex", {
                        mode: "goods"
                    });
                });
            },
            handleGoodsItemTap: function(e) {
                (0, _path.navigateTo)("Webview", {
                    link: "/goods/" + e
                });
            },
            handleCartTap: function() {
                (0, _track.trackNormalData)({
                    action: "go_to_shoppingcart"
                });
            },
            handleTapCategory: function(e, t) {
                var i = this;
                if ((0, _track.trackClick)({
                    label: "category",
                    property: t.id,
                    context: {}
                }), e === this.categoryList.length - 1) return void wx.navigateToMiniProgram({
                    appId: this.miniProgram_info.appId,
                    path: ""
                });
                wx.pageScrollTo({
                    scrollTop: .01,
                    duration: 0
                }), this.categoryActiveIndex = e, this.cursorScore = void 0, this.goods = [], this.goodsList = _productTrending.DEFAULT_DATA, 
                this.$apply(), this.fetchTrending().then(function() {
                    return i.error = !1;
                }, function(e) {
                    i.isFetchingFeeds = !1, i.$invoke("Quark-toast", "show", {
                        content: "小红薯正在忙碌中..."
                    }), i.$apply();
                });
            }
        }, r = i, _possibleConstructorReturn(n, r);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, i = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        t = _wepy2.default.$instance.globalData.promise, t && t.then(function() {
                            i.init();
                        }), this.$apply();

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onReady",
        value: function() {
            var e = this;
            if (!wx.canIUse("createSelectorQuery") || !wx.createSelectorQuery) return this.searchHeader = 41, 
            void (this.tabItemsOffset = [ {
                left: 5,
                right: 74,
                width: 69,
                height: 44
            }, {
                left: 74,
                right: 171,
                width: 97,
                height: 44
            }, {
                left: 171,
                right: 268,
                width: 97,
                height: 44
            }, {
                left: 268,
                right: 337,
                width: 69,
                height: 44
            }, {
                left: 337,
                right: 434,
                width: 97,
                height: 44
            }, {
                left: 434,
                right: 503,
                width: 69,
                height: 44
            } ]);
            wx.createSelectorQuery().select(".search-header").boundingClientRect(function(t) {
                e.searchHeader = t.height, e.bannerTop = e.searchHeader + 44 + 10;
            }).exec();
        }
    }, {
        key: "init",
        value: function() {
            var e = this, t = {};
            t.target = _path.MINIPROGRAM_STORE.TARGET, t.appId = _path.MINIPROGRAM_STORE.APP_ID, 
            t.version = _path.MINIPROGRAM_STORE.VERSION, this.miniProgram_info = t, this.pagination = JSON.parse(JSON.stringify(_page.DEFAULT_PAGINATION_ARGS)), 
            this.goodsList = _productTrending.DEFAULT_DATA;
            var i = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), n = i.sid;
            (0, _home.getFulisheCategoryBanner)({
                tabId: "5b73a17169bd897f47df97b0"
            }).then(function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                e.categoryList = t.topTabs || [], e.categoryList.push(e.categoryAll), e.bannerList = t.banners, 
                e.$apply(), e.fetch({
                    sid: n
                });
            }).catch(function(t) {
                e.fetch({
                    sid: n
                });
            });
        }
    }, {
        key: "fetch",
        value: function(e) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return _wepy2.default.showNavigationBarLoading(), this.fetchTrending(_extends({}, e, {
                isMore: i
            })).then(function() {
                return t.error = !1;
            }, function(e) {
                t.isFetchingFeeds = !1, t.$invoke("Quark-toast", "show", {
                    content: "小红薯正在忙碌中..."
                }), t.$apply();
            }).then(_wepy2.default.hideNavigationBarLoading);
        }
    }, {
        key: "fetchTrending",
        value: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = t.sid, n = void 0 === i ? this.user.sid : i, r = t.cursorScore, o = void 0 === r ? this.cursorScore : r, a = t.isMore;
            return this.cursorScore = o, a ? this.isFetchingMoreData = !0 : this.isFetchingFeeds = !0, 
            this.$apply(), (0, _home.getHomeFeeds)({
                sid: n,
                cursorScore: o,
                categoryid: this.categoryList[this.categoryActiveIndex].id
            }).then(function(t) {
                e.pagination.pageSize = t.goods.length;
                var i = (0, _productTrending.mapPage)(e.goodsList, (0, _productTrending.createData)(t.goods), e.pagination);
                e.pagination.page = 2, e.goodsList = i, e.goods = i.goods, e.isOnEarth = !t.hasMore, 
                e.goods && e.goods.length > 0 && !e.cursorScore && e.$invoke("Quark-toast", "show", {
                    content: "为您推荐" + e.goods.length + "条商品"
                }), e.cursorScore = t.cursorScore, _wepy2.default.stopPullDownRefresh(), a ? e.isFetchingMoreData = !1 : e.isFetchingFeeds = !1, 
                e.$apply(e.methods.countStyle);
            });
        }
    }, {
        key: "onPageScroll",
        value: function(e) {}
    }, {
        key: "onPullDownRefresh",
        value: function() {
            this.isOnEarth = !1, this.cursorScore = void 0, this.pagination = JSON.parse(JSON.stringify(_page.DEFAULT_PAGINATION_ARGS)), 
            this.lastScrollTop = 0, this.fetch({
                sid: this.user.sid
            }).then(_wepy2.default.stopPullDownRefresh, _wepy2.default.stopPullDownRefresh);
        }
    }, {
        key: "onReachBottom",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!this.isFetchingFeeds && this.cursorScore && !this.isOnEarth) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return e.next = 4, this.fetch({
                            sid: this.user.sid
                        }, !0);

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onShareAppMessage",
        value: function() {
            return {
                title: "小红书",
                path: (0, _path.makeSharePath)("HomePage")
            };
        }
    } ]), t;
}(_wepy2.default.page);

Page(require("./../../../npm/wepy/lib/wepy.js").default.$createPage(Home, "pages/main/store/index"));