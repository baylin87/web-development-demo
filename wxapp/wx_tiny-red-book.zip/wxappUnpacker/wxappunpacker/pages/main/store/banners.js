function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, n) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !n || "object" != typeof n && "function" != typeof n ? e : n;
}

function _inherits(e, n) {
    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function, not " + typeof n);
    e.prototype = Object.create(n && n.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(e, n) : e.__proto__ = n);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _extends = Object.assign || function(e) {
    for (var n = 1; n < arguments.length; n++) {
        var r = arguments[n];
        for (var t in r) Object.prototype.hasOwnProperty.call(r, t) && (e[t] = r[t]);
    }
    return e;
}, _createClass = function() {
    function e(e, n) {
        for (var r = 0; r < n.length; r++) {
            var t = n[r];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(n, r, t) {
        return r && e(n.prototype, r), t && e(n, t), n;
    };
}(), _wepy = require("./../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _urlParse = require("./../../../npm/url-parse/index.js"), _urlParse2 = _interopRequireDefault(_urlParse), _rowCard = require("./rowCard.js"), _rowCard2 = _interopRequireDefault(_rowCard), _index = require("./../../../components/toast/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./../../../components/modal/index.js"), _index4 = _interopRequireDefault(_index3), _path = require("./../../../utils/path.js"), _enum = require("./../../../utils/enum.js"), _home = require("./../../../services/home.js"), NOT_MEMBER_CODE = -777, EPX_MEMBER_CODE = -779, NOT_MEMBER_MODAL_MESSAGE = [ "本券仅限小红卡会员领取", "加入会员仅￥19.9，尊享五大权益" ], EXP_MEMBER_MODAL_MESSAGE = [ "体验会员不能领取此券", "成为正式会员仅￥19.9，快来加入！" ], CLAIM_COUPON_SUCCESS_MESSAGE = "恭喜！领券成功～", Banners = function(e) {
    function n() {
        var e, r, t, o;
        _classCallCheck(this, n);
        for (var a = arguments.length, i = Array(a), s = 0; s < a; s++) i[s] = arguments[s];
        return r = t = _possibleConstructorReturn(this, (e = n.__proto__ || Object.getPrototypeOf(n)).call.apply(e, [ this ].concat(i))), 
        t.props = {
            bannerList: {
                type: Array,
                twoWay: !0
            }
        }, t.data = {
            miniProgram_info: {},
            show: !1,
            hideModal: !0,
            modalHeader: " ",
            confirmText: "",
            modalMessage: [],
            offerPath: "fulishe/member/purchase"
        }, t.computed = {
            bannerGroup: function() {
                if (this.bannerList && this.bannerList.length) {
                    var e = [];
                    return this.bannerList.forEach(function(n) {
                        if (-1 === [ "slides", "sale_event" ].indexOf(n.modelType)) {
                            var r = {
                                items: []
                            }, t = "height:" + n.itemHeight + "rpx;width:" + n.itemWidth + "rpx;";
                            n.items.forEach(function(e) {
                                var n = (0, _urlParse2.default)(e.link, !0), o = n.query || {};
                                o.coupon && (e.isCoupon = !0, e.couponId = o.coupon), e.miniProgramPath = "main/webview/index?link=" + encodeURIComponent(e.link), 
                                r.items.push(_extends({}, e, {
                                    imageStyle: t
                                }));
                            }), e.push(r);
                        }
                    }), e;
                }
            }
        }, t.$repeat = {
            bannerGroup: {
                com: "row-card",
                props: "dataSource.sync"
            }
        }, t.$props = {
            "row-card": {
                "xmlns:v-bind": {
                    value: "",
                    for: "bannerGroup",
                    item: "banner",
                    index: "index",
                    key: "index"
                },
                "v-bind:dataSource.sync": {
                    value: "banner",
                    type: "item",
                    for: "bannerGroup",
                    item: "banner",
                    index: "index",
                    key: "index"
                },
                "v-bind:miniProgram_info.sync": {
                    value: "miniProgram_info",
                    for: "bannerGroup",
                    item: "banner",
                    index: "index",
                    key: "index"
                },
                "xmlns:v-on": {
                    value: "",
                    for: "bannerGroup",
                    item: "banner",
                    index: "index",
                    key: "index"
                }
            },
            "Quark-Modal1": {
                "xmlns:v-bind": "",
                "v-bind:hide.sync": "hideModal",
                "xmlns:wx": "",
                class: "modal"
            }
        }, t.$events = {
            "row-card": {
                "v-on:coupon-click": "handleCouponTap"
            }
        }, t.components = {
            "row-card": _rowCard2.default,
            QuarkToast: _index2.default,
            "Quark-Modal1": _index4.default
        }, t.methods = {
            handleTabCloseModal: function() {
                this.hideModal = !0, this.$apply();
            },
            handleCouponTap: function() {
                var e = this, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = wx.getStorageSync(_enum.STORAGE_KEY.USER_INFO), t = r.sid;
                (0, _home.claimCoupon)(n.couponId, t).then(function() {
                    e.$invoke("QuarkToast", "show", {
                        content: CLAIM_COUPON_SUCCESS_MESSAGE
                    });
                }).catch(function(n) {
                    switch (n.code) {
                      case NOT_MEMBER_CODE:
                        e.show = !0, e.hideModal = !1, e.confirmText = "成为会员", e.modalMessage = NOT_MEMBER_MODAL_MESSAGE, 
                        e.$apply();
                        break;

                      case EPX_MEMBER_CODE:
                        e.show = !0, e.hideModal = !1, e.confirmText = "成为正式会员", e.modalMessage = EXP_MEMBER_MODAL_MESSAGE, 
                        e.$apply();
                        break;

                      default:
                        e.$invoke("QuarkToast", "show", {
                            content: n.message
                        });
                    }
                });
            },
            handleTapClaim: function() {
                (0, _path.navigateTo)("Webview", {
                    link: "/genuine"
                });
            }
        }, o = r, _possibleConstructorReturn(t, o);
    }
    return _inherits(n, e), _createClass(n, [ {
        key: "onLoad",
        value: function() {
            var e = {};
            e.target = _path.MINIPROGRAM_STORE.TARGET, e.appId = _path.MINIPROGRAM_STORE.APP_ID, 
            e.version = _path.MINIPROGRAM_STORE.VERSION, this.miniProgram_info = e;
        }
    } ]), n;
}(_wepy2.default.component);

exports.default = Banners;