function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(i, o) {
                try {
                    var a = t[i](o), s = a.value;
                } catch (e) {
                    return void n(e);
                }
                if (!a.done) return Promise.resolve(s).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(s);
            }
            return r("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function replaceWebp2jpg() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return ".webp" === e.substring(e.lastIndexOf("."), e.length) && (e = e.slice(0, e.lastIndexOf(".")) + ".jpg"), 
    e;
}

function unique(e) {
    var t = {}, n = [], r = void 0;
    e.forEach(function(e) {
        t[JSON.stringify(e.id)] = e;
    });
    for (r in t) n.push(t[r]);
    return n;
}

function checkIndexInArr(e, t) {
    return "[object Array]" === Object.prototype.toString.call(e) && e.length > t;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), _wepy = require("./../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _Base = require("./../../../npm/Base64/base64.js"), _Base2 = _interopRequireDefault(_Base), _base = require("./../../../mixins/base.js"), _base2 = _interopRequireDefault(_base), _index = require("./../../../components/page/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./../../../components/loading/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("./../../../components/fixed/index.js"), _index6 = _interopRequireDefault(_index5), _index7 = require("./../../../components/search/index.js"), _index8 = _interopRequireDefault(_index7), _scrollFeeds = require("./../../../components/note-list/scroll-feeds.js"), _scrollFeeds2 = _interopRequireDefault(_scrollFeeds), _index9 = require("./../../../components/toast/index.js"), _index10 = _interopRequireDefault(_index9), _addMpToast = require("./../../../components/toast/add-mp-toast.js"), _addMpToast2 = _interopRequireDefault(_addMpToast), _index11 = require("./../../../components/form/index.js"), _index12 = _interopRequireDefault(_index11), _eventBus = require("./../../../libs/event-bus.js"), _eventBus2 = _interopRequireDefault(_eventBus), _track = require("./../../../utils/track.js"), _path = require("./../../../utils/path.js"), _user = require("./../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _storage = require("./../../../utils/storage.js"), _tracker = require("./../../../services/tracker.js"), _discovery = require("./../../../services/discovery.js"), _noteSearch = require("./../../../services/note-search.js"), _homepage = require("./../../../services/homepage.js"), _home = require("./../../../services/home.js"), IS_GET_NEW_FEEDS_KEY = "IS_GET_NEW_FEEDS", HOME_PAGE_FEEDS_KEY = "HOME_PAGE_FEEDS", REFRESH_FEEDS_NOTES_LENGTH = _wepy2.default.$instance.globalData.isIOS ? 120 : 80, Main = function(e) {
    function t() {
        var e, n, r, i;
        _classCallCheck(this, t);
        for (var o = arguments.length, a = Array(o), s = 0; s < o; s++) a[s] = arguments[s];
        return n = r = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        r.config = {
            enablePullDownRefresh: !0,
            backgroundColor: "#f5f8fa",
            onReachBottomDistance: 1e3
        }, r.mixins = (0, _base2.default)({
            CheckLoginMixin: !1,
            AddMyMpMixin: !0
        }), r.$repeat = {}, r.$props = {
            Page: {
                "xmlns:v-bind": "",
                "v-bind:navigationBarConfig.sync": "navigationBarConfig"
            },
            Loading: {
                "v-bind:type.sync": "loadType",
                "v-bind:text.sync": "loadText"
            },
            FixedConatiner: {
                class: "category-list"
            },
            SearchBar: {
                type: "home",
                class: "searchbar",
                "v-bind:placeHolder.sync": "searchPlaceholder",
                "xmlns:v-on": ""
            },
            LoadingGray: {
                type: "gray",
                class: "loading-gray-padding"
            },
            ScrollFeeds: {
                "v-bind:scrollTop.sync": "scrollTop",
                "v-bind:notes.sync": "noteList",
                "v-bind:isFirstLogin.sync": "isFirstLogin",
                "v-bind:isNeverFillInRecommendTagForm.sync": "isNeverFillInRecommendTagForm",
                "v-bind:canLike.sync": "canLike"
            },
            AddMpToast: {}
        }, r.$events = {
            SearchBar: {
                "v-on:goSearchPage": "handleSearch"
            },
            AddMpToast: {
                "v-on:MaskTap": "handleMaskTap"
            },
            QuarkForm: {
                "v-on:submit": "handleTapGame"
            }
        }, r.components = {
            Page: _index2.default,
            Loading: _index4.default,
            FixedConatiner: _index6.default,
            SearchBar: _index8.default,
            LoadingGray: _index4.default,
            ScrollFeeds: _scrollFeeds2.default,
            QuarkToast: _index10.default,
            AddMpToast: _addMpToast2.default,
            QuarkForm: _index12.default
        }, r.data = {
            navigationBarConfig: {
                titleText: "小红书",
                backgroundColor: "#FFFFFF",
                textStyle: "black"
            },
            showTopContainerSkeleton: !0,
            showFeedsSkeleton: !0,
            skeletonsCategoryList: [ , , , , ,  ],
            categoryList: [],
            categoryActiveIndex: 0,
            isFetchingNoteList: !1,
            skeletonsNoteList: [ , , , ,  ],
            noteList: [],
            noteListPage: 1,
            isLastFailGetNoteList: !1,
            pageSize: 20,
            searchDefaultValue: "",
            searchPlaceholder: "",
            isRefreshing: !1,
            scrollTop: 0,
            isFirstLogin: !1,
            isNeverFillInRecommendTagForm: !1,
            canLike: !0,
            showActivityEntry: !1,
            loadType: "defeat",
            loadText: null,
            containerHeight: 0,
            isShowAddMp: !1,
            isInitReachBottomObserver: !1,
            isLoadMoreNoteList: !1,
            isLoginStatus: null
        }, r.methods = {
            handleMaskTap: function() {
                this.isShowAddMp = !1;
            },
            handleTapGame: function() {
                this.showActivityEntry ? ((0, _track.trackNormalData)({
                    action: "lucky_packet_activity_from_homepage"
                }), (0, _path.navigateTo)("ActivityLuckyPacketHome")) : (0, _path.navigateTo)("ActivityDrawFaceIndex");
            },
            handleTapCategory: function(e, t) {
                var n = this;
                if ((0, _track.trackClick)({
                    label: "category",
                    property: t.oid,
                    context: {}
                }), e === this.categoryActiveIndex && this.noteList.length > 0) return void function() {
                    _wepy2.default.pageScrollTo({
                        scrollTop: 0,
                        duration: 100
                    });
                }();
                if (this.isFetchingNoteList = !1, this.isRefreshing = !1, this.loadType = "defeat", 
                this.loadText = null, this.$apply(), this.categoryActiveIndex = e, this.noteList = [], 
                _user2.default.checkLogin()) if ("附近" === t.name) {
                    var r = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = {
                            latitude: e.latitude,
                            longitude: e.longitude
                        }, i = _Base2.default.btoa(JSON.stringify(r));
                        n.renderNoteList({
                            clearList: !0,
                            oid: t.oid,
                            geo: i
                        });
                    };
                    _wepy2.default.getLocation().then(function(e) {
                        r(e);
                    }, function() {
                        _user2.default.openSettingModal(function(e) {
                            e.authSetting["scope.userLocation"] && _wepy2.default.getLocation().then(function(e) {
                                r(e);
                            });
                        });
                    });
                } else this.renderNoteList({
                    oid: t.oid,
                    clearList: !0
                }); else this.noteListPage = 1, this.renderNoteList({
                    oid: t.oid,
                    page: this.noteListPage,
                    clearList: !0
                });
            },
            handleSearch: function() {
                var e = this.searchDefaultValue;
                _user2.default.ensureLogin().then(function() {
                    (0, _track.trackClick)({
                        label: "search_input",
                        context: {}
                    }), (0, _path.navigateTo)("SearchIndex", {
                        defaultValue: e
                    });
                });
            }
        }, i = n, _possibleConstructorReturn(r, i);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "getCategoryList",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, r, i, o, a, s;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = "CATEGORY", n = _user2.default.checkLogin(), r = (0, _storage.getStorageSync)(t) || [], 
                        i = (0, _storage.getStorageSync)(IS_GET_NEW_FEEDS_KEY) || !1, o = {}, a = n ? _homepage.getHomeFeedsCategories : _homepage.getHomeFeedsCategoriesWithoutSid, 
                        s = [], e.prev = 7, e.next = 10, a(o);

                      case 10:
                        s = e.sent, e.next = 17;
                        break;

                      case 13:
                        e.prev = 13, e.t0 = e.catch(7), console.warn("get category list err", e.t0), checkIndexInArr(r, 0) && (s = r);

                      case 17:
                        return s && s.length > 0 ? n && (0, _storage.setStorage)({
                            key: t,
                            data: s
                        }) : s = (0, _homepage.getDefaultCategories)(), e.abrupt("return", s);

                      case 19:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 7, 13 ] ]);
            }));
            return e;
        }()
    }, {
        key: "formatNoteList",
        value: function() {
            return (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : []).map(function(e) {
                var t = checkIndexInArr(e.imagesList, 0) ? e.imagesList[0] : {}, n = e.user || {}, r = replaceWebp2jpg(t.url);
                return e.image = {
                    url: r,
                    width: t.width,
                    height: t.height
                }, e.user = {
                    image: n.images,
                    nickname: n.nickname,
                    userid: n.userid
                }, e;
            });
        }
    }, {
        key: "setNoteListCache",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            try {
                if (0 !== this.categoryActiveIndex) return;
                var t = JSON.parse(JSON.stringify(e));
                (0, _storage.setStorage)({
                    key: HOME_PAGE_FEEDS_KEY,
                    data: t
                }).then(function() {
                    console.info("set Storage note list success", t.length);
                });
            } catch (e) {
                console.warn("set Storage note list fail", e);
            }
        }
    }, {
        key: "getNoteList",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, r, i, o, a, s, c, u, l, d, h, f, p, g, _, v, y = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = this.noteList, n = y.oid, r = y.geo, i = y.cursorScore, o = void 0 === i ? "" : i, 
                        a = y.clearList, s = y.page, c = y.pageSize, u = _user2.default.checkLogin(), l = _homepage.getHomeFeeds, 
                        d = u ? "homefeed_recommend" : "recommend", n = n || d, h = {
                            oid: n,
                            cursorScore: o,
                            geo: r
                        }, f = t, p = [], u || (c = c || this.pageSize, l = _homepage.getHomeFeedsWithoutSid, 
                        h = {
                            oid: n,
                            page: s,
                            pageSize: c
                        }), g = {}, this.isLastFailGetNoteList && h.cursorScore && (h.cursorScore = ""), 
                        this.isLastFailGetNoteList = !1, e.prev = 13, e.next = 16, l(h);

                      case 16:
                        p = e.sent, p = this.formatNoteList(p || []), e.next = 24;
                        break;

                      case 20:
                        e.prev = 20, e.t0 = e.catch(13), this.isLastFailGetNoteList = !0, _wepy2.default.showToast({
                            title: "请求超时",
                            icon: "none"
                        });

                      case 24:
                        if (!(_ = !p || 0 === p.length)) {
                            e.next = 29;
                            break;
                        }
                        return this.isLastFailGetNoteList = !0, g.noNewResult = !0, e.abrupt("return", {
                            result: f,
                            resultInfo: g
                        });

                      case 29:
                        return v = function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                            if (e.length < REFRESH_FEEDS_NOTES_LENGTH) return e;
                            var t = e.length - 15;
                            return e = e.slice(t), console.warn("性能长度限制，只保留", e.length), e;
                        }, f = a ? p : v(f).concat(p), e.abrupt("return", {
                            result: f,
                            resultInfo: g
                        });

                      case 32:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 13, 20 ] ]);
            }));
            return e;
        }()
    }, {
        key: "renderNoteList",
        value: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return new Promise(function(n, r) {
                if (e.isFetchingNoteList) return void r();
                e.isFetchingNoteList = !0, e.getNoteList(t).then(function() {
                    var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = i.result, a = i.resultInfo, s = t.canCache, c = checkIndexInArr(e.notelist, 0), u = checkIndexInArr(o, 0);
                    if (e.isFetchingNoteList = !1, a.noResult && c) return void r();
                    0 !== e.categoryActiveIndex || u || c || (console.warn("首页推荐降级方案", o), o = (0, _storage.getStorageSync)(HOME_PAGE_FEEDS_KEY) || []), 
                    s && u && e.setNoteListCache(o), e.noteList = o, e.showFeedsSkeleton = !1, e.$apply(function() {
                        n(o, a);
                    });
                });
            });
        }
    }, {
        key: "renderCategoryList",
        value: function() {
            var e = this;
            (0, this.getCategoryList)().then(function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                e.categoryList = t, e.showTopContainerSkeleton = !1, e.$apply();
            });
        }
    }, {
        key: "initSearchPlaceHolder",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, r, i, o;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (t = _user2.default.getUserInfo(), n = t.openid, r = {
                            placeholder: "搜索小红书的笔记",
                            defaultValue: ""
                        }, _user2.default.checkLogin()) {
                            e.next = 4;
                            break;
                        }
                        return e.abrupt("return", r);

                      case 4:
                        return e.prev = 4, e.next = 7, (0, _noteSearch.getNotesPlaceholder)({
                            openid: n
                        });

                      case 7:
                        i = e.sent, console.log(i), checkIndexInArr(i, 0) && (o = i[0] || {}, r.placeholder = o.displayWord, 
                        r.defaultValue = o.searchWord), e.next = 14;
                        break;

                      case 12:
                        e.prev = 12, e.t0 = e.catch(4);

                      case 14:
                        return e.abrupt("return", r);

                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 4, 12 ] ]);
            }));
            return e;
        }()
    }, {
        key: "initBasic",
        value: function() {
            this.noteListPage = 1, this.categoryActiveIndex = 0, this.renderCategoryList(), 
            this.renderNoteList({
                page: 1,
                pageSize: this.pageSize,
                canCache: !0
            });
        }
    }, {
        key: "initSecondary",
        value: function() {
            var e = this, t = this.initSearchPlaceHolder, n = function() {
                return t().then(function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    e.searchPlaceholder = t.placeholder, e.searchDefaultValue = t.defaultValue;
                });
            }, r = [ n ];
            Promise.all(r.map(function(e) {
                return e();
            })).then(function() {
                console.info(">>>>>>>>>>>> secondary data ready"), e.$apply();
            });
        }
    }, {
        key: "getCurrentCategory",
        value: function() {
            var e = {
                name: "推荐",
                oid: "homefeed_recommend"
            }, t = this.categoryList, n = this.categoryActiveIndex;
            return checkIndexInArr(t, n) && (e = t[n]), e;
        }
    }, {
        key: "fetchMoreNoteList",
        value: function() {
            var e = this, t = (arguments.length > 0 && void 0 !== arguments[0] && arguments[0], 
            this.categoryList), n = this.noteList;
            this.lastScrollTop;
            if (this.isLoadMoreNoteList) return void console.warn("拦截more note list");
            if (checkIndexInArr(t, 0) && checkIndexInArr(n, 0)) {
                this.isLoadMoreNoteList = !0;
                var r = this.getCurrentCategory(), i = r.oid, o = {
                    oid: i
                };
                (0, _track.trackNormalData)({
                    action: "more-feeds",
                    property: i
                }), _user2.default.checkLogin() ? o.cursorScore = n[n.length - 1].cursorScore : (this.noteListPage++, 
                o.page = this.noteListPage, o.pageSize = this.pageSize), this.renderNoteList(o).then(function() {
                    e.isLoadMoreNoteList = !1;
                });
            }
        }
    }, {
        key: "initEventBus",
        value: function() {
            var e = this;
            _eventBus2.default.on("likeTaped", function(t) {
                var n = null, r = -1;
                if (checkIndexInArr(e.noteList, 0) && e.noteList.some(function(e, i) {
                    if (t === e.id) return n = e, r = i, !0;
                }), n) {
                    var i = n.inlikes, o = _discovery.likeNote, a = "like-increase";
                    i && (o = _discovery.dislikeNote, a = "like-decrease"), o({
                        noteId: t
                    }).then(function(o) {
                        _tracker.wxTrack.call(e, {
                            action: a,
                            property: t
                        }), n.likes = i ? --n.likes : ++n.likes, n.inlikes = !i, e.noteList[r] = n, e.$apply();
                    });
                }
            });
        }
    }, {
        key: "initReachBottomObserver",
        value: function() {
            var e = this;
            if (wx.createIntersectionObserver && !this.isInitReachBottomObserver) {
                this.isInitReachBottomObserver = !0;
                try {
                    wx.createIntersectionObserver().relativeToViewport({
                        bottom: 10
                    }).observe(".page-scroll-end", function() {
                        e.fetchMoreNoteList();
                    });
                } catch (e) {
                    console.warn("initReachBottomObserver error");
                }
            }
        }
    }, {
        key: "onLoad",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, r, i = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = _wepy2.default.$instance.globalData.promise, e.next = 3, (0, _home.activityBannerEntry)();

                      case 3:
                        n = e.sent, r = n.isShowHomeActivityBanner, console.log(r), this.showActivityEntry = r, 
                        t && t.then(function() {
                            i.isLoginStatus = _user2.default.checkLogin(), i.initSecondary(), i.initBasic();
                        });

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onPullDownRefresh",
        value: function() {
            var e = this, t = (this.categoryList, this.pageSize), n = this.noteList, r = {}, i = this.getCurrentCategory();
            if ((0, _track.trackNormalData)({
                action: "refresh",
                property: i.oid
            }), _user2.default.checkLogin()) {
                var o = "";
                checkIndexInArr(n, 0) && (o = n[n.length - 1].cursorScore), r = {
                    oid: i.oid,
                    cursorScore: o,
                    clearList: !0
                };
            } else r = {
                oid: i.oid,
                page: 1,
                pageSize: t
            };
            this.isRefreshing = !0, this.renderNoteList(r).then(function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                t && t.length > 0 && (e.isRefreshing = !1, e.$apply()), _wepy2.default.stopPullDownRefresh();
            });
        }
    }, {
        key: "onShow",
        value: function() {
            if (this.initEventBus(), null !== this.isLoginStatus && !this.isLoginStatus) {
                var e = _user2.default.checkLogin();
                !1 === this.isLoginStatus && e && (console.info("新用户刷新内容"), this.isLoginStatus = e, 
                this.initBasic());
            }
        }
    }, {
        key: "onUnload",
        value: function() {
            _eventBus2.default.off("likeTaped");
        }
    }, {
        key: "onHide",
        value: function() {
            _eventBus2.default.off("likeTaped");
        }
    }, {
        key: "onShareAppMessage",
        value: function() {
            return (0, _track.trackNormalData)({
                action: "share"
            }), {
                title: "小红书·标记我的生活",
                path: "/main/home/index"
            };
        }
    }, {
        key: "onReachBottom",
        value: function() {
            this.initReachBottomObserver(), this.fetchMoreNoteList();
        }
    } ]), t;
}(_wepy2.default.page);

Page(require("./../../../npm/wepy/lib/wepy.js").default.$createPage(Main, "pages/main/home/index"));