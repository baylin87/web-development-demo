function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function i(s, r) {
                try {
                    var o = t[s](r), a = o.value;
                } catch (e) {
                    return void n(e);
                }
                if (!o.done) return Promise.resolve(a).then(function(e) {
                    i("next", e);
                }, function(e) {
                    i("throw", e);
                });
                e(a);
            }
            return i("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function replaceWebp2jpg(e) {
    return e.map(function(e) {
        var t = e.image.url;
        return ".webp" === t.substring(t.lastIndexOf("."), t.length) && (t = t.slice(0, t.lastIndexOf(".")) + ".jpg"), 
        e.image.url = t, e;
    });
}

function formatNum() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    return e >= 1e4 ? (e = Math.round(10 * (e / 1e4).toFixed(1)) / 10) + "万" : e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), _wepy = require("./../../../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _index = require("./../../../components/page/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./../../../components/toast/index.js"), _index4 = _interopRequireDefault(_index3), _userInfo = require("./../../../components/user/user-info.js"), _userInfo2 = _interopRequireDefault(_userInfo), _scrollFeeds = require("./../../../components/note-list/scroll-feeds.js"), _system = require("./../../../services/system.js"), _author = require("./../../../services/author.js"), _collect = require("./../../../services/collect.js"), _track = require("./../../../utils/track.js"), _user = require("./../../../utils/user.js"), _user2 = _interopRequireDefault(_user), _discovery = require("./../../../services/discovery.js"), _tracker = require("./../../../services/tracker.js"), _icons = require("./../../../utils/icons.js"), _icons2 = _interopRequireDefault(_icons), _eventBus = require("./../../../libs/event-bus.js"), _eventBus2 = _interopRequireDefault(_eventBus), _path = require("./../../../utils/path.js"), _enum = require("./../../../utils/enum.js"), _base = require("./../../../mixins/base.js"), _base2 = _interopRequireDefault(_base), CDN_ORIGIN = "https://ci.xiaohongshu.com", Mine = function(e) {
    function t() {
        var e, n, i, s;
        _classCallCheck(this, t);
        for (var r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
        return n = i = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(o))), 
        i.config = {}, i.$repeat = {}, i.$props = {
            QuarkPage: {
                "xmlns:v-bind": "",
                "v-bind:navigationBarConfig.sync": "navigationBarConfig"
            },
            UserInfoComponent: {
                "v-bind:noteList.sync": "noteList",
                "v-bind:userInfo.sync": "userInfo",
                "v-bind:switchTab.sync": "switchTab",
                "v-bind:isFetching.sync": "isFetching",
                "v-bind:isFetchEnd.sync": "isFetchEnd",
                "xmlns:v-on": ""
            }
        }, i.$events = {
            UserInfoComponent: {
                "v-on:tapSwitchTab": "handleTapSwitchTab"
            }
        }, i.components = {
            QuarkPage: _index2.default,
            QuarkToast: _index4.default,
            UserInfoComponent: _userInfo2.default
        }, i.data = {
            isLogin: !1,
            noteList: [],
            navigationBarConfig: {
                titleText: "我的",
                backgroundColor: "#FFFFFF",
                textStyle: "black"
            },
            canLike: !1,
            page: 1,
            userInfo: {},
            bottomStart: "",
            switchTab: "notes",
            settingsIcon: CDN_ORIGIN + "/" + _icons2.default.settingsGrey,
            isFetching: !1,
            isFetchEnd: !1
        }, i.mixins = (0, _base2.default)({
            NewbieMixin: !1,
            WXfriendMixin: !1,
            IntervalMixin: !1,
            PerformancelMixin: !1
        }), i.methods = {
            handleEditInfo: function() {
                if (!this.isLogin) return void (0, _path.navigateTo)("LoginIndex");
                (0, _track.trackClick)({
                    label: "edit_info",
                    context: {},
                    timeStamp: new Date().getTime()
                }), (0, _path.navigateTo)("InfoPage");
            },
            handleScroll: function(e) {
                this.noteList.length > _scrollFeeds.REFRESH_FEEDS_NOTES_LENGTH && (this.$invoke("QuarkToast", "show", {
                    content: "正在加载更多内容"
                }), this.noteList = this.noteList.slice(_scrollFeeds.REFRESH_FEEDS_NOTES_LENGTH - 10)), 
                e.detail.scrollHeight - e.detail.scrollTop < _scrollFeeds.PUSH_MORE_SCOLL_TOP ? this.isLoadingFeeds || (this.isLoadingFeeds = !0, 
                this.pushMoreFeeds()) : this.isLoadingFeeds = !1;
            },
            handleScrollToLower: function() {
                this.pushMoreFeeds();
            },
            handleTapSwitchTab: function(e, t) {
                this.switchTab = e, this.noteList = [], this.refreshNotes(this.userInfo.userid);
            },
            handleTapSettings: function() {
                this.isLogin && ((0, _track.trackClick)({
                    label: "settings",
                    context: {},
                    timeStamp: new Date().getTime()
                }), (0, _path.navigateTo)("SettingsPage"));
            }
        }, s = n, _possibleConstructorReturn(i, s);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "init",
        value: function(e) {
            this.refreshUserInfo(e), this.refreshNotes(e), this.initEventBus();
        }
    }, {
        key: "refreshNotes",
        value: function(e) {
            var t = e;
            return "collect" === this.switchTab ? void this.fetchCollectFeed() : "notes" === this.switchTab ? void this.fetchAuthorNotes({
                userId: t
            }) : void 0;
        }
    }, {
        key: "onLoad",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, i = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        console.log(this.sid), t = _user2.default.getUserInfo(), n = t.appUserId, this.userId = n, 
                        this.isLogin = _user2.default.checkLogin(), this.settingsIcon = this.isLogin ? CDN_ORIGIN + "/" + _icons2.default.settings : CDN_ORIGIN + "/" + _icons2.default.settingsGrey, 
                        _user2.default.ensureLogin().then(function() {
                            i.init(n);
                        });

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onUnload",
        value: function() {
            _eventBus2.default.off("likeTaped");
        }
    }, {
        key: "onHide",
        value: function() {
            _eventBus2.default.off("likeTaped");
        }
    }, {
        key: "fetchCollectFeed",
        value: function(e) {
            var t = this;
            return this.isFetching ? new Promise(function(e) {
                return e();
            }) : (this.isFetching = !0, (0, _collect.getFaved)({
                bottomStart: e
            }).then(function(e) {
                var n = e;
                n && 0 === n.length ? t.isFetchEnd = !0 : (n = t.formatNoteList(e), t.noteList = t.noteList.concat(n), 
                t.bottomStart = n[n.length - 1].cursorScore), t.isFetching = !1, t.$apply();
            }, function(e) {
                t.isFetching = !1;
            }));
        }
    }, {
        key: "fetchAuthorNotes",
        value: function(e) {
            var t = this, n = e.userId, i = e.page, s = void 0 === i ? 1 : i, r = e.pageSize, o = void 0 === r ? 15 : r;
            return this.isFetching ? new Promise(function(e) {
                return e();
            }) : (this.isFetching = !0, (0, _author.getNoteUser)({
                userId: n,
                page: s,
                pageSize: o
            }).then(function(e) {
                var n = e.notes;
                if (n && 0 === n.length) t.isFetchEnd = !0; else {
                    var i = t.formatNoteList(n);
                    t.noteList = t.noteList.concat(i);
                }
                t.isFetching = !1, t.page++, t.$apply();
            }, function(e) {
                t.isFetching = !1, console.log("err", e);
            }));
        }
    }, {
        key: "pushMoreFeeds",
        value: function() {
            0 !== this.noteList.length && ("collect" === this.switchTab && this.fetchCollectFeed(this.bottomStart), 
            "notes" === this.switchTab && this.fetchAuthorNotes({
                userId: this.userId,
                page: this.page,
                pageSize: this.pageSize
            }));
        }
    }, {
        key: "formatNoteList",
        value: function(e) {
            return replaceWebp2jpg(e.map(function(e) {
                return Object.assign({}, e, {
                    image: {
                        url: e.imagesList[0].url,
                        width: e.imagesList[0].width,
                        height: e.imagesList[0].height
                    },
                    user: {
                        image: e.user.images,
                        nickname: e.user.nickname,
                        userid: e.user.userid || e.user.userId
                    }
                });
            }));
        }
    }, {
        key: "formatUserInfo",
        value: function(e) {
            var t = e;
            return t.level.levelName = t.level.level_name, t.userid = this.userId, t;
        }
    }, {
        key: "refreshUserInfo",
        value: function() {
            var e = this;
            arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            (0, _system.getMineInfo)().then(function(t) {
                e.userInfo = e.formatUserInfo(t), e.$apply();
            });
        }
    }, {
        key: "handleGoLoginPage",
        value: function() {
            (0, _path.navigateTo)("LoginIndex");
        }
    }, {
        key: "initEventBus",
        value: function() {
            var e = this;
            _eventBus2.default.on("likeTaped", function(t) {
                e.noteList.some(function(n, i) {
                    if (t === n.id) {
                        var s = n.inlikes, r = _discovery.likeNote, o = "like-increase";
                        return s && (r = _discovery.dislikeNote, o = "like-decrease"), r({
                            noteId: t
                        }).then(function(r) {
                            _tracker.wxTrack.call(e, {
                                action: o,
                                property: t
                            }), n.likes = s ? --n.likes : ++n.likes, n.inlikes = !s, e.noteList[i] = n, e.$apply();
                        }), !0;
                    }
                });
            });
        }
    } ]), t;
}(_wepy2.default.page);

Page(require("./../../../npm/wepy/lib/wepy.js").default.$createPage(Mine, "pages/main/mine/index"));