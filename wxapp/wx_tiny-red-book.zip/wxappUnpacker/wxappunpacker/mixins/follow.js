function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var o = 0; o < t.length; o++) {
            var r = t[o];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, o, r) {
        return o && e(t.prototype, o), r && e(t, r), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../utils/api.js"), _api2 = _interopRequireDefault(_api), _appuser = require("./../services/appuser.js"), _tracker = require("./../services/tracker.js"), FollowMixin = function(e) {
    function t() {
        return _classCallCheck(this, t), _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments));
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "handleFollow",
        value: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            t && t.fstatus && -1 === [ "follows", "both" ].indexOf(t.fstatus) ? this.followAppUser(t) : t && t.fstatus && -1 === [ "none" ].indexOf(t.fstatus) ? _api2.default.showModal({
                title: "是否取消关注",
                confirmText: "确认",
                cancelText: "取消",
                success: function(o) {
                    o.confirm && e.unfollowAppUser(t);
                }
            }) : t && t.hasOwnProperty("followed") && !t.followed ? this.followAppUser(t) : t && t.hasOwnProperty("followed") && t.followed && _api2.default.showModal({
                title: "是否取消关注",
                confirmText: "确认",
                cancelText: "取消",
                success: function(o) {
                    o.confirm && e.unfollowAppUser(t);
                }
            });
        }
    }, {
        key: "followAppUser",
        value: function(e) {
            var t = this;
            (0, _appuser.followUser)({
                userId: e.userid || e.id
            }).then(function() {
                _tracker.wxTrack.call(t, {
                    action: "follow-tap",
                    label: "follow-button",
                    property: e.userid || e.id
                }), e.hasOwnProperty("followed") ? e.followed = !0 : e.fstatus = "follows", t.$apply();
            });
        }
    }, {
        key: "unfollowAppUser",
        value: function(e) {
            var t = this;
            (0, _appuser.unfollowUser)({
                userId: e.userid || e.id
            }).then(function() {
                _tracker.wxTrack.call(t, {
                    action: "unfollow-tap",
                    label: "unfollow-button",
                    property: e.userid || e.id
                }), e.hasOwnProperty("followed") ? e.followed = !1 : e.fstatus = "none", t.$apply();
            });
        }
    } ]), t;
}(_wepy2.default.mixin);

exports.default = FollowMixin;