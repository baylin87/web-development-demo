function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function BaseMixin(e) {
    var i = [], r = {
        CheckLoginMixin: !0,
        TrackerMixin: !0,
        WXfriendMixin: !0,
        IntervalMixin: !0,
        PerformancelMixin: !0
    }, n = Object.assign({}, r, e);
    for (var a in MixinMap) n && n[a] && i.push(MixinMap[a]);
    return i;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = BaseMixin;

var _checkLogin = require("./check-login.js"), _checkLogin2 = _interopRequireDefault(_checkLogin), _tracker = require("./tracker.js"), _tracker2 = _interopRequireDefault(_tracker), _wxfriend = require("./wxfriend.js"), _wxfriend2 = _interopRequireDefault(_wxfriend), _newbie = require("./newbie.js"), _newbie2 = _interopRequireDefault(_newbie), _follow = require("./follow.js"), _follow2 = _interopRequireDefault(_follow), _tracking = require("./tracking.js"), _tracking2 = _interopRequireDefault(_tracking), _interval = require("./interval.js"), _interval2 = _interopRequireDefault(_interval), _performance = require("./performance.js"), _performance2 = _interopRequireDefault(_performance), MixinMap = {
    CheckLoginMixin: _checkLogin2.default,
    TrackerMixin: _tracker2.default,
    WXfriendMixin: _wxfriend2.default,
    NewbieMixin: _newbie2.default,
    FollowMixin: _follow2.default,
    TrackingMixin: _tracking2.default,
    IntervalMixin: _interval2.default,
    PerformancelMixin: _performance2.default
};