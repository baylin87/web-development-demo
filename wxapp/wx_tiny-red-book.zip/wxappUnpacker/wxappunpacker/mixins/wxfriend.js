function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, n) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !n || "object" != typeof n && "function" != typeof n ? e : n;
}

function _inherits(e, n) {
    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function, not " + typeof n);
    e.prototype = Object.create(n && n.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(e, n) : e.__proto__ = n);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var r = n[t];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(n, t, r) {
        return t && e(n.prototype, t), r && e(n, r), n;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _user = require("./../services/user.js"), _enum = require("./../utils/enum.js"), WXfriendMixin = function(e) {
    function n() {
        return _classCallCheck(this, n), _possibleConstructorReturn(this, (n.__proto__ || Object.getPrototypeOf(n)).apply(this, arguments));
    }
    return _inherits(n, e), _createClass(n, [ {
        key: "onLoad",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.fromUnionId, t = e.appuid, r = _wepy2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO), o = r.sid, i = r.appUserId, u = r.unionid;
            if (o) return void (t ? (0, _user.becomeFriend)({
                sid: o,
                fromUid: t,
                toUid: i
            }) : n && (0, _user.becomeRawFriend)({
                fromUnionId: n,
                toUnionId: u,
                toUserid: i
            }));
            _wepy2.default.$instance.globalData.promise && _wepy2.default.$instance.globalData.promise.then(function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                e.sid && e.appUserId ? t ? (0, _user.becomeFriend)({
                    sid: e.sid,
                    fromUid: t,
                    toUid: e.appUserId
                }) : n && (0, _user.becomeRawFriend)({
                    fromUnionId: n,
                    toUnionId: e.unionid,
                    toUserid: e.appUserId
                }) : n && (0, _user.becomeRawFriend)({
                    fromUnionId: n,
                    toUnionId: u
                });
            }, function(e) {
                console.log("login-fail", e);
            });
        }
    } ]), n;
}(_wepy2.default.mixin);

exports.default = WXfriendMixin;