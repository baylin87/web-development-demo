function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(t, n, a) {
        return n && e(t.prototype, n), a && e(t, a), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _enum = require("./../utils/enum.js"), _path = require("./../utils/path.js"), MAX_NAVIGATE_TO_LOGIN_PAGE_COUNT = 2, CheckLoginMixin = function(e) {
    function t() {
        var e, n, a, o;
        _classCallCheck(this, t);
        for (var i = arguments.length, r = Array(i), l = 0; l < i; l++) r[l] = arguments[l];
        return n = a = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(r))), 
        a.data = {
            sid: null,
            appUserId: null
        }, o = n, _possibleConstructorReturn(a, o);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            var e = this, t = _wepy2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO), n = t.sid, a = t.appUserId;
            if (n) return this.sid = n, void (this.appUserId = a);
            _wepy2.default.$instance.globalData.promise && _wepy2.default.$instance.globalData.promise.then(function(t) {
                console.log(sid)
                if (console.log("login", t), !t.sid) {
                    var n = Date.now(), a = _wepy2.default.$instance.globalData.navigateToLoginPageTime;
                    _wepy2.default.$instance.globalData.navigateToLoginPageCount < MAX_NAVIGATE_TO_LOGIN_PAGE_COUNT && (!a || n - a > 3e4) && (_wepy2.default.$instance.globalData.navigateToLoginPageCount++, 
                    _wepy2.default.$instance.globalData.navigateToLoginPageTime = n, (0, _path.navigateTo)("LoginIndex"));
                }
                e.sid = t.sid, e.appUserId = t.appUserId;
            }, function(e) {
                console.log("login-fail", e);
            });
        }
    }, {
        key: "onShow",
        value: function() {
            var e = _wepy2.default.getStorageSync(_enum.STORAGE_KEY.USER_INFO), t = e.sid, n = e.appUserId;
            t && (this.sid = t, this.appUserId = n);
        }
    } ]), t;
}(_wepy2.default.mixin);

exports.default = CheckLoginMixin;